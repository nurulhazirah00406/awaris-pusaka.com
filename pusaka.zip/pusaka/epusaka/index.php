<?php 
$base_url = "http://" . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'] . "view";

redirect($base_url);

function redirect($url) {
    header('Location: '.$url);
    die();
}
// exit();
?>