$(".dial1").knob();
dial1 = $(".dial1").val();
$({animatedVal: 0}).animate({animatedVal: dial1}, {
	duration: 3000,
	easing: "swing",
	step: function() {
		$(".dial1").val(Math.ceil(this.animatedVal)).trigger("change");
	}
});

$(".dial2").knob();
dial2 = $(".dial2").val();
$({animatedVal: 0}).animate({animatedVal: dial2}, {
	duration: 3000,
	easing: "swing",
	step: function() {
		$(".dial2").val(Math.ceil(this.animatedVal)).trigger("change");
	}
});

$(".dial3").knob();
dial3 = $(".dial3").val();
$({animatedVal: 0}).animate({animatedVal: dial3}, {
	duration: 3000,
	easing: "swing",
	step: function() {
		$(".dial3").val(Math.ceil(this.animatedVal)).trigger("change");
	}
});

$(".dial4").knob();
dial4 = $(".dial4").val();
$({animatedVal: 0}).animate({animatedVal: dial4}, {
	duration: 3000,
	easing: "swing",
	step: function() {
		$(".dial4").val(Math.ceil(this.animatedVal)).trigger("change");
	}
});

$(".dial5").knob();
dial5 = $(".dial5").val();
$({animatedVal: 0}).animate({animatedVal: dial5}, {
	duration: 3000,
	easing: "swing",
	step: function() {
		$(".dial5").val(Math.ceil(this.animatedVal)).trigger("change");
	}
});

$(".dial6").knob();
dial6 = $(".dial6").val();
$({animatedVal: 0}).animate({animatedVal: dial6}, {
	duration: 3000,
	easing: "swing",
	step: function() {
		$(".dial6").val(Math.ceil(this.animatedVal)).trigger("change");
	}
});
