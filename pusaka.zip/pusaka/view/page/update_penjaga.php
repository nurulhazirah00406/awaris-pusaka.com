<?php
	if (isset($_GET['simati']) && ($_GET['simati'] != '' || $_GET['simati'] != null)) {
		$id = $_GET['simati'];
	}else{
		$base_url = base_url();
		$url = $base_url."/epusaka/view/senarai_pemohon.php";
		// redirect($url);
		echo "<script> window.location.href = `$url`; </script>;";
	}

	$row = $result->fetch_assoc();

?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="section-title">
				<h3>Borang Permohonan Perkhidmatan Pentadbiran Harta Pusaka</h3>
			</div>
			<h4>9.0 Keterangan Mengenai Penjaga</h4>
			<h6>
				<strong>Jika ada Waris Di Bawah Umur 18 Tahun/Tidak Sempurna Akal</strong>
			</h6>
		</div>
		<div class="col-md-12">
			<form action="../../epusaka/controller/functions.php" method="post">
				<div class="row col-md-12">
					<div class="col-md-6">
						<div class="left-side-form">
							<h5>
								<label for="pw_nama">Nama Penuh/ (Seperti Dalam Kad Pengenalan)</label>
								<span class="error"></span>
							</h5>
							<p>
								<input type="hidden" name="sm_id" value="<?php echo $id;?>">
								<input type="text" name="pw_nama" value="<?php echo $row['pw_nama'];?>">
							</p>
							<h5><label for="pw_nric_new">No. KP. Baru</label><span class="error">
								</span></h5>
							<p><input type="text" name="pw_nric_new" value="<?php echo $row['pw_nric_new'];?>"></p>
							
							<h5><label for="pw_nric_old">No. KP Lama/Polis/Tentera/No. Pasport</label><span class="error">
								</span></h5>
							<p><input type="text" name="pw_nric_old" value="<?php echo $row['pw_nric_old'];?>"></p>
							
							<h5><label for="pw_umur">Umur</label><span class="error">
								</span></h5>
							<p><input type="text" name="pw_umur" value="<?php echo $row['pw_umur'];?>"></p>
							<?php 
                                                	$var = $row['pw_birthdate'];
													$date = str_replace('/', '-', $var);
                                                ?>
							<h5><label for="pw_birthdate">Tarikh Lahir</label><span class="error">
								</span></h5>
							<p><input type="date" name="pw_birthdate" value="<?php echo date('Y-m-d', strtotime($date));?>"></p>
							
							<h5><label for="pw_alamat_tetap">Alamat Tetap</label><span class="error">
								</span></h5>
							<p><textarea name="pw_alamat_tetap"><?php echo $row['pw_alamat_tetap'];?></textarea></p>
							
							<h5><label for="pw_poskod">Poskod</label><span class="error">
								</span></h5>
							<p><input type="text" name="pw_poskod" value="<?php echo $row['pw_poskod'];?>"></p>
							
							<h5><label for="pw_negeri">Negeri</label><span class="error">
								</span></h5>
							<p><input type="text" name="pw_negeri" value="<?php echo $row['pw_negeri'];?>"></p>
						</div>
					</div>
					<div class="col-md-6">
						<div class="right-side-form">
							<h5><label for="pw_notel_rumah">No. Tel Rumah</label><span class="error">
								</span></h5>
							<p><input type="text" name="pw_notel_rumah" value="<?php echo $row['pw_notel_rumah'];?>"></p>
							
							<h5><label for="pw_notel_bimbit">No. Tel Bimbit</label><span class="error">
								</span></h5>
							<p><input type="text" name="pw_notel_bimbit" value="<?php echo $row['pw_notel_bimbit'];?>"></p>
							
							<h5><label for="pw_notel_pjbt">No. Tel Pejabat</label><span class="error">
								</span></h5>
							<p><input type="text" name="pw_notel_pjbt" value="<?php echo $row['pw_notel_pjbt'];?>"></p>
							
							<h5><label for="pw_emel">Emel</label><span class="error">
								</span></h5>
							<p><input type="text" name="pw_emel" value="<?php echo $row['pw_emel'];?>"></p>
							
							<h5><label for="pw_hubungan">Perhubungan Persaudaraan Dengan Simati</label></h5>
							<input type="radio" name="pw_hubungan" value="Bapa">
							<span>Bapa</span>
							<input type="radio" name="pw_hubungan" value="Ibu">
							<span>Ibu</span>
							<input type="radio" name="pw_hubungan" value="Lain-lain">
							<span>Lain-lain</span>
							<span class="error"></span>
							<p>
								<a href="borang_view.php?simati=<?php echo $id;?>" class="btn btn-secondary" title="Langkau ke Akuan">Skip</a>
								<input type="submit" name="btn_update_penjaga" value="Kemaskini">
							</p>
						</div>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>

<script type="text/javascript">
	// p_hubungan
	var pw_hubungan = `<?php echo $row['pw_hubungan']; ?>`;

	$('input:radio[name="pw_hubungan"]').filter('[value="'+pw_hubungan+'"]').attr('checked', true);
</script>
