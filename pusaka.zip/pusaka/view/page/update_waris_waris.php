<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	<div class="container">
										<div class="row">
												<div class="col-md-12">
													<br>
													<div class="section-title">
														<h3>8.0 Keterangan Mengenai Waris-Waris Simati</h3>
													</div>
													<h5>Nama Penuh/ (Seperti Dalam Kad Pengenalan) <span class="error"></span><p><input type="text" name="" value=""></p>
													</h5>
													<h5>Hubungan <span class="error"></span><p><input type="text" name="" value=""></p>
													</h5>
													<h5>No. KP <span class="error"></span><p><input type="text" name="" value=""></p>
													</h5>
													<h5>Alamat <span class="error"></span><p><input type="text" name="" value=""></p>
													</h5>
													<h5>No. Telefon Bimbit <span class="error"></span><p><input type="text" name="" value=""></p>
													</h5>
													<h5>No. Telfon Rumah <span class="error"></span><p><input type="text" name="" value=""></p>
													</h5>
													<h5>No. Telefon Bimbit <span class="error"></span><p><input type="text" name="" value=""></p>
													</h5>
													<h5>Emel <span class="error"></span><p><input type="text" name="" value=""></p>
													</h5>
												</div>
											</div>
										</div>
									</div>
								</div>
</body>
</html>