<?php
	if (isset($_GET['simati']) && ($_GET['simati'] != '' || $_GET['simati'] != null)) {
		$id = $_GET['simati'];
	}else{
		$base_url = base_url();
		$url = $base_url."/epusaka/view/senarai_pemohon.php";
		// redirect($url);
		echo "<script> window.location.href = `$url`; </script>;";
	}

	$row = $result->fetch_assoc();
	// var_dump();

?>
<div class="container">
  <div class="row">
    <div class="col-md-12">
      <div class="section-title">
        <h3>Akuan</h3>
      </div>
      <h4>
        <strong>10.0 Akuan</strong>
      </h4> 
      <?php include ('../view/progressbarr.php')?> 
      <div class="mt-5">
      	<h5>Saya, <strong><u><?php echo $row['p_nama']; ?></u></strong> dengan sesungguhnya dan sebenarnya mengaku bahawa tuntutan pusaka ini belum pernah dibuat dan segala keterangan yang tersebut di atas adalah benar mengikut pengetahuan saya sendiri dan saya membuat akuan ini dengan kepercayaan bahawa apa-apa yang tersebut di dalamnya adalah benar, serta menurut Akta Akuan Berkanun 1960.</h5>
      </div>
      <form action="../../epusaka/controller/functions.php" method="post">
	      <div class="form-check mb-2 mt-5">
	        <input class="form-check-input" type="checkbox" value="1" id="defaultCheck1" required>
	        <label class="form-check-label" for="defaultCheck1"> <strong>Setuju</strong> </label>
	      </div>
	      <div class="mb-5 p-5">
	      	<input type="hidden" name="sm_id" value="<?php echo $id;?>">
	      	<input type="submit" name="btn_borang_akuan" class="float-right" value="submit">
	      </div>
      </form>
       <h5>Diperbuat dan dengan sebenarnya diakui oleh yang tersebut namanya di atas <br> iaitu <strong><u><?php echo $row['p_nama']; ?></u></strong> <br> di..................... <br> di Negeri .................... <br> pada jam <strong><u><?php date_default_timezone_set('Asia/Kuala_Lumpur'); echo date('h:i:s');?> </u></strong> bertarikh <strong><u><?php date_default_timezone_set('Asia/Kuala_Lumpur'); echo date('d/m/Y');?> </u></strong> </h5> 
      <p>
        <br>
      </p> 
		<hr>
		<p3>*Sila COP JURAT di Pesuruhjaya Sumpah berkenaan tandatangan tuan/puan dalam Bahasa CINA/TAMIL/JAWI/COP IBU JARI
		<br> ** Sebarang lampiran tambahan perlu diikrarkan dihadapan Pesuruhjaya Sumpah</p3>
       <div class="col-md-6">
        <div class="right-side-form">
			<br>
          <h5>Di Hadapan Saya <br>
            <br>
            <br> _______________________________________ <br>
            <strong>Tandatangan Hakim Mahkamah Saksyen/ Majistret/ Pesuruhjaya Sumpah</strong>
          </h5>
        </div>
		   <div><center><img src="../img/imageico.ico" alt="image/icon" class="center"></center>
		   <p2> 15-03 Tower A, Menara Prima, Jalan PJU 1/39, Dataran Prima, 47301 Petaling Jaya Selangor Malaysia 
			   <br> Tel : +603-7887 1120 | www.awarisgroup.com</p2>
		   </div> 
        <!-- <p>
          <input type="submit" name="btn_borang_akuan" class="float-right" value="submit"> 
        </p> -->
      </div> 
    </div>
  </div>
</div>