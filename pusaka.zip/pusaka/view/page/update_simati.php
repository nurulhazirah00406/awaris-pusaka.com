<?php
	if (isset($_GET['simati']) && ($_GET['simati'] != '' || $_GET['simati'] != null)) {
		$id = $_GET['simati'];
	}else{
		$base_url = base_url();
		$url = $base_url."/epusaka/view/senarai_pemohon.php";
		// redirect($url);
		echo "<script> window.location.href = `$url`; </script>;";
	}

	// var_dump($result->fetch_assoc());
	$row = $result->fetch_assoc();

?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="section-title">
				<h3>Borang Permohonan Perkhidmatan Pentadbiran Harta Pusaka</h3>
			</div>
			<?php //include ('../view/progressbarr.php')?>
			<div class="row">
				<div class="col-md-12">
					<h4><strong>2.0 Keterangan Mengenai Simati</strong></h4>
					<form action="../../epusaka/controller/functions.php" method="post">
						<div class="row">
							<div class="col-md-6">
								<div class="left-side-form">
									<h5><label for="nama">Nama Penuh/ (Seperti Dalam Kad Pengenalan)</label>
									<span class="error"></span></h5>
									<p><input type="hidden" name="sm_id" value="<?php echo $id;?>"></p>
									<p><input type="text" name="sm_nama" value="<?php echo $row['sm_nama'];?>"></p>

									<h5><label for="nokp">No. KP Baru</label><span class="error">
											</span></h5>
									<p><input type="text" name="sm_nric_new" value="<?php echo $row['sm_nric_new'];?>"></p>
									
									<h5><label for="nokplama">No. KP Lama/Polis/Tentera/No. Pasport</label><span class="error">
											</span></h5>
									<p><input type="text" name="sm_nric_old" value="<?php echo $row['sm_nric_old'];?>"></p>
									
									<h5><label for="jantina">Jantina</label></h5>
									<input type="radio" name="sm_jantina" value="Lelaki"><span>Lelaki</span>
									<input type="radio" name="sm_jantina" value="Perempuan"><span>Perempuan</span>
									<span class="error">
										</span>

									<h5><label for="sm_datemati">Tarikh Meninggal Dunia </label><span class="error">
											</span></h5>
											<?php 
                                                	$var = $row['p_birthdate'];
													$date = str_replace('/', '-', $var);
                                                ?>
									<p><input type="date" name="sm_datemati" value="<?php echo date('Y-m-d', strtotime($date));?>" ></p>

									<h5><label for="sm_tmptmati">Tempat Kematian</label><span class="error">
											</span></h5>
									<p><textarea name="sm_tmptmati"><?php echo $row['sm_tmptmati'];?></textarea></p>
									
					         </div>
							</div>
							<div class="col-md-6">
								<div class="right-side-form">
									
                                    <h5><label for="sm_taraf_perkhawinan">Taraf Perkhawinan</label></h5>
									<input type="radio" name="sm_taraf_perkhawinan" value="Berkahwin"><span>Berkahwin</span>
									<input type="radio" name="sm_taraf_perkhawinan" value="Bujang"><span>Bujang</span>
									<input type="radio" name="sm_taraf_perkhawinan" value="Bercerai"><span>Bercerai</span>
									<span class="error">
										</span>
									
									<h5><label for="sm_sbbmati">Sebab Kematian</label></h5>
									<input type="radio" name="sm_sbbmati" value="Biasa"><span>Biasa</span>
									<input type="radio" name="sm_sbbmati" value="Kemalangan"><span>Kemalangan</span>
									<span class="error">
										</span>
									
                                    <h5><label for="sm_warganegara">Warganegara</label></h5>
									<input type="radio" name="sm_warganegara" value="Malaysia"><span>Malaysia</span>
									<input type="radio" name="sm_warganegara" value="Lain-lain"><span>Lain-lain</span>
									<span class="error">
										</span>
									
									<h5><label for="sm_agama">Agama</label></h5>
									<input type="radio" name="sm_agama" value="Islam"><span>Islam</span>
									<input type="radio" name="sm_agama" value="Buddha"><span>Buddha</span>
									<input type="radio" name="sm_agama" value="Kristian"><span>Kristian</span>
									<input type="radio" name="sm_agama" value="Hindu"><span>Hindu</span>
									<input type="radio" name="sm_agama" value="Lain-lain"><span>Lain-lain</span>
									<span class="error">
										</span>
									
									<h5><label for="sm_bangsa">Bangsa</label></h5>
									<input type="radio" name="sm_bangsa" value="Melayu"><span>Melayu</span>
									<input type="radio" name="sm_bangsa" value="Cina"><span>Cina</span>
									<input type="radio" name="sm_bangsa" value="India"><span>India</span>
									<span class="error">
										</span>
									
									<h5><label for="sm_muflis">Muflis</label></h5>
									<input type="radio" name="sm_muflis" value="Ya"><span>Ya</span>
									<input type="radio" name="sm_muflis" value="Tidak"><span>Tidak</span>
									<span class="error">
										</span>
									<p><input type="submit" name="btn_updatesimati" value="Submit"></p>
								</div>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	// p_hubungan
	var sm_jantina = `<?php echo $row['sm_jantina']; ?>`;
	var sm_taraf_perkhawinan = `<?php echo $row['sm_taraf_perkhawinan']; ?>`;
	var sm_sbbmati = `<?php echo $row['sm_sbbmati']; ?>`;
	var sm_warganegara = `<?php echo $row['sm_warganegara']; ?>`;
	var sm_agama = `<?php echo $row['sm_agama']; ?>`;
	var sm_bangsa = `<?php echo $row['sm_bangsa']; ?>`;
	var sm_muflis = `<?php echo $row['sm_muflis']; ?>`;

	$('input:radio[name="sm_jantina"]').filter('[value="'+sm_jantina+'"]').attr('checked', true);
	$('input:radio[name="sm_taraf_perkhawinan"]').filter('[value="'+sm_taraf_perkhawinan+'"]').attr('checked', true);
	$('input:radio[name="sm_sbbmati"]').filter('[value="'+sm_sbbmati+'"]').attr('checked', true);
	$('input:radio[name="sm_warganegara"]').filter('[value="'+sm_warganegara+'"]').attr('checked', true);
	$('input:radio[name="sm_agama"]').filter('[value="'+sm_agama+'"]').attr('checked', true);
	$('input:radio[name="sm_bangsa"]').filter('[value="'+sm_bangsa+'"]').attr('checked', true);
	$('input:radio[name="sm_muflis"]').filter('[value="'+sm_muflis+'"]').attr('checked', true);
</script>