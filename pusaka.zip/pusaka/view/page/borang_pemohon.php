    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title">
                    <h3>Borang Permohonan Perkhidmatan Pentadbiran Harta Pusaka</h3>
                </div>

				<?php include ('../view/progressbarr.php')?>
				
                <div class="row">
                    <div class="col-md-12">
                        <h4><strong>1.0 Keterangan Pemohon</strong></h4>
                        <form action="../../epusaka/controller/functions.php" method="post">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="left-side-form">
                                        <h5><label for="p_nama">Nama Penuh/ (Seperti Dalam Kad Pengenalan)</label>
                                        <span class="error"></span></h5>
                                        <p><input type="text" name="p_nama" value=""></p>
                                        
                                        <h5><label for="p_nric_new">No. KP. Baru</label><span class="error">
                                                </span></h5>
                                        <p><input type="text" name="p_nric_new" value=""></p>
                                        
                                        <h5><label for="p_nric_old">No. KP Lama/Polis/Tentera/No. Pasport</label><span class="error">
                                                </span></h5>
                                        <p><input type="text" name="p_nric_old" value=""></p>

                                        <h5><label for="p_age">Umur</label><span class="error">
                                                </span></h5>
                                        <p><input type="text" name="p_age" value=""></p>

                                        <h5><label for="p_birthdate">Tarikh Lahir</label><span class="error">
                                                </span></h5>
                                        <p><input type="date" name="p_birthdate" value=""></p>

                                        <h5><label for="p_tel_rumah">No. Tel Rumah</label><span class="error">
                                                </span></h5>
                                        <p><input type="text" name="p_tel_rumah" value=""></p>
                                        
                                        <h5><label for="p_tel_bimbit">No. Tel Bimbit</label><span class="error">
                                                </span></h5>
                                        <p><input type="text" name="p_tel_bimbit" value=""></p>
                                        
                                        <h5><label for="p_tel_pejabat">No. Tel Pejabat</label><span class="error">
                                                </span></h5>
                                        <p><input type="text" name="p_tel_pejabat" value=""></p>
                                        
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="right-side-form">

                                        <h5><label for="p_alamat_surat">Alamat Surat Menyurat </label><span class="error">
                                                </span></h5>
                                        <p><textarea name="p_alamat_surat" ></textarea></p>

                                        <h5><label for="p_poskod_surat">Poskod Surat Menyurat</label><span class="error">
                                                </span></h5>
                                        <p><input type="text" name="p_poskod_surat" value=""></p>

                                        <h5><label for="p_negeri_surat">Negeri Surat Menyurat</label><span class="error">
                                                </span></h5>
                                        <p><input type="text" name="p_negeri_surat" value=""></p>

                                        <h5><label for="p_alamat">Alamat Tetap</label><span class="error">
                                                </span></h5>
                                        <p><textarea name="p_alamat"></textarea></p>

                                        <h5><label for="p_poskod">Poskod Alamat Tetap</label><span class="error">
                                                </span></h5>
                                        <p><input type="text" name="p_poskod" value=""></p>

                                        <h5><label for="p_negeri">Negeri Alamat Tetap</label><span class="error">
                                                </span></h5>
                                        <p><input type="text" name="p_negeri" value="">

                                        <h5><label for="p_hubungan">Perhubungan Persaudaraan Dengan Simati</label></h5>
                                        <input type="radio" name="p_hubungan" value="Suami"><span>Suami</span>
                                        <input type="radio" name="p_hubungan" value="Isteri"><span>Isteri</span>
                                        <input type="radio" name="p_hubungan" value="Bapa"><span>Bapa</span>
                                        <input type="radio" name="p_hubungan" value="Ibu"><span>Ibu</span>
                                        <input type="radio" name="p_hubungan" value="Anak"><span>Anak</span>
                                        <input type="radio" name="p_hubungan" value="Lain-lain"><span>Lain-lain</span>
                                        <span class="error">
                                            </span>
                                        
                                        <p><input type="submit" name="btn_mohon" value="Submit"></p>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>