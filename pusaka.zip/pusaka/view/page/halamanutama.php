<?php $arrayStatus = array(
	0 => "Buka Fail",
	1 => "Dokumentasi",
	2 => "La / probate",
	3 => "Pencairan",
	4 => "Pembahagian",
	5 => "Tutup Fail"
);

$set = array();
$j = 0;
while ($row = $result->fetch_assoc()){
	$set[$j] = $row;
	$j++;
}

?>
<div class="container">
				<div class="row clearfix progress-box">
					<?php 
					$i = 1;
					
					foreach ($arrayStatus as $key => $value) {
						$flag = '';
						foreach ($set as $key1 => $value1){
							if ($value == $value1['m_status']) {
								// echo $i;
								// echo $value;
								// echo $value1['m_status'];
								$flag = "yes";
					?>
								<div class="col-lg-3 col-md-6 col-sm-12 mb-30">
									<div class="card-box pd-30 height-100-p">
										<div class="progress-box text-center">
											<input
												type="text"
												class="knob dial<?php echo $i?>"
												value="<?php echo $value1['percentage'];?>"
												data-width="120"
												data-height="120"
												data-linecap="round"
												data-thickness="0.12"
												data-bgColor="#fff"
												data-fgColor="#1b00ff"
												data-angleOffset="180"
												readonly
											/>
											<h5 class="text-blue padding-top-10 h5"><?php echo $value;?></h5>
											<span class="d-block"
												><?php echo $value1['percentage'];?>% Average <i class="fa fa-line-chart text-blue"></i
											></span>
										</div>
									</div>
								</div>
					<?php 
							}
						}
						if ($flag != "yes") {
							?>
							<div class="col-lg-3 col-md-6 col-sm-12 mb-30">
									<div class="card-box pd-30 height-100-p">
										<div class="progress-box text-center">
											<input
												type="text"
												class="knob dial<?php echo $i?>"
												value="0"
												data-width="120"
												data-height="120"
												data-linecap="round"
												data-thickness="0.12"
												data-bgColor="#fff"
												data-fgColor="#1b00ff"
												data-angleOffset="180"
												readonly
											/>
											<h5 class="text-blue padding-top-10 h5"><?php echo $value;?></h5>
											<span class="d-block"
												>0% Average <i class="fa fa-line-chart text-blue"></i
											></span>
										</div>
									</div>
								</div>
							<?php
						}
						// echo $flag;
						$i++;
					}
					?>
					<!-- <div class="col-lg-3 col-md-6 col-sm-12 mb-30">
						<div class="card-box pd-30 height-100-p">
							<div class="progress-box text-center">
								<input
									type="text"
									class="knob dial2"
									value="70"
									data-width="120"
									data-height="120"
									data-linecap="round"
									data-thickness="0.12"
									data-bgColor="#fff"
									data-fgColor="#1b00ff"
									data-angleOffset="180"
									readonly
								/>
								<h5 class="text-blue padding-top-10 h5">
									Dokumentasi
								</h5>
								<span class="d-block"
									>75% Average <i class="fa text-blue fa-line-chart"></i
								></span>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-12 mb-30">
						<div class="card-box pd-30 height-100-p">
							<div class="progress-box text-center">
								<input
									type="text"
									class="knob dial3"
									value="90"
									data-width="120"
									data-height="120"
									data-linecap="round"
									data-thickness="0.12"
									data-bgColor="#fff"
									data-fgColor="#1b00ff"
									data-angleOffset="180"
									readonly
								/>
								<h5 class="text-blue padding-top-10 h5">
									LA / Probate
								</h5>
								<span class="d-block"
									>90% Average <i class="fa text-blue fa-line-chart"></i
								></span>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-12 mb-30">
						<div class="card-box pd-30 height-100-p">
							<div class="progress-box text-center">
								<input
									type="text"
									class="knob dial4"
									value="65"
									data-width="120"
									data-height="120"
									data-linecap="round"
									data-thickness="0.12"
									data-bgColor="#fff"
									data-fgColor="#1b00ff"
									data-angleOffset="180"
									readonly
								/>
								<h5 class="text-blue padding-top-10 h5">
									Pencairan
								</h5>
								<span class="d-block"
									>65% Average <i class="fa text-blue fa-line-chart"></i
								></span>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-12 mb-30">
						<div class="card-box pd-30 height-100-p">
							<div class="progress-box text-center">
								<input
									type="text"
									class="knob dial2"
									value="70"
									data-width="120"
									data-height="120"
									data-linecap="round"
									data-thickness="0.12"
									data-bgColor="#fff"
									data-fgColor="#1b00ff"
									data-angleOffset="180"
									readonly
								/>
								<h5 class="text-blue padding-top-10 h5">
									Pembahagian
								</h5>
								<span class="d-block"
									>75% Average <i class="fa text-blue fa-line-chart"></i
								></span>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-12 mb-30">
						<div class="card-box pd-30 height-100-p">
							<div class="progress-box text-center">
								<input
									type="text"
									class="knob dial2"
									value="70"
									data-width="120"
									data-height="120"
									data-linecap="round"
									data-thickness="0.12"
									data-bgColor="#fff"
									data-fgColor="#1b00ff"
									data-angleOffset="180"
									readonly
								/>
								<h5 class="text-blue padding-top-10 h5">
									Tutup Fail
								</h5>
								<span class="d-block"
									>75% Average <i class="fa text-blue fa-line-chart"></i
								></span>
							</div>
						</div>
					</div> -->
				</div>

		</div>