<?php 
    // var_dump($GLOBALS["senarai_pemohon"]);
    // $senarai_pemohon = $GLOBALS["senarai_pemohon"];
    // echo json_encode($senarai_pemohon);
    // var_dump($senarai_pemohon);
?>
<div class="form-area">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="section-title">
		<h3>Senarai Pemohon</h3>
        <table>
            <thead>
                <tr>
                    <th>Bil.</th>
                    <th>Nama Pemohon</th>
                    <th>No. Kad Pengenalan</th>
                    <th>Bilangan Pusaka</th>
					<th>Lihat</th>
                    <!-- <th>ID</th> -->
					<!-- <th>Padam</th> -->
                </tr>
            </thead>
            <tbody>
                <?php $i = 1; while ($row = $result->fetch_assoc()){?>
                <tr>
                    <td><?php echo $i; ?></td>
                    <td><?php echo $row['p_nama']; ?></td>
                    <td><?php echo $row['p_nric_new']; ?></td>
                    <td><?php echo $row['bil_pusaka']; ?></td>
                    <td><a class="btn btn-primary btn-sm" href="#" onclick="onclick_view(<?php echo $row['p_id']; ?>)">View</a></td>
                    <!-- <td><?php echo $row['id']; ?></button></td> -->
					<!-- <td><button>X</button></td> -->
                </tr>
                <?php $i++; }
                $result -> free_result();
                $conn -> close();
                ?>
                </tbody>
                </table>
            </div>
		</div>
        <?php
    require "pop-up.php";
    ?>
	</div>
</div>
</div>