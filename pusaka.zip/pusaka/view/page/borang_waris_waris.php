<?php
	if (isset($_GET['simati']) && ($_GET['simati'] != '' || $_GET['simati'] != null)) {
		$id = $_GET['simati'];
	}else{
		$base_url = base_url();
		$url = $base_url."/epusaka/view/senarai_pemohon.php";
		// redirect($url);
		echo "<script> window.location.href = `$url`; </script>;";
	}
?>
<div class="container">
	<form action="../../epusaka/controller/functions.php" method="post">
		<div class="section-title">
			<h3>Borang Permohonan Perkhidmatan Pentadbiran Harta Pusaka</h3>
		</div>
		<?php include ('../view/progressbarr.php')?> 
		<h4 class="p-2 mb-3">
			<strong>7.0 Keterangan Mengenai Benefisiari & <br> 8.0 Waris-Waris Simati Yang Dinamakan Di Dalam Wasiat</strong>
			<a href="javascript:void(0);" class="add_button btn btn-primary btn-sm float-right mx-2" title="Add field">Tambah Waris <i class="fa fa-plus"></i>
			</a>
		</h4>
		<div class="row field_wrapper p-2">
			<div class="row col-md-12 mb-2">
				<div class="col-md-12 mb-2">
					<input type="hidden" name="sm_id" value="<?php echo $id;?>">
					<label for="exampleFormControlSelect2">Jenis Waris</label>
				    <select class="form-control" id="exampleFormControlSelect2" name="ww_waris_type[]" required>
				      <option disabled selected>Pilih Jenis Waris</option>
				      <option value="1">Benefisiari</option>
				      <option value="2">Waris</option>
				      <option value="3">Benefisiari & Waris</option>
				    </select>
				</div>
				<div class="col-md-6 m-0">
					<div class="left-side-form m-0 p-0">
						<h5 class="m-0 p-0">
							<label for="nama">Nama Penuh/ (Seperti Dalam Kad Pengenalan)</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_nama[]" value="">
						</p>
						<h5 class="m-0 p-0">
							<label for="nokp">Hubungan</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_hubungan[]" value="">
						</p>
						<h5 class="m-0 p-0">
							<label for="nokplama">No. KP</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_nric[]" value="">
						</p>
						<h5 class="m-0 p-0">
							<label for="sm_tmptmati">Alamat</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<textarea name="ww_alamat[]" class="m-0"></textarea>
						</p>
					</div>
				</div>
				<div class="col-md-6 m-0">
					<div class="right-side-form m-0 p-0">
						<h5 class="m-0 p-0">
							<label for="nama">No. Telefon Bimbit</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_notel_rumah[]" value="">
						</p>
						<h5 class="m-0 p-0">
							<label for="nokp">No. Telefon Rumah</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_notel_pejabat[]" value="">
						</p>
						<h5 class="m-0 p-0">
							<label for="nokplama">No. Telefon Pejabat</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_notel_bimbit[]" value="">
						</p>
						<h5 class="m-0 p-0">
							<label for="nokplama">Emel</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_emel[]" value="">
						</p>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-6">
				<div class="left-side-form">
					<!-- <p><input type="submit" class="float-right" name="btn_borang_harta" value="Submit"></p> -->
				</div>
			</div>
			<div class="col-md-6">
				<div class="right-side-form">
					<p>
						<input type="submit" class="float-right" name="btn_borang_benefisiari" value="Submit">
					</p>
				</div>
			</div>
		</div>
	</form>
</div>
<script type="text/javascript">
$(document).ready(function(){
    var maxField = 50; //Input fields increment limitation
    var addButton = $('.add_button'); //Add button selector
    var wrapper = $('.field_wrapper'); //Input field wrapper
    var x = 1; //Initial field counter is 1
    var fieldHTML = `<div class="row col-md-12 mb-2 mt-4">
				<div class="col-md-12 mb-2">
					<input type="hidden" name="p_id" value="<?php echo $id;?>">
					<label for="exampleFormControlSelect2">Jenis Waris</label>
				    <select class="form-control" id="exampleFormControlSelect2" name="ww_waris_type[]" required>
				      <option disabled selected>Pilih Jenis Waris</option>
				      <option value="1">Benefisiari</option>
				      <option value="2">Waris</option>
				      <option value="3">Benefisiari & Waris</option>
				    </select>
					<a href="javascript:void(0);" class="remove_button btn btn-danger btn-sm float-right" title="Add field"><i class="fa fa-minus"></i></a>
				</div>
				<div class="col-md-6 m-0">
					<div class="left-side-form m-0 p-0">
						<h5 class="m-0 p-0">
							<label for="nama">Nama Penuh/ (Seperti Dalam Kad Pengenalan)</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_nama[]" value="">
						</p>
						<h5 class="m-0 p-0">
							<label for="nokp">Hubungan</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_hubungan[]" value="">
						</p>
						<h5 class="m-0 p-0">
							<label for="nokplama">No. KP</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_nric[]" value="">
						</p>
						<h5 class="m-0 p-0">
							<label for="sm_tmptmati">Alamat</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<textarea name="ww_alamat[]" class="m-0"></textarea>
						</p>
					</div>
				</div>
				<div class="col-md-6 m-0">
					<div class="right-side-form m-0 p-0">
						<h5 class="m-0 p-0">
							<label for="nama">No. Telefon Bimbit</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_notel_rumah[]" value="">
						</p>
						<h5 class="m-0 p-0">
							<label for="nokp">No. Telefon Rumah</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_notel_pejabat[]" value="">
						</p>
						<h5 class="m-0 p-0">
							<label for="nokplama">No. Telefon Pejabat</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_notel_bimbit[]" value="">
						</p>
						<h5 class="m-0 p-0">
							<label for="nokplama">Emel</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_emel[]" value="">
						</p>
					</div>
				</div>
			</div>`; //New input field html 
    
    //Once add button is clicked
    $(addButton).click(function(){
        //Check maximum number of input fields
        if(x < maxField){ 
            x++; //Increment field counter
            $(wrapper).append(fieldHTML); //Add field html
        }
    });
    
    //Once remove button is clicked
    $(wrapper).on('click', '.remove_button', function(e){
        e.preventDefault();
        console.log( $(this).parent());
        $(this).parent().parent('div').remove(); //Remove field html
        x--; //Decrement field counter
    });

});

function floatNumberField(){
	$(".floatNumberField").change(function() {
        $(this).val(parseFloat($(this).val()).toFixed(2));
    });
}
</script>