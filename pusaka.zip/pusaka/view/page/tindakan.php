<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="section-title">
		<h3>Tindakan </h3>
        <table>
            <thead>
				<h4><em>Samat Bin Khaled(no ic)</em></h4>
                <tr>
                    <th>Tarikh</th>
                    <th>Penerangan</th>
                    <th>No. Kad Pengenalan</th>
					<th>Status Terkini</th>
                    <th>Bukti Status(Muat Naik Dokumen)</th>
                    <th>Pegawai</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>(1/Mac/2022)</td>
                    <td>//penerangan staff//</td>
                    <td>780905-14-0460</td>
					<td>
					<form action="/action_page.php">
					<input list="browsers" name="browser">
                    <datalist id="browsers">
					<option value="Buka Fail">
                    <option value="Dokumentasi">
                    <option value="LA / Probate">
                    <option value="Pencairan">
                    <option value="Pembahagian">
                    <option value="Tutup Fail">
						</datalist>
						</form>
					</td>
                    <td><button>Muat Naik</button></td>
					<td>((nama staff yg kemaskini auto kelua detect pkai emel))</td>
				</tr>
            </tbody>
        </table>
					<input type="submit" name="submit" value="Submit">
    </div>
			</div>
		</div>
	</div>