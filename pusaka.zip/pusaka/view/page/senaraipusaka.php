
<div class="container">
	<div class="row mb-2">
		<div class="col-md-12">
			<div class="section-title">
				
            	<h3>Senarai Pusaka <?php 
                            
                            if (isset($_GET['idpemohon']) && ($_GET['idpemohon'] != '' || $_GET['idpemohon'] != null)) {
                                $id = $_GET['idpemohon'];
                                echo '<a href="borang_simati.php?pemohon='.$id.'" class="btn btn-sm btn-primary m-2"><i class="fa fa-plus"></i></a></h3>';
                            }

                        ?>
                    </h3>

                <table id="myTable" class="">
                    <thead>
                        <tr>
                            <th>No. Fail</th>
                            <th>Nama Simati</th>
                            <th>No. Kad Pengenalan</th>
                            <th>Status Terkini </th>
                            <th>Keterangan Terperinci </th>
            				<th>Kemaskini </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            $i = 1; while ($row = $result->fetch_assoc()){
                            if (isset($_GET['idpemohon']) && ($_GET['idpemohon'] != '' || $_GET['idpemohon'] != null)) {
                                $id = $_GET['idpemohon'];
                                if ($row['p_id'] != $id) {
                                    continue;
                                }
                            }

                        ?>
                        <tr>
                            <td><a href="../view/borang_view.php?simati=<?php echo $row['id']; ?>" class="btn btn-primary btn-sm"><?php echo $row['m_nofail']?></a></td>
                            <td><?php echo $row['sm_nama']; ?></td>
                            <td><?php echo $row['sm_nric_new']; ?></td>
                            <td><?php echo $row['m_status']; ?></td>
            				<td><?php echo $row['m_keterangan']; ?></td>
                            <td>
                                <a href="../view/update_pemohon.php?simati=<?php echo $row['id']; ?>" class="btn btn-secondary btn-sm">Kemaskini</a>
            				    <!-- Button trigger modal -->
                                <button type="button" class="btn btn-info btn-sm" onclick="updateStatus(`<?php echo $row['m_nofail']; ?>`, `<?php echo $row['m_status']; ?>`);">
                                  + Status
                                </button>
                            </td>
                        </tr>
                        <?php $i++; }
                        $result -> free_result();
                        $conn -> close();
                        ?>
                    </tbody>
                </table>
            </div>
		</div>
	</div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Kemaskini Status Si Mati</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="../../epusaka/controller/functions.php" method="post">
          <div class="modal-body">
            
                <input type="hidden" name="m_nofail" id="idval">
                <div class="form-group">
                    <select class="custom-select" required id="select_status" name="m_status">
                        <!-- <option disabled selected value="">Pilih status...</option> -->
                        <option value="Buka Fail">Buka Fail</option>
                        <option value="Dokumentasi">Dokumentasi</option>
                        <option value="La / probate">La / probate</option>
                        <option value="Pencairan">Pencairan</option>
                        <option value="Pembahagian">Pembahagian</option>
                        <option value="Tutup Fail">Tutup Fail</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="exampleFormControlTextarea1">Keterangan</label>
                    <input type="text" class="form-control" required name=" m_keterangan">
                </div>

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <!-- <button type="submit" value="hantar" class="btn btn-primary" >Kemaskini Status</button> -->
            <input type="submit" class="float-right" name="btn_update_status" value="Kemaskini Status">
          </div>
      </form>
    </div>
  </div>
</div>

<script type="text/javascript">
    $(document).ready( function () {
        $('#myTable').DataTable();
    } );
    function updateStatus(id, status){
        console.log(id);
        console.log(status);
        $('#exampleModal').modal('show');
        $('#idval').val(id);
        $('#select_status option[value="'+status+'"]').attr('selected','selected');
    }
    
</script>