<?php
	if (isset($_GET['simati']) && ($_GET['simati'] != '' || $_GET['simati'] != null)) {
		$id = $_GET['simati'];
	}else{
		$base_url = base_url();
		$url = $base_url."/epusaka/view/senarai_pemohon.php";
		// redirect($url);
		echo "<script> window.location.href = `$url`; </script>;";
	}

	$row_pemohon = $result_pemohon->fetch_assoc();
	// var_dump();

?>
<div class="container mb-2" id="printContent">
	<div class="row pagebreak mb-2 mt-2">
		<div class="col-md-12">
			<div class="section-title">
				<h3>1.0 Keterangan Pemohon</h3>
			</div>
			<div class="row">
				<div class="col-md-6">
					<div class="left-side-form">
						<h5>Nama Penuh/ (Seperti Dalam Kad Pengenalan) <span class="error"></span></h5>
						<p><?php echo $row_pemohon['p_nama']; ?></p>
						<h5>No. KP. Baru <span class="error"></span></h5>
						<p><?php echo $row_pemohon['p_nric_new']; ?></p>
						<h5>No. KP Lama/Polis/Tentera/No. Pasport <span class="error"></span></h5>
						<p><?php echo $row_pemohon['p_nric_old']; ?></p>
						<h5>Umur <span class="error"></span></h5>
						<p><?php echo $row_pemohon['p_age']; ?></p>
						<h5>Tarikh Lahir <span class="error"></span></h5>
						<p><?php echo $row_pemohon['p_birthdate']; ?></p>
						<h5>No. Tel Rumah <span class="error"></span></h5>
						<p><?php echo $row_pemohon['p_tel_rumah']; ?></p>
						<h5>No. Tel Bimbit <span class="error"></span></h5>
						<p><?php echo $row_pemohon['p_tel_bimbit']; ?></p>
						<h5>No. Tel Pejabat <span class="error"></span></h5>
						<p><?php echo $row_pemohon['p_tel_pejabat']; ?></p>
					</div>
				</div>
				<div class="col-md-6">
					<div class="right-side-form">
						<h5>Alamat Surat Menyurat <span class="error"></span></h5>
						<p><?php echo $row_pemohon['p_alamat_surat']; ?></p>
						<h5>Poskod Surat Menyurat <span class="error"></span></h5>
						<p><?php echo $row_pemohon['p_poskod_surat']; ?></p>
						<h5>Negeri Surat Menyurat <span class="error"></span></h5>
						<p><?php echo $row_pemohon['p_negeri_surat']; ?></p>
						<h5>Alamat Tetap <span class="error"></span></h5>
						<p><?php echo $row_pemohon['p_alamat']; ?></p>
						<h5>Poskod Alamat Tetap <span class="error"></span></h5>
						<p><?php echo $row_pemohon['p_poskod']; ?></p>
						<h5>Negeri Alamat Tetap <span class="error"></span></h5>
						<p><?php echo $row_pemohon['p_negeri']; ?></p>
						<h5>Perhubungan Persaudaraan Dengan Simati <span class="error"></span></h5>
						<p><?php echo $row_pemohon['p_hubungan']; ?></p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="row pagebreak mb-2 mt-2">
		<div class="col-md-12"><br>
			<div class="section-title">
				<h3>2.0 Keterangan Mengenai Simati</h3>
			</div>
			<div class="row">
				<div class="col-md-6">
					<div class="left-side-form">
						<h5>Nama Penuh/ (Seperti Dalam Kad Pengenalan) <span class="error"></span></h5>
						<p><?php echo $row_pemohon['sm_nama']; ?></p>
						<h5>No. KP Baru <span class="error"></span></h5>
						<p><?php echo $row_pemohon['sm_nric_new']; ?></p>
						<h5>No. KP Lama/Polis/Tentera/No. Pasport <span class="error"></span></h5>
						<p><?php echo $row_pemohon['sm_nric_old']; ?></p>
						<h5>Jantina <span class="error"></span></h5>
						<p><?php echo $row_pemohon['sm_jantina']; ?></p>
						<h5>Tarikh Meninggal Dunia <span class="error"></span></h5>
						<p><?php echo $row_pemohon['sm_datemati']; ?></p>
						<h5>Tempat Kematian <span class="error"></span></h5>
						<p><?php echo $row_pemohon['sm_tmptmati']; ?></p>
					</div>
				</div>
				<div class="col-md-6">
					<div class="right-side-form">
						<h5>Taraf Perkhawinan <span class="error"></span></h5>
						<p><?php echo $row_pemohon['sm_taraf_perkhawinan']; ?></p>
						<h5>Sebab Kematian <span class="error"></span></h5>
						<p><?php echo $row_pemohon['sm_sbbmati']; ?></p>
						<h5>Warganegara <span class="error"></span></h5>
						<p><?php echo $row_pemohon['sm_warganegara']; ?></p>
						<h5>Agama <span class="error"></span></h5>
						<p><?php echo $row_pemohon['sm_agama']; ?></p>
						<h5>Bangsa <span class="error"></span></h5>
						<p><?php echo $row_pemohon['sm_warganegara']; ?></p>
						<h5>Muflis <span class="error"></span></h5>
						<p><?php echo $row_pemohon['sm_muflis']; ?></p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="row pagebreak mb-2 mt-2">
		<div class="col-md-12">
			<div class="section-title">
				<h3>3.0 Keterangan Mengenai Wasiat</h3>
			</div>
			<h5>Wasiat Bertulis / Wasiat Lisan <span class="error"></span></h5>
			<p><?php echo $row_pemohon['iw_jenis']; ?></p>
			<h5>No. Pendaftaran Wasiat : <span class="error"></span></h5>
			<p><?php echo $row_pemohon['iw_nopendaftaran']; ?></p>
			<h5>Wasi : <span class="error"></span></h5>
			<p><?php echo $row_pemohon['iw_wasi']; ?></p>
			<h5>Tempat Menyimpan Wasiat : <span class="error"></span></h5>
			<p><?php echo $row_pemohon['iw_tmptsimpan']; ?></p>
		</div>
		<div class="col-md-12">
			<div class="section-title">
				<h3>3.1 Keterangan Mengenai Wasi</h3>
			</div>
			<div class="row">
				<div class="col-md-6">
					<div class="left-side-form">
						<h5>Nama Penuh/ (Seperti Dalam Kad Pengenalan) <span class="error"></span></h5>
						<p><?php echo $row_pemohon['iw_nama']; ?></p>
						<h5>No. KP Baru <span class="error"></span></h5>
						<p><?php echo $row_pemohon['iw_nric_new']; ?></p>
						<h5>No. KP Lama/Polis/Tentera/No. Pasport <span class="error"></span></h5>
						<p><?php echo $row_pemohon['iw_nric_old']; ?></p>
						<h5>Umur <span class="error"></span></h5>
						<p><?php echo $row_pemohon['iw_umur']; ?></p>
						<h5>Tarikh Lahir <span class="error"></span></h5>
						<p><?php echo $row_pemohon['iw_birthdate']; ?></p>
						<h5>Alamat Surat Menyurat <span class="error"></span></h5>
						<p><?php echo $row_pemohon['iw_alamat_surat']; ?></p>
						<h5>Negeri <span class="error"></span></h5>
						<p><?php echo $row_pemohon['iw_surat_negeri']; ?></p>
						<h5>Alamat Tetap <span class="error"></span></h5>
						<p><?php echo $row_pemohon['iw_alamat_tetap']; ?></p>
						<h5>Poskod <span class="error"></span></h5>
						<p><?php echo $row_pemohon['iw_poskod']; ?></p>
						<h5>Negeri <span class="error"></span></h5>
						<p><?php echo $row_pemohon['iw_negeri']; ?></p>
					</div>
				</div>
				<div class="col-md-6">
					<div class="right-side-form">
						<h5>No.Tel Rumah <span class="error"></span></h5>
						<p><?php echo $row_pemohon['iw_tel_rumah']; ?></p>
						<h5>No. Tel Pejabat <span class="error"></span></h5>
						<p><?php echo $row_pemohon['iw_tel_pjbt']; ?></p>
						<h5>No. Tel Bimbit <span class="error"></span></h5>
						<p><?php echo $row_pemohon['iw_tel_bimbit']; ?></p>
						<h5>E-mel <span class="error"></span></h5>
						<p><?php echo $row_pemohon['iw_emel']; ?></p>
						<h5>Perhubungan Persaudaraan Dengan Simati <span class="error"></span></h5>
						<p><?php echo $row_pemohon['iw_hubungan']; ?></p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="row pagebreak mb-2 mt-2">
		<div class="col-md-12">
			<div class="section-title">
				<h3>4.0 Keterangan Mengenai Harta Si Mati</h3>
			</div>
		</div>
		<div class="col-md-12">
			<h5>
				<strong>4.1 Harta Tak Alih</strong> (Contoh: Tanah/Rumah)
			</h5>
			<table class="table">
				<thead>
					<tr>
						<th>Jenis Hak Milik</th>
						<th>No. Hak Milik</th>
						<th>No. Lot</th>
						<th>Mukim/ Bandar</th>
						<th>Daerah/ Negeri</th>
						<th>Bahagian</th>
						<th>Anggaran Nilai(RM)</th>
					</tr>
				</thead>
				<tbody>
					<?php  $i = 1; while ($row_hartaxalih = $result_hartaxalih->fetch_assoc()){ ?>
					<tr>
						<td><?php echo $row_hartaxalih['hx_jenis']?></td>
						<td><?php echo $row_hartaxalih['hx_no_hakmilik']?></td>
						<td><?php echo $row_hartaxalih['hx_no_lot']?></td>
						<td><?php echo $row_hartaxalih['hx_mukim_bandar']?></td>
						<td><?php echo $row_hartaxalih['hx_daerah_negeri']?></td>
						<td><?php echo $row_hartaxalih['hx_bahagian']?></td>
						<td><?php echo $row_hartaxalih['hx_anggaran']?></td>
					</tr>
					<?php $i++; } ?>
				</tbody>
			</table>
		</div>
		<div class="col-md-12">
			<div class="section-title">
				<h5>
					<strong>4.2 Harta Alih</strong> (Contoh: Tunai/Akaun Bank/Saham/KWSP/Kenderaan/Insuran/Takaful)
				</h5>
			</div>
			<div class="table-responsive">
				<table class="table">
					<thead>
						<tr>
							<th>Jenis Harta</th>
							<th>No. Akaun/No. Ahli/No. Pendaftaran/Dan Lain-lain</th>
							<th>Anggaran Nilai(RM)</th>
						</tr>
					</thead>
					<tbody>
						<?php  $i = 1; while ($row_hartaalih = $result_hartaalih->fetch_assoc()){ ?>
						<tr>
							<td><?php echo $row_hartaalih['ha_jenis']?></td>
							<td><?php echo $row_hartaalih['ha_no_akaun']?></td>
							<td><?php echo $row_hartaalih['ha_anggaran']?></td>
						</tr>
						<?php $i++; } ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<!-- hutang & penghutang -->
	<div class="row pagebreak mb-2 mt-2">
		<div class="col-md-12">
			<div class="section-title">
				<h3>5.0 Keterangan Mengenai Hutang Si Mati</h3>
			</div>
			<div class="table-responsive">
				<table class="table">
					<thead>
						<tr>
							<th>Jenis Hutang</th>
							<th>Nama dan Alamat Pemiutang</th>
							<th>Anggaran Nilai(RM)</th>
						</tr>
					</thead>
					<tbody>
						<?php  $i = 1; while ($row_hutangsimati = $result_hutangsimati->fetch_assoc()){ ?>
						<tr>
							<td><?php echo $row_hutangsimati['hs_jenis']?></td>
							<td><?php echo $row_hutangsimati['hs_nama_alamat']?></td>
							<td><?php echo $row_hutangsimati['hs_anggaran']?></td>
						</tr>
						<?php $i++; } ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<div class="row pagebreak mb-2 mt-2">
		<div class="col-md-12">
			<div class="section-title">
				<h3>6.0 Keterangan Mengenai Penghutang</h3>
				<div class="table-responsive">
					<table class="table">
						<thead>
							<tr>
								<th>Jenis Hutang</th>
								<th>Nama dan Alamat Penghutang</th>
								<th>Anggaran Nilai(RM)</th>
							</tr>
						</thead>
						<tbody>
							<?php  $i = 1; while ($row_r_penghutangsimati = $result_r_penghutangsimati->fetch_assoc()){ ?>
							<tr>
								<td><?php echo $row_r_penghutangsimati['ps_jenis']?></td>
								<td><?php echo $row_r_penghutangsimati['ps_nama_alamat']?></td>
								<td><?php echo $row_r_penghutangsimati['ps_anggaran']?></td>
							</tr>
							<?php $i++; } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
	<!-- benefisiari -->
	<div class="row pagebreak mb-2 mt-2">
		<div class="col-md-12">
			<div class="section-title">
				<h3>7.0 Keterangan Mengenai Benefisiari Yang Dinamakan Di Dalam Wasiat</h3>
			</div>
			<table class="table">
				<thead>
					<tr>
						<th>Nama Penuh/ (Seperti Dalam Kad Pengenalan)</th>
						<th>Hubungan</th>
						<th>No. KP</th>
						<th>Alamat</th>
						<th>No. Telefon Bimbit</th>
						<th>No. Telefon Rumah</th>
						<th>No. Telefon Pejabat</th>
						<th>Emel</th>
					</tr>
				</thead>
				<tbody>
					<?php  $i = 1; while ($row_r_waris_wasiatsimati = $result_r_waris_wasiatsimati->fetch_assoc()){ 
						if ($row_r_waris_wasiatsimati['ww_waris_type'] == 2) {
							continue;
						}
					?>
					<tr>
						<td><?php echo $row_r_waris_wasiatsimati['ww_nama']?></td>
						<td><?php echo $row_r_waris_wasiatsimati['ww_hubungan']?></td>
						<td><?php echo $row_r_waris_wasiatsimati['ww_nric']?></td>
						<td><?php echo $row_r_waris_wasiatsimati['ww_alamat']?></td>
						<td><?php echo $row_r_waris_wasiatsimati['ww_notel_bimbit']?></td>
						<td><?php echo $row_r_waris_wasiatsimati['ww_notel_rumah']?></td>
						<td><?php echo $row_r_waris_wasiatsimati['ww_notel_pejabat']?></td>
						<td><?php echo $row_r_waris_wasiatsimati['ww_emel']?></td>
					</tr>
					<?php $i++; } ?>
				</tbody>
			</table>
		</div>
	</div>
	<!-- Waris-waris -->
	<div class="row pagebreak mb-2 mt-2">
		<div class="col-md-12">
			<br>
			<div class="section-title">
				<h3>8.0 Keterangan Mengenai Waris-Waris Simati</h3>
			</div>
            <table class="table">
            	<thead>
            		<tr>
	            		<th>Nama Penuh/ (Seperti Dalam Kad Pengenalan)</th>
	            		<th>Hubungan</th>
	            		<th>No. KP</th>
	            		<th>Alamat</th>
	            		<th>No. Telefon Bimbit</th>
	            		<th>No. Telefon Rumah</th>
	            		<th>No. Telefon Pejabar</th>
	            		<th>Emel</th>
	            	</tr>
            	</thead>
		        <tbody>
					<?php  $i = 1; while ($row_r_waris_wasiatsimati1 = $result_r_waris_wasiatsimati1->fetch_assoc()){ 
						if ($row_r_waris_wasiatsimati1['ww_waris_type'] == 1) {
								continue;
						}
					?>
					<tr>
						<td><?php echo $row_r_waris_wasiatsimati1['ww_nama']?></td>
						<td><?php echo $row_r_waris_wasiatsimati1['ww_hubungan']?></td>
						<td><?php echo $row_r_waris_wasiatsimati1['ww_nric']?></td>
						<td><?php echo $row_r_waris_wasiatsimati1['ww_alamat']?></td>
						<td><?php echo $row_r_waris_wasiatsimati1['ww_notel_bimbit']?></td>
						<td><?php echo $row_r_waris_wasiatsimati1['ww_notel_rumah']?></td>
						<td><?php echo $row_r_waris_wasiatsimati1['ww_notel_pejabat']?></td>
						<td><?php echo $row_r_waris_wasiatsimati1['ww_emel']?></td>
					</tr>
					<?php $i++; } ?>
				</tbody>
    		</table>
		</div>
	</div>
	<!-- penjaga -->
	<div class="row pagebreak mb-2 mt-2">
		<div class="col-md-12">
			<div class="section-title">
				<h3>9.0 Keterangan Mengenai Penjaga (Jika ada waris Di Bawah Umur 18 Tahun / Tidak Sempurna Akal)</h3>
			</div>
			<div class="row">
				<div class="col-md-6">
					<div class="left-side-form">
						<h5>Nama Penuh/ (Seperti Dalam Kad Pengenalan) <span class="error"></span>
						</h5>
						<p><?php echo $row_pemohon ['pw_nama']; ?></p>
						<h5>No. KP. Baru <span class="error"></span>
						</h5>
						<p><?php echo $row_pemohon ['pw_nric_new']; ?></p>
						<h5>No. KP Lama/Polis/Tentera/No. Pasport <span class="error"></span>
						</h5>
						<p><?php echo $row_pemohon ['pw_nric_old']; ?></p>
						<h5>Umur <span class="error"></span>
						</h5>
						<p><?php echo $row_pemohon ['pw_umur']; ?></p>
						<h5>Tarikh Lahir <span class="error"></span>
						</h5>
						<p><?php echo $row_pemohon ['pw_birthdate']; ?></p>
						<h5>Alamat Tetap <span class="error"></span>
						</h5>
						<p><?php echo $row_pemohon ['pw_alamat_tetap']; ?></p>
						<h5>Poskod <span class="error"></span>
						</h5>
						<p><?php echo $row_pemohon ['pw_poskod']; ?></p>
						<h5>Negeri <span class="error"></span>
						</h5>
						<p><?php echo $row_pemohon ['pw_negeri']; ?></p>
					</div>
				</div>
				<div class="col-md-6">
					<div class="right-side-form">
						<h5>No. Tel Rumah <span class="error"></span>
						</h5>
						<p><?php echo $row_pemohon ['pw_notel_rumah']; ?></p>
						<h5>No. Tel Bimbit <span class="error"></span>
						</h5>
						<p><?php echo $row_pemohon ['pw_notel_bimbit']; ?></p>
						<h5>No. Tel Pejabat <span class="error"></span>
						</h5>
						<p><?php echo $row_pemohon ['pw_notel_pjbt']; ?></p>
						<h5>Emel <span class="error"></span>
						</h5>
						<p><?php echo $row_pemohon ['pw_emel']; ?></p>
						<h5>Perhubungan Persaudaraan Dengan Simati <span class='error'></span>
						</h5>
						<p><?php echo $row_pemohon ['pw_hubungan']; ?></p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- akuan -->
    <div class="row pagebreak mb-2 mt-2">
      	<div class="col-md-12">
       		<div class="section-title">
         		<h3>10.0 Akuan</h3>
       		</div>
    		<div class="mt-5">
          			<h5>Saya, <strong><u><?php echo $row_pemohon['p_nama']; ?></u></strong> dengan sesungguhnya dan sebenarnya mengaku bahawa tuntutan pusaka ini belum pernah dibuat dan segala keterangan yang tersebut di atas adalah benar mengikut pengetahuan saya sendiri dan saya membuat akuan ini dengan kepercayaan bahawa apa-apa yang tersebut di dalamnya adalah benar, serta menurut Akta Akuan Berkanun 1960.</h5>
          	</div>

          	<div class="col-md-6">
        <div class="right-side-form">
			<br>
          <h5>Di Hadapan Saya <br>
            <br>
            <br> _______________________________________ <br>
            <strong>Tandatangan Hakim Mahkamah Saksyen/ Majistret/ Pesuruhjaya Sumpah</strong>
          </h5>
        </div>
		   <div><center><img src="../img/imageico.ico" alt="image/icon" class="center"></center>
		   <p2> 15-03 Tower A, Menara Prima, Jalan PJU 1/39, Dataran Prima, 47301 Petaling Jaya Selangor Malaysia 
			   <br> Tel : +603-7887 1120 | www.awarisgroup.com</p2>
		   </div> 
      	</div>
   	</div>
	<button class="btn btn-primary btn-sm noPrint" onclick="window.print()">Print</button>
</div>
