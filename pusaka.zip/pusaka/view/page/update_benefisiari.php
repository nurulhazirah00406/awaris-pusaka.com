<?php
	if (isset($_GET['simati']) && ($_GET['simati'] != '' || $_GET['simati'] != null)) {
		$id = $_GET['simati'];
	}else{
		$base_url = base_url();
		$url = $base_url."/epusaka/view/senarai_pemohon.php";
		// redirect($url);
		echo "<script> window.location.href = `$url`; </script>;";
	}

	// var_dump($result->fetch_assoc());
	// $row1 = $result1->fetch_assoc();
	// $row2 = $result2->fetch_assoc();

?>
<div class="container">
	<!-- benefisiari -->
	<div class="row pagebreak mb-2 mt-2">
		<div class="col-md-12">
			<div class="section-title">
				<h3>7.0 Keterangan Mengenai Benefisiari Yang Dinamakan Di Dalam Wasiat <button class="btn btn-sm btn-primary m-2" onclick='updateStatus("<?php echo $id;?>", 3);'><i class="fa fa-plus"></i></button></h3>
			</div>
			<table class="table">
				<thead>
					<tr>
						<th>Nama Penuh/ (Seperti Dalam Kad Pengenalan)</th>
						<th>Hubungan</th>
						<th>No. KP</th>
						<th>Alamat</th>
						<th>No. Telefon Bimbit</th>
						<th>No. Telefon Rumah</th>
						<th>No. Telefon Pejabat</th>
						<th>Emel</th>
						<th>Kemaskini</th>
					</tr>
				</thead>
				<tbody>
					<?php  $i = 1; $set = array(); while ($row_r_waris_wasiatsimati = $result_r_waris_wasiatsimati->fetch_assoc()){ $set[$i] = $row_r_waris_wasiatsimati;
						if ($row_r_waris_wasiatsimati['ww_waris_type'] == 2) {
							continue;
						}
					?>
					<tr>
						<td><?php echo $row_r_waris_wasiatsimati['ww_nama']?></td>
						<td><?php echo $row_r_waris_wasiatsimati['ww_hubungan']?></td>
						<td><?php echo $row_r_waris_wasiatsimati['ww_nric']?></td>
						<td><?php echo $row_r_waris_wasiatsimati['ww_alamat']?></td>
						<td><?php echo $row_r_waris_wasiatsimati['ww_notel_bimbit']?></td>
						<td><?php echo $row_r_waris_wasiatsimati['ww_notel_rumah']?></td>
						<td><?php echo $row_r_waris_wasiatsimati['ww_notel_pejabat']?></td>
						<td><?php echo $row_r_waris_wasiatsimati['ww_emel']?></td>
						<td><button class="btn btn-sm btn-info m-2" onclick='updateStatus("<?php echo $i;?>", 1);'><i class="fa fa-edit"></i></button><a href="../../epusaka/controller/functions.php?colname=ww_id &&page=update_benefisiari&&dlt_jenis=r_waris_wasiatsimati&&dlte=<?php echo $row_r_waris_wasiatsimati['ww_id'];?>&&idsimati=<?php echo $id;?>" class="btn btn-sm btn-danger m-2"><i class="fa fa-trash"></i></a></td>
					</tr>
					<?php $i++; } ?>
				</tbody>
			</table>
		</div>
	</div>
	<!-- Waris-waris -->
	<div class="row pagebreak mb-2 mt-2">
		<div class="col-md-12">
			<br>
			<div class="section-title">
				<h3>8.0 Keterangan Mengenai Waris-Waris Simati <button class="btn btn-sm btn-primary m-2" onclick='updateStatus("<?php echo $id;?>", 3);'><i class="fa fa-plus"></i></button></h3>
			</div>
            <table class="table">
            	<thead>
            		<tr>
	            		<th>Nama Penuh/ (Seperti Dalam Kad Pengenalan)</th>
	            		<th>Hubungan</th>
	            		<th>No. KP</th>
	            		<th>Alamat</th>
	            		<th>No. Telefon Bimbit</th>
	            		<th>No. Telefon Rumah</th>
	            		<th>No. Telefon Pejabar</th>
	            		<th>Emel</th>
	            		<th>Kemaskini</th>
	            	</tr>
            	</thead>
		        <tbody>
					<?php  $i = 1; $set1 = array(); while ($row_r_waris_wasiatsimati1 = $result_r_waris_wasiatsimati1->fetch_assoc()){ $set1[$i] = $row_r_waris_wasiatsimati1; 
						if ($row_r_waris_wasiatsimati1['ww_waris_type'] == 1) {
								continue;
						}
					?>
					<tr>
						<td><?php echo $row_r_waris_wasiatsimati1['ww_nama']?></td>
						<td><?php echo $row_r_waris_wasiatsimati1['ww_hubungan']?></td>
						<td><?php echo $row_r_waris_wasiatsimati1['ww_nric']?></td>
						<td><?php echo $row_r_waris_wasiatsimati1['ww_alamat']?></td>
						<td><?php echo $row_r_waris_wasiatsimati1['ww_notel_bimbit']?></td>
						<td><?php echo $row_r_waris_wasiatsimati1['ww_notel_rumah']?></td>
						<td><?php echo $row_r_waris_wasiatsimati1['ww_notel_pejabat']?></td>
						<td><?php echo $row_r_waris_wasiatsimati1['ww_emel']?></td>
						<td><button class="btn btn-sm btn-info m-2" onclick='updateStatus("<?php echo $i;?>", 2);'><i class="fa fa-edit"></i></button><a href="../../epusaka/controller/functions.php?colname=ww_id &&page=update_benefisiari&&dlt_jenis=r_waris_wasiatsimati&&dlte=<?php echo $row_r_waris_wasiatsimati1['ww_id'];?>&&idsimati=<?php echo $id;?>" class="btn btn-sm btn-danger m-2"><i class="fa fa-trash"></i></a></td>
					</tr>
					<?php $i++; } ?>
				</tbody>
    		</table>
    		<p class="float-right">
			<a href="update_penjaga.php?simati=<?php echo $id;?>" class="btn btn-primary" title="Langkau ke Akuan">Seterusnya</a>
		</p>	
		</div>
	</div>
</div>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Kemaskini Status Si Mati</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="../../epusaka/controller/functions.php" method="post">
          <div class="modal-body" id="content_body">
          	
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <!-- <button type="submit" value="hantar" class="btn btn-primary" >Kemaskini Status</button> -->
            <input type="submit" id="btn_update_harta" class="float-right" name="" value="Kemaskini">
          </div>
      </form>
    </div>
  </div>
</div>

<script type="text/javascript">
	function floatNumberField(){
			$(".floatNumberField").change(function() {
		        $(this).val(parseFloat($(this).val()).toFixed(2));
		    });
		}
  	function updateStatus(id, jenis){
      	content = '';
        var array_r_waris_wasiatsimati = <?php echo json_encode($set);?>;
        var array_r_waris_wasiatsimati1 = <?php echo json_encode($set1);?>;
        if (jenis == 1) {
          console.log(array_r_waris_wasiatsimati[id]);
          currArray = array_r_waris_wasiatsimati[id];
          content = `<div class="row col-md-12 mb-2">
				<div class="col-md-12 mb-2">
					<input type="hidden" name="sm_id" value="<?php echo $id;?>">
					<input type="hidden" name="ww_id" value="${currArray['ww_id']}">
					<label for="exampleFormControlSelect2">Jenis Waris</label>
				    <select class="form-control" id="exampleFormControlSelect2" name="ww_waris_type" required>
				      <option value="1">Benefisiari</option>
				      <option value="2">Waris</option>
				      <option value="3">Benefisiari & Waris</option>
				    </select>
				</div>
				<div class="col-md-6 m-0">
					<div class="left-side-form m-0 p-0">
						<h5 class="m-0 p-0">
							<label for="nama">Nama Penuh/ (Seperti Dalam Kad Pengenalan)</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_nama" value="${currArray['ww_nama']}">
						</p>
						<h5 class="m-0 p-0">
							<label for="nokp">Hubungan</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_hubungan" value="${currArray['ww_hubungan']}">
						</p>
						<h5 class="m-0 p-0">
							<label for="nokplama">No. KP</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_nric" value="${currArray['ww_nric']}">
						</p>
						<h5 class="m-0 p-0">
							<label for="sm_tmptmati">Alamat</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<textarea name="ww_alamat" class="m-0">${currArray['ww_alamat']}</textarea>
						</p>
					</div>
				</div>
				<div class="col-md-6 m-0">
					<div class="right-side-form m-0 p-0">
						<h5 class="m-0 p-0">
							<label for="nama">No. Telefon Bimbit</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_notel_rumah" value="${currArray['ww_notel_rumah']}">
						</p>
						<h5 class="m-0 p-0">
							<label for="nokp">No. Telefon Rumah</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_notel_pejabat" value="${currArray['ww_notel_pejabat']}">
						</p>
						<h5 class="m-0 p-0">
							<label for="nokplama">No. Telefon Pejabat</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_notel_bimbit" value="${currArray['ww_notel_bimbit']}">
						</p>
						<h5 class="m-0 p-0">
							<label for="nokplama">Emel</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_emel" value="${currArray['ww_emel']}">
						</p>
					</div>
				</div>
			</div>`;
          $('#btn_update_harta').attr('name', 'btn_update_waris');
          $('#btn_update_harta').attr('value', 'Kemaskini');
          $('#content_body').html(content);
          $('#exampleFormControlSelect2 option[value='+currArray['ww_waris_type']+']').attr('selected','selected');

        }else if(jenis == 2){
          currArray = array_r_waris_wasiatsimati1[id];
          content = `<div class="row col-md-12 mb-2">
				<div class="col-md-12 mb-2">
					<input type="hidden" name="sm_id" value="<?php echo $id;?>">
					<input type="hidden" name="ww_id" value="${currArray['ww_id']}">
					<label for="exampleFormControlSelect2">Jenis Waris</label>
				    <select class="form-control" id="exampleFormControlSelect2" name="ww_waris_type" required>
				      <option value="1">Benefisiari</option>
				      <option value="2">Waris</option>
				      <option value="3">Benefisiari & Waris</option>
				    </select>
				</div>
				<div class="col-md-6 m-0">
					<div class="left-side-form m-0 p-0">
						<h5 class="m-0 p-0">
							<label for="nama">Nama Penuh/ (Seperti Dalam Kad Pengenalan)</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_nama" value="${currArray['ww_nama']}">
						</p>
						<h5 class="m-0 p-0">
							<label for="nokp">Hubungan</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_hubungan" value="${currArray['ww_hubungan']}">
						</p>
						<h5 class="m-0 p-0">
							<label for="nokplama">No. KP</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_nric" value="${currArray['ww_nric']}">
						</p>
						<h5 class="m-0 p-0">
							<label for="sm_tmptmati">Alamat</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<textarea name="ww_alamat" class="m-0">${currArray['ww_alamat']}</textarea>
						</p>
					</div>
				</div>
				<div class="col-md-6 m-0">
					<div class="right-side-form m-0 p-0">
						<h5 class="m-0 p-0">
							<label for="nama">No. Telefon Bimbit</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_notel_rumah" value="${currArray['ww_notel_rumah']}">
						</p>
						<h5 class="m-0 p-0">
							<label for="nokp">No. Telefon Rumah</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_notel_pejabat" value="${currArray['ww_notel_pejabat']}">
						</p>
						<h5 class="m-0 p-0">
							<label for="nokplama">No. Telefon Pejabat</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_notel_bimbit" value="${currArray['ww_notel_bimbit']}">
						</p>
						<h5 class="m-0 p-0">
							<label for="nokplama">Emel</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_emel" value="${currArray['ww_emel']}">
						</p>
					</div>
				</div>
			</div>`;
          $('#btn_update_harta').attr('name', 'btn_update_waris');
          $('#btn_update_harta').attr('value', 'Kemaskini');
          $('#content_body').html(content);
          $('#exampleFormControlSelect2 option[value='+currArray['ww_waris_type']+']').attr('selected','selected');
        }else if(jenis == 3){
        	content = `<div class="row col-md-12 mb-2">
				<div class="col-md-12 mb-2">
					<input type="hidden" name="sm_id" value="<?php echo $id;?>">
					<label for="exampleFormControlSelect2">Jenis Waris</label>
				    <select class="form-control" id="exampleFormControlSelect2" name="ww_waris_type" required>
				      <option readonlyselected value="">Pilih Jenis Waris</option>
				      <option value="1">Benefisiari</option>
				      <option value="2">Waris</option>
				      <option value="3">Benefisiari & Waris</option>
				    </select>
				</div>
				<div class="col-md-6 m-0">
					<div class="left-side-form m-0 p-0">
						<h5 class="m-0 p-0">
							<label for="nama">Nama Penuh/ (Seperti Dalam Kad Pengenalan)</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_nama" value="">
						</p>
						<h5 class="m-0 p-0">
							<label for="nokp">Hubungan</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_hubungan" value="">
						</p>
						<h5 class="m-0 p-0">
							<label for="nokplama">No. KP</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_nric" value="">
						</p>
						<h5 class="m-0 p-0">
							<label for="sm_tmptmati">Alamat</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<textarea name="ww_alamat" class="m-0"></textarea>
						</p>
					</div>
				</div>
				<div class="col-md-6 m-0">
					<div class="right-side-form m-0 p-0">
						<h5 class="m-0 p-0">
							<label for="nama">No. Telefon Bimbit</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_notel_rumah" value="">
						</p>
						<h5 class="m-0 p-0">
							<label for="nokp">No. Telefon Rumah</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_notel_pejabat" value="">
						</p>
						<h5 class="m-0 p-0">
							<label for="nokplama">No. Telefon Pejabat</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_notel_bimbit" value="">
						</p>
						<h5 class="m-0 p-0">
							<label for="nokplama">Emel</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ww_emel" value="">
						</p>
					</div>
				</div>
			</div>`;
          $('#btn_update_harta').attr('name', 'btn_add_waris');
          $('#btn_update_harta').attr('value', 'Tambah');
          $('#content_body').html(content);
        }
        $('#exampleModal').modal('show');
        // $('#idval').val(id);
        // $('#select_status option[value="'+status+'"]').attr('selected','selected');
      }
</script>