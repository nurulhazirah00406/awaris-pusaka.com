<?php
	if (isset($_GET['simati']) && ($_GET['simati'] != '' || $_GET['simati'] != null)) {
		$id = $_GET['simati'];
	}else{
		$base_url = base_url();
		$url = $base_url."/epusaka/view/senarai_pemohon.php";
		// redirect($url);
		echo "<script> window.location.href = `$url`; </script>;";
	}
?>

<div class="container">
	<form action="../../epusaka/controller/functions.php" method="post">
		<div class="row">
			<div class="col-md-12">
				<div class="section-title">
					<h3>Borang Permohonan Perkhidmatan Pentadbiran Harta Pusaka</h3>
				</div> 
				<?php include ('../view/progressbarr.php')?> 
				<h3>
					<strong>4.0 Keterangan Mengenai Harta Si Mati</strong>
				</h3>
				<h5>
					<strong>4.1 Harta Tak Alih</strong> (Contoh: Tanah/Rumah)
				</h5>
				<div class="table-responsive">
					<table class="table">
						<thead>
							<tr>
								<th>Jenis Hak Milik</th>
								<th>No. Hak Milik</th>
								<th>No. Lot</th>
								<th>Mukim/ Bandar</th>
								<th>Daerah/ Negeri</th>
								<th>Bahagian</th>
								<th>Anggaran Nilai(RM)</th>
							</tr>
						</thead>
						<tbody class="field_wrapper1">
							<tr>
								<td>
									<input type="hidden" name="sm_id" value="<?php echo $id;?>">
									<input type="text" class="w-100 p-0 m-0 rounded-0" name="hx_jenis[]" value="" />
								</td>
								<td>
									<input type="text" class="w-100 p-0 m-0 rounded-0" name="hx_no_hakmilik[]" value="" />
								</td>
								<td>
									<input type="text" class="w-100 p-0 m-0 rounded-0" name="hx_no_lot[]" value="" />
								</td>
								<td>
									<input type="text" class="w-100 p-0 m-0 rounded-0" name="hx_mukim_bandar[]" value="" />
								</td>
								<td>
									<input type="text" class="w-100 p-0 m-0 rounded-0" name="hx_daerah_negeri[]" value="" />
								</td>
								<td>
									<input type="text" class="w-100 p-0 m-0 rounded-0" name="hx_bahagian[]" value="" />
								</td>
								<td>
									<input type="number" step="0.01" class="w-100 floatNumberField p-0 m-0 rounded-0" oninput="floatNumberField();" name="hx_anggaran[]" min="0" value="0.00" />
								</td>
								<td>
									<a href="javascript:void(0);" class="add_button1 btn btn-primary btn-sm" title="Add field">
										<i class="fa fa-plus"></i>
									</a>
								</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="section-title">
					<h5>
						<strong>4.2 Harta Alih</strong> (Contoh: Tunai/Akaun Bank/Saham/KWSP/Kenderaan/Insuran/Takaful)
					</h5>
					<div class="table-responsive">
						<table class="table">
							<thead>
								<tr>
									<th>Jenis Harta</th>
									<th>No. Akaun/No. Ahli/No. Pendaftaran/Dan Lain-lain</th>
									<th>Anggaran Nilai(RM)</th>
								</tr>
							</thead>
							<tbody class="field_wrapper">
								<!-- <div class="field_wrapper"><div><input type="text" name="field_name[]" value="" /><a href="javascript:void(0);" class="add_button btn btn-primary btn-sm" title="Add field"><i class="fa fa-plus"></i></a></div></div> -->
								<tr>
									<td>
										<input type="text" class="w-100 p-0 m-0 rounded-0" name="ha_jenis[]" value="" />
									</td>
									<td>
										<input type="text" class="w-100 p-0 m-0 rounded-0" name="ha_no_akaun[]" value="" />
									</td>
									<td>
										<input type="number" step="0.01" class="w-100 floatNumberField p-0 m-0 rounded-0" oninput="floatNumberField();" name="ha_anggaran[]" min="0" value="0.00" />
									</td>
									<td>
										<a href="javascript:void(0);" class="add_button btn btn-primary btn-sm" title="Add field">
											<i class="fa fa-plus"></i>
										</a>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<div class="col-md-6">
				<div class="left-side-form">
					<!-- <p><input type="submit" class="float-right" name="btn_borang_harta" value="Submit"></p> -->
				</div>
			</div>
			<div class="col-md-6">
				<div class="right-side-form">
					<p><input type="submit" class="float-right" name="btn_borang_harta" value="Submit"></p>
				</div>
			</div>
		</div>
	</form>
</div>

<script type="text/javascript">
$(document).ready(function(){
    var maxField = 50; //Input fields increment limitation
    var addButton = $('.add_button'); //Add button selector
    var wrapper = $('.field_wrapper'); //Input field wrapper
    var fieldHTML = `<tr>
								<td><input type="text" class="w-100 p-0 m-0 rounded-0" name="ha_jenis[]" value="" /></td>
								<td><input type="text" class="w-100 p-0 m-0 rounded-0" name="ha_no_akaun[]" value="" /></td>
								<td><input type="number" step="0.01" class="w-100 floatNumberField p-0 m-0 rounded-0" oninput="floatNumberField();" name="ha_anggaran[]" min="0" value="0.00" /></td>
								<td><a href="javascript:void(0);" class="remove_button btn btn-danger btn-sm" title="Add field"><i class="fa fa-minus"></i></a></td>
							</tr>`; //New input field html 
    var x = 1; //Initial field counter is 1
    
    //Once add button is clicked
    $(addButton).click(function(){
        //Check maximum number of input fields
        if(x < maxField){ 
            x++; //Increment field counter
            $(wrapper).append(fieldHTML); //Add field html
        }
    });
    
    //Once remove button is clicked
    $(wrapper).on('click', '.remove_button', function(e){
        e.preventDefault();
        console.log( $(this).parent());
        $(this).parent().parent().remove(); //Remove field html
        x--; //Decrement field counter
    });

    var addButton1 = $('.add_button1'); //Add button selector
    var wrapper1 = $('.field_wrapper1'); //Input field wrapper
    var fieldHTML1 = `<tr>
						<td><input type="text" class="w-100 p-0 m-0 rounded-0" name="hx_jenis[]" value="" /></td>
						<td><input type="text" class="w-100 p-0 m-0 rounded-0" name="hx_no_hakmilik[]" value="" /></td>
						<td><input type="text" class="w-100 p-0 m-0 rounded-0" name="hx_no_lot[]" value="" /></td>
						<td><input type="text" class="w-100 p-0 m-0 rounded-0" name="hx_mukim_bandar[]" value="" /></td>
						<td><input type="text" class="w-100 p-0 m-0 rounded-0" name="hx_daerah_negeri[]" value="" /></td>
						<td><input type="text" class="w-100 p-0 m-0 rounded-0" name="hx_bahagian[]" value="" /></td>
						<td><input type="number" step="0.01" class="w-100 floatNumberField p-0 m-0 rounded-0" oninput="floatNumberField();" name="hx_anggaran[]" min="0" value="0.00" /></td>
						<td><a href="javascript:void(0);" class="remove_button btn btn-danger btn-sm" title="Add field"><i class="fa fa-minus"></i></a></td>
					</tr>`; //New input field html 
    var y = 1; //Initial field counter is 1
    
    //Once add button is clicked
    $(addButton1).click(function(){
        //Check maximum number of input fields
        if(y < maxField){ 
            y++; //Increment field counter
            $(wrapper1).append(fieldHTML1); //Add field html
        }
    });
    
    //Once remove button is clicked
    $(wrapper1).on('click', '.remove_button', function(e){
        e.preventDefault();
        console.log( $(this).parent());
        $(this).parent().parent().remove(); //Remove field html
        y--; //Decrement field counter
    });
});

function floatNumberField(){
	$(".floatNumberField").change(function() {
        $(this).val(parseFloat($(this).val()).toFixed(2));
    });
}
</script>