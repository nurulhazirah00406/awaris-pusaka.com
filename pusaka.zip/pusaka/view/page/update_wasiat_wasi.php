<?php
	if (isset($_GET['simati']) && ($_GET['simati'] != '' || $_GET['simati'] != null)) {
		$id = $_GET['simati'];
	}else{
		$base_url = base_url();
		$url = $base_url."/epusaka/view/senarai_pemohon.php";
		// redirect($url);
		echo "<script> window.location.href = `$url`; </script>;";
	}

	// var_dump($result->fetch_assoc());
	$row = $result->fetch_assoc();

?>
<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="section-title">
					<h3>Borang Permohonan Perkhidmatan Pentadbiran Harta Pusaka</h3>
				</div>
				<div class="row">
					<div class="col-md-12">
						<form action="../../epusaka/controller/functions.php" method="post">
							<div class="row">
								<div class="col-md-6">
									<div class="left-side-form">
										<h3><strong>Keterangan Mengenai Wasiat & Wasi</strong></h3>
										<h5><strong>3.0 Keterangan Mengenai Wasiat</strong></h5>
										<p><input type="hidden" name="sm_id" value="<?php echo $id;?>"></p>
										<input type="radio" name="iw_jenis" value="wasiattulis"><span>Wasiat Bertulis</span>
										<input type="radio" name="iw_jenis" value="wasiatlisan"><span>Wasiat Lisan</span>
										<span class="error">
										
										<h5><label for="iw_nopendaftaran">No. Pendaftaran Wasiat :</label>
										<span class="error"></span></h5>
										<p><input type="text" name="iw_nopendaftaran" value="<?php echo $row['iw_nopendaftaran'];?>"></p>

										<h5><label for="iw_wasi">Wasi :</label><span class="error">
												</span></h5>
										<p><input type="text" name="iw_wasi" value="<?php echo $row['iw_wasi'];?>"></p>
										
										<h5><label for="iw_tmptsimpan">Tempat Menyimpan Wasiat :</label><span class="error">
												</span></h5>
										<p><input type="text" name="iw_tmptsimpan" value="<?php echo $row['iw_tmptsimpan'];?>"></p>
	
						         </div>
								</div>
								<div class="col-md-6">
									<div class="right-side-form">
										<h5><strong>3.1 Keterangan Mengenai Wasi</strong></h5>
										
										<h5><label for="iw_nama">Nama Penuh/ (Seperti Dalam Kad Pengenalan)</label>
										<span class="error"></span></h5>
										<p><input type="text" name="iw_nama" value="<?php echo $row['iw_nama'];?>"></p>

										<h5><label for="iw_nric_new">No. KP Baru</label><span class="error">
												</span></h5>
										<p><input type="text" name="iw_nric_new" value="<?php echo $row['iw_nric_new'];?>"></p>
										
										<h5><label for="iw_nric_old">No. KP Lama/Polis/Tentera/No. Pasport</label><span class="error">
												</span></h5>
										<p><input type="text" name="iw_nric_old" value="<?php echo $row['iw_nric_old'];?>"></p>
										
										<h5><label for="iw_umur">Umur</label><span class="error">
												</span></h5>
										<p><input type="text" name="iw_umur" value="<?php echo $row['iw_umur'];?>"></p>
										<?php 
                                        	$var = $row['p_birthdate'];
											$date = str_replace('/', '-', $var);
                                        ?>
										<h5><label for="iw_birthdate">Tarikh Lahir</label><span class="error">
												</span></h5>
										<p><input type="date" name="iw_birthdate" value="<?php echo date('Y-m-d', strtotime($date));?>"></p>
										
										<h5><label for="iw_alamat_surat">Alamat Surat Menyurat</label><span class="error">
												</span></h5>
										<p><input type="text" name="iw_alamat_surat" value="<?php echo $row['iw_alamat_surat'];?>"></p>
										
										<h5><label for="iw_surat_poskod">Poskod</label><span class="error">
												</span></h5>
										<p><input type="text" name="iw_surat_poskod" value="<?php echo $row['iw_surat_poskod'];?>"></p>
										
										<h5><label for="iw_surat_negeri">Negeri</label><span class="error">
												</span></h5>
										<p><input type="text" name="iw_surat_negeri" value="<?php echo $row['iw_surat_negeri'];?>"></p>
										
										<h5><label for="iw_alamat_tetap">Alamat Tetap</label><span class="error">
												</span></h5>
										<p><input type="text" name="iw_alamat_tetap" value="<?php echo $row['iw_alamat_tetap'];?>"></p>
										
										<h5><label for="iw_poskod">Poskod</label><span class="error">
												</span></h5>
										<p><input type="text" name="iw_poskod" value="<?php echo $row['iw_poskod'];?>"></p>
										
										<h5><label for="iw_negeri">Negeri</label><span class="error">
												</span></h5>
										<p><input type="text" name="iw_negeri" value="<?php echo $row['iw_negeri'];?>"></p>
										
										<h5><label for="iw_tel_rumah">No.Tel Rumah</label><span class="error">
												</span></h5>
										<p><input type="text" name="iw_tel_rumah" value="<?php echo $row['iw_tel_rumah'];?>"></p>
										
										<h5><label for="iw_tel_pjbt">No. Tel Pejabat</label><span class="error">
												</span></h5>
										<p><input type="text" name="iw_tel_pjbt" value="<?php echo $row['iw_tel_pjbt'];?>"></p>
										
										<h5><label for="iw_tel_bimbit">No. Tel Bimbit</label><span class="error">
												</span></h5>
										<p><input type="text" name="iw_tel_bimbit" value="<?php echo $row['iw_tel_bimbit'];?>"></p>
										
									    <h5><label for="iw_emel">E-mel</label><span class="error">
												</span></h5>
										<p><input type="text" name="iw_emel" value="<?php echo $row['iw_emel'];?>"></p>
									
									<h5><label for="iw_hubungan">Perhubungan Persaudaraan Dengan Simati</label></h5>
										<input type="radio" name="iw_hubungan" value="Suami"><span>Suami</span>
										<input type="radio" name="iw_hubungan" value="Isteri"><span>Isteri</span>
										<input type="radio" name="iw_hubungan" value="Bapa"><span>Bapa</span>
										<input type="radio" name="iw_hubungan" value="Ibu"><span>Ibu</span>
										<input type="radio" name="iw_hubungan" value="Anak"><span>Anak</span>
										<input type="radio" name="iw_hubungan" value="Lain-lain"><span>Lain-lain</span>
										<span class="error">
										<p><input type="submit" name="btn_update_wasiat" value="Submit"></p>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script type="text/javascript">
	var iw_jenis = `<?php echo $row['iw_jenis']; ?>`;
	var iw_hubungan = `<?php echo $row['iw_hubungan']; ?>`;

	$('input:radio[name="iw_jenis"]').filter('[value="'+iw_jenis+'"]').attr('checked', true);
	$('input:radio[name="iw_hubungan"]').filter('[value="'+iw_hubungan+'"]').attr('checked', true);
	</script>