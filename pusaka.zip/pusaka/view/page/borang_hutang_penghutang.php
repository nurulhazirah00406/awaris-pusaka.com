<?php
    if (isset($_GET['simati']) && ($_GET['simati'] != '' || $_GET['simati'] != null)) {
        $id = $_GET['simati'];
    }else{
        $base_url = base_url();
        $url = $base_url."/epusaka/view/senarai_pemohon.php";
        // redirect($url);
        echo "<script> window.location.href = `$url`; </script>;";
    }
?>
<div class="container">
    <form action="../../epusaka/controller/functions.php" method="post">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title">
                    <h3>
                        <strong>Borang Permohonan Perkhidmatan Pentadbiran Harta Pusaka</strong>
                    </h3>
                </div> <?php include ('../view/progressbarr.php')?> <h3>Keterangan Mengenai Hutang & Penghutang Si Mati</h3>
                <h5>
                    <strong>5.0 Keterangan Mengenai Hutang Si Mati</strong>(Termasuk Tuntutan Belanja Kematian/Badal Haji/Zakat/Nazar/Fidyah)
                </h5>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Jenis Harta</th>
                                <th>Nama dan Alamat Pemiutang</th>
                                <th>Anggaran Nilai(RM)</th>
                            </tr>
                        </thead>
                        <tbody class="field_wrapper1">
                            <tr>
                                <td>
                                    <input type="hidden" name="sm_id" value="<?php echo $id;?>">
                                    <input type="text" class="w-100 p-0 m-0 rounded-0" name="hs_jenis[]" value="" />
                                </td>
                                <td>
                                    <input type="text" class="w-100 p-0 m-0 rounded-0" name="hs_nama_alamat[]" value="" />
                                </td>
                                <td>
                                    <input type="number" step="0.01" class="w-100 floatNumberField p-0 m-0 rounded-0" oninput="floatNumberField();" name="hs_anggaran[]" min="0" value="0.00" />
                                </td>
                                <td>
                                    <a href="javascript:void(0);" class="add_button1 btn btn-primary btn-sm" title="Add field">
                                        <i class="fa fa-plus"></i>
                                    </a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="section-title">
                    <h5>
                        <strong>6.0 Keterangan Mengenai Penghutang</strong>
                    </h5>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Jenis Hutang</th>
                                    <th>Nama dan Alamat Penghutang</th>
                                    <th>Anggaran Nilai(RM)</th>
                                </tr>
                            </thead>
                            <tbody class="field_wrapper">
                                <tr>
                                    <td>
                                        <input type="text" class="w-100 p-0 m-0 rounded-0" name="ps_jenis[]" value="" />
                                    </td>
                                    <td>
                                        <input type="text" class="w-100 p-0 m-0 rounded-0" name="ps_nama_alamat[]" value="" />
                                    </td>
                                    <td>
                                        <input type="number" step="0.01" class="w-100 floatNumberField p-0 m-0 rounded-0" oninput="floatNumberField();" name="ps_anggaran[]" min="0" value="0.00" />
                                    </td>
                                    <td>
                                        <a href="javascript:void(0);" class="add_button btn btn-primary btn-sm" title="Add field">
                                            <i class="fa fa-plus"></i>
                                        </a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="left-side-form">
                    <!-- <p><input type="submit" class="float-right" name="btn_borang_harta" value="Submit"></p> -->
                </div>
            </div>
            <div class="col-md-6">
                <div class="right-side-form">
                    <p><input type="submit" class="float-right" name="btn_borang_hutang_penghutang" value="Submit"></p>
                </div>
            </div>
        </div>
    </form>
</div>

<script type="text/javascript">
    $(document).ready(function(){
    var maxField = 50; //Input fields increment limitation
    var addButton = $('.add_button'); //Add button selector
    var wrapper = $('.field_wrapper'); //Input field wrapper
    var fieldHTML = `<tr>
                                <td><input type="text" class="w-100 p-0 m-0 rounded-0" name="ps_jenis[]" value="" /></td>
                                <td><input type="text" class="w-100 p-0 m-0 rounded-0" name="ps_nama_alamat[]" value="" /></td>
                                <td><input type="number" step="0.01" class="w-100 floatNumberField p-0 m-0 rounded-0" oninput="floatNumberField();" name="ps_anggaran[]" min="0" value="0.00" /></td>
                                <td><a href="javascript:void(0);" class="remove_button btn btn-danger btn-sm" title="Add field">
                                        <i class="fa fa-minus"></i></a>
                                    </a></td>
                            </tr>`; //New input field html 
    var x = 1; //Initial field counter is 1
    
    //Once add button is clicked
    $(addButton).click(function(){
        //Check maximum number of input fields
        if(x < maxField){ 
            x++; //Increment field counter
            $(wrapper).append(fieldHTML); //Add field html
        }
    });
    
    //Once remove button is clicked
    $(wrapper).on('click', '.remove_button', function(e){
        e.preventDefault();
        console.log( $(this).parent());
        $(this).parent().parent().remove(); //Remove field html
        x--; //Decrement field counter
    });

    var addButton1 = $('.add_button1'); //Add button selector
    var wrapper1 = $('.field_wrapper1'); //Input field wrapper
    var fieldHTML1 = `<tr>
                        <td><input type="text" class="w-100 p-0 m-0 rounded-0" name="hs_jenis[]" value="" /></td>
                        <td><input type="text" class="w-100 p-0 m-0 rounded-0" name="hs_nama_alamat[]" value="" /></td>
                        <td><input type="number" step="0.01" class="w-100 floatNumberField p-0 m-0 rounded-0" oninput="floatNumberField();" name="hs_anggaran[]" min="0" value="0.00" /></td>
                        <td><a href="javascript:void(0);" class="remove_button btn btn-danger btn-sm" title="Add field">
                                        <i class="fa fa-minus"></i>
                                    </a></td>
                    </tr>`; //New input field html 
    var y = 1; //Initial field counter is 1
    
    //Once add button is clicked
    $(addButton1).click(function(){
        //Check maximum number of input fields
        if(y < maxField){ 
            y++; //Increment field counter
            $(wrapper1).append(fieldHTML1); //Add field html
        }
    });
    
    //Once remove button is clicked
    $(wrapper1).on('click', '.remove_button', function(e){
        e.preventDefault();
        console.log( $(this).parent());
        $(this).parent().parent().remove(); //Remove field html
        y--; //Decrement field counter
    });
});

    function floatNumberField(){
        $(".floatNumberField").change(function() {
            $(this).val(parseFloat($(this).val()).toFixed(2));
        });
    }
</script>