<?php
	if (isset($_GET['simati']) && ($_GET['simati'] != '' || $_GET['simati'] != null)) {
		$id = $_GET['simati'];
	}else{
		$base_url = base_url();
		$url = $base_url."/epusaka/view/senarai_pemohon.php";
		// redirect($url);
		echo "<script> window.location.href = `$url`; </script>;";
	}

	// var_dump($row1 = $resultAll1->fetch_all());
	// $row2 = $resultAll2->fetch_all();
	// $row1 = $result1->fetch_assoc();
	// $row2 = $result2->fetch_assoc();

?>
<div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="section-title">
            <h3>4.0 Keterangan Mengenai Harta Si Mati</h3>
          </div>
          <h5>
            <strong>4.1 Harta Tak Alih</strong> (Contoh: Tanah/Rumah) <button class="btn btn-sm btn-primary m-2" onclick='updateStatus("<?php echo $id;?>", 3);'><i class="fa fa-plus"></i></button>
          </h5>
          <table class="table">
            <thead>
              <tr>
                <th>Jenis Hak Milik</th>
                <th>No. Hak Milik</th>
                <th>No. Lot</th>
                <th>Mukim/ Bandar</th>
                <th>Daerah/ Negeri</th>
                <th>Bahagian</th>
                <th>Anggaran Nilai(RM)</th>
                <th>Kemaskini</th>
              </tr>
            </thead>
            <tbody class="field_wrapper1">
				<?php  $i = 0;$set = array(); while ($row_hartaxalih = $result1->fetch_assoc()){  $set[$i] = $row_hartaxalih;?>
				<tr>
					<td><?php echo $row_hartaxalih['hx_jenis']?></td>
					<td><?php echo $row_hartaxalih['hx_no_hakmilik']?></td>
					<td><?php echo $row_hartaxalih['hx_no_lot']?></td>
					<td><?php echo $row_hartaxalih['hx_mukim_bandar']?></td>
					<td><?php echo $row_hartaxalih['hx_daerah_negeri']?></td>
					<td><?php echo $row_hartaxalih['hx_bahagian']?></td>
					<td><?php echo $row_hartaxalih['hx_anggaran']?></td>
					<td><button class="btn btn-sm btn-info m-2" onclick='updateStatus("<?php echo $i;?>", 1);'><i class="fa fa-edit"></i></button><a href="../../epusaka/controller/functions.php?colname=hx_id&&page=update_harta_simati&&dlt_jenis=r_hrtxalih&&dlte=<?php echo $row_hartaxalih['hx_id'];?>&&idsimati=<?php echo $id;?>" class="btn btn-sm btn-danger m-2"><i class="fa fa-trash"></i></a></td>
				</tr>
				<?php $i++; } ?>
			</tbody>
          </table>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="section-title">
            <h5>
              <strong>4.2 Harta Alih</strong> (Contoh: Tunai/Akaun Bank/Saham/KWSP/Kenderaan/Insuran/Takaful) <button class="btn btn-sm btn-primary m-2" onclick='updateStatus("<?php echo $id;?>", 4);'><i class="fa fa-plus"></i></button>
            </h5>
          </div>
          <div class="table-responsive">
            <table class="table">
              <thead>
                <tr>
                  <th>Jenis Harta</th>
                  <th>No. Akaun/No. Ahli/No. Pendaftaran/Dan Lain-lain</th>
                  <th>Anggaran Nilai(RM)</th>
                  <th>Kemaskini</th>
                </tr>
              </thead>
              <tbody class="field_wrapper">
                <?php  $i = 1; $set1 = array(); while ($row_hartaalih = $result2->fetch_assoc()){ $set1[$i] = $row_hartaalih;?>
        				<tr>
        					<td><?php echo $row_hartaalih['ha_jenis']?></td>
        					<td><?php echo $row_hartaalih['ha_no_akaun']?></td>
        					<td><?php echo $row_hartaalih['ha_anggaran']?></td>
        					<td><button class="btn btn-sm btn-info m-2" onclick='updateStatus("<?php echo $i;?>", 2);'><i class="fa fa-edit"></i></button><a href="../../epusaka/controller/functions.php?colname=ha_id&&page=update_harta_simati&&dlt_jenis=r_hartaalih&&dlte=<?php echo $row_hartaalih['ha_id']?>&&idsimati=<?php echo $id;?>" class="btn btn-sm btn-danger m-2"><i class="fa fa-trash"></i></a></td>
        				</tr>
        				<?php $i++; } ?>
              </tbody>
            </table>
          </div>
        <p class="float-right">
			<a href="update_hutang_penghutang.php?simati=<?php echo $id;?>" class="btn btn-primary" title="Langkau ke Akuan">Seterusnya</a>
		</p>
        </div>
      </div>
    </div>

    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Kemaskini Status Si Mati</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <form action="../../epusaka/controller/functions.php" method="post">
              <div class="modal-body" id="content_body">
              	
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <!-- <button type="submit" value="hantar" class="btn btn-primary" >Kemaskini Status</button> -->
                <input type="submit" id="btn_update_harta" class="float-right" name="" value="Kemaskini">
              </div>
          </form>
        </div>
      </div>
    </div>

    <script type="text/javascript">
    	function floatNumberField(){
				$(".floatNumberField").change(function() {
			        $(this).val(parseFloat($(this).val()).toFixed(2));
			    });
			}
      function updateStatus(id, jenis){
      	content = '';
        var array_hartaxalih = <?php echo json_encode($set);?>;
        var array_hartaalih = <?php echo json_encode($set1);?>;
        if (jenis == 1) {
          // console.log(array_hartaxalih[id]);
          currArray = array_hartaxalih[id];
          content = `<div class="row mb-2">
              		<div class="col-md-12 m-0">
						<input type="hidden" name="sm_id" value="<?php echo $id;?>">
						<input type="hidden" name="hx_id" value="${currArray['hx_id']}">
						<h5 class="m-0 p-0">
							<label for="nama">Jenis Hak Milik</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="hx_jenis" value="${currArray['hx_jenis']}" />
						</p>
						<h5 class="m-0 p-0">
							<label for="nokp">No. Hak Milik</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="hx_no_hakmilik" value="${currArray['hx_no_hakmilik']}" />
						</p>
						<h5 class="m-0 p-0">
							<label for="nokplama">No. Lot</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="hx_no_lot" value="${currArray['hx_no_lot']}" />
						</p>
						<h5 class="m-0 p-0">
							<label for="sm_tmptmati">Mukim/ Bandar</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="hx_mukim_bandar" value="${currArray['hx_mukim_bandar']}" />
						</p>

						<h5 class="m-0 p-0">
							<label for="nama">Daerah/ Negeri</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="hx_daerah_negeri" value="${currArray['hx_daerah_negeri']}" />
						</p>
						<h5 class="m-0 p-0">
							<label for="nokp">Bahagian</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="hx_bahagian" value="${currArray['hx_bahagian']}" />
						</p>
						<h5 class="m-0 p-0">
							<label for="nokplama">Anggaran Nilai(RM)</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="number" step="0.01" class="m-0 floatNumberField" oninput="floatNumberField();" name="hx_anggaran" min="0" value="${currArray['hx_anggaran']}" />
						</p>
					</div>
				</div>`;
          $('#btn_update_harta').attr('name', 'btn_update_hartaxalih');
          $('#btn_update_harta').attr('value', 'Kemaskini');
          $('#content_body').html(content);
        }else if(jenis == 2){
          console.log(array_hartaalih[id]);
          currArray = array_hartaalih[id];
          content = `<div class="row mb-2">
              		<div class="col-md-12 m-0">
						<input type="hidden" name="sm_id" value="<?php echo $id;?>">
						<input type="hidden" name="ha_id" value="${currArray['ha_id']}">
						<h5 class="m-0 p-0">
							<label for="nama">Jenis Hak Milik</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ha_jenis" value="${currArray['ha_jenis']}" />
						</p>
						<h5 class="m-0 p-0">
							<label for="nokp">No. Hak Milik</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ha_no_akaun" value="${currArray['ha_no_akaun']}" />
						</p>
						<h5 class="m-0 p-0">
							<label for="nokplama">Anggaran Nilai(RM)</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="number" step="0.01" class="m-0 floatNumberField" oninput="floatNumberField();" name="ha_anggaran" min="0" value="${currArray['ha_anggaran']}" />
						</p>
					</div>
				</div>`;
          $('#btn_update_harta').attr('name', 'btn_update_hartaalih');
          $('#btn_update_harta').attr('value', 'Kemaskini');
          $('#content_body').html(content);
        }else if(jenis == 3){
        	content = `<div class="row mb-2">
              		<div class="col-md-12 m-0">
						<input type="hidden" name="sm_id" value="<?php echo $id;?>">
						<h5 class="m-0 p-0">
							<label for="nama">Jenis Hak Milik</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="hx_jenis" value="" />
						</p>
						<h5 class="m-0 p-0">
							<label for="nokp">No. Hak Milik</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="hx_no_hakmilik" value="" />
						</p>
						<h5 class="m-0 p-0">
							<label for="nokplama">No. Lot</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="hx_no_lot" value="" />
						</p>
						<h5 class="m-0 p-0">
							<label for="sm_tmptmati">Mukim/ Bandar</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="hx_mukim_bandar" value="" />
						</p>

						<h5 class="m-0 p-0">
							<label for="nama">Daerah/ Negeri</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="hx_daerah_negeri" value="" />
						</p>
						<h5 class="m-0 p-0">
							<label for="nokp">Bahagian</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="hx_bahagian" value="" />
						</p>
						<h5 class="m-0 p-0">
							<label for="nokplama">Anggaran Nilai(RM)</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="number" step="0.01" class="m-0 floatNumberField" oninput="floatNumberField();" name="hx_anggaran" min="0" value="" />
						</p>
					</div>
				</div>`;
          $('#btn_update_harta').attr('name', 'btn_add_hartaxalih');
          $('#btn_update_harta').attr('value', 'Tambah');
          $('#content_body').html(content);
        }else if(jenis == 4){
        	content = `<div class="row mb-2">
              		<div class="col-md-12 m-0">
						<input type="hidden" name="sm_id" value="<?php echo $id;?>">
						<h5 class="m-0 p-0">
							<label for="nama">Jenis Hak Milik</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ha_jenis" value="" />
						</p>
						<h5 class="m-0 p-0">
							<label for="nokp">No. Hak Milik</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="text" class="m-0" name="ha_no_akaun" value="" />
						</p>
						<h5 class="m-0 p-0">
							<label for="nokplama">Anggaran Nilai(RM)</label>
							<span class="error"></span>
						</h5>
						<p class="m-0 p-0">
							<input type="number" step="0.01" class="m-0 floatNumberField" oninput="floatNumberField();" name="ha_anggaran" min="0" value="" />
						</p>
					</div>
				</div>`;
          $('#btn_update_harta').attr('name', 'btn_add_hartaalih');
          $('#btn_update_harta').attr('value', 'Tambah');
          $('#content_body').html(content);
        }
        $('#exampleModal').modal('show');
        // $('#idval').val(id);
        // $('#select_status option[value="'+status+'"]').attr('selected','selected');
      }
    </script>