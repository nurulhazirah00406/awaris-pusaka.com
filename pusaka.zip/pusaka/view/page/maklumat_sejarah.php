	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="section-title">
		<h4>Maklumat Terperinci & Sejarah Dokumentasi</h4>
        <table>
            <thead>
				<h4><em>Samat Bin Khaled(no ic)</em></h4>
                <tr>
                    <th>No Fail</th>
                    <th>Si Mati</th>
                    <th>No. Kad Pengenalan</th>
                    <th>Tarikh Kematian</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>A001</td>
                    <td>Samat Bin Khaled</td>
                    <td>780905-14-0460</td>
					<td>(1/Mac/2022)</td>
				</tr>
            </tbody>
        </table>
					<h5>Sejarah Fail</h5>
					   <table>
            <thead>
                <tr>
                    <th>Tarikh</th>
                    <th>Status</th>
                    <th>Penerangan</th>
                    <th>Pegawai</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>5/September/22</td>
                    <td>Dokumentasi</td>
                    <td>//penerangan staff//</td>
					<td>((nama staff yg kemaskini))</td>
				</tr>
				 <tr>
                    <td>8/September/22</td>
                    <td>Proses Mahkamah</td>
                    <td>//penerangan staff//</td>
					<td>((nama staff yg kemaskini))</td>
				</tr>
				 <tr>
                    <td>10/September/22</td>
                    <td>Pencairan Aset</td>
                    <td>//penerangan staff//</td>
					<td>((nama staff yg kemaskini))</td>
				</tr>
				 <tr>
                    <td>15/September/22</td>
                    <td>Tutup Fail</td>
                    <td>//penerangan staff//</td>
					<td>((nama staff yg kemaskini))</td>
				</tr>
            </tbody>
        </table>
    </div>
			</div>
		</div>
	</div>
	</div>
