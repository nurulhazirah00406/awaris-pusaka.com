<!doctype html>
<html>
<head>
	<!--============================== Required meta tags ===========================-->
    
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!--============================= Fonts =======================================-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100i,300,300i,400,700" rel="stylesheet">

    <!--============================= CSS =======================================-->
    <link rel="stylesheet" href="../css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="../css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="../css/owl.carousel.min.css" type="text/css">
	  <link rel="stylesheet" href="../css/navstyle.css" type="text/css">
    <link rel="stylesheet" href="../css/print.min.css" type="text/css">

    <script src="../js/jquery-3.2.1.slim.min.js"></script>

    <title></title>
    <link rel="shourtcut icon" type="image/png" href="../img/image.png">

    <style type="text/css">
      @media print {
        body {-webkit-print-color-adjust: exact;}
      }
        @media print {
          .noPrint{
            display:none;
          }

          th{
            background-color: #faf5f5 !important;
            color: #0f0f0f !important;
            -webkit-print-color-adjust: exact;
          }
        }

        @media print {
            .pagebreak { page-break-before: always; } /* page-break-after works, as well */
        }
        .pagebreak{
          -webkit-print-color-adjust:exact !important;
          print-color-adjust:exact !important;
        }
    </style>
</head>
<body>

	<?php 
    	require "layout/header.php";
    	require "../controller/pages.php";
    	$curPageName = substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1);  
        $curpage = strtok($curPageName,  '.');
    	pages($curpage);
    ?>
	<script src="../js/popper-1.12.9.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <script src="../js/owl.carousel.min.js"></script>
	<script src="../js/main.js"></script>
  <script src="../js/print.min.js"></script>
</body>