<?php 

$server = "localhost";
$user = "root";
$pass = "";
$awarisdatabase = "awaris_db";

$conn = mysqli_connect($server, $user, $pass, $awarisdatabase);

if (!$conn) {
    die("<script>alert('Connection Failed.')</script>");
}

?>