<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  div.square {
  position: absolute;
  right: 150px;
  height: 65px;
  width: 65px;
  background-color: #FFFFFF;
  border: 1px solid black;
	  
}
</style>
</head>
<body>
	
<div class="square"><right>         
	</div></right>
	

</body>
</html> 