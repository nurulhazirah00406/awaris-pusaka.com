<?php 
	session_start();
	session_destroy();
	function base_url(){
		return $base_url = "http://" . $_SERVER['SERVER_NAME'];
	}

	function redirect($url) {
	    header("Location: ".$url);
	    die();
	}

	$base_url = base_url()."/epusaka";
	redirect($base_url);
?>