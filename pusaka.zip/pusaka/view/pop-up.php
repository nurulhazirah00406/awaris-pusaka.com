<div id="Lihat" style="display: none;position:absolute; height:100%;width:90%;top: 435px;margin-left:5%;">
<div  class="card shadow-lg" style="position:relative; margin-left:auto;margin-right:auto;overflow: auto;">
    <div class="card-body">
        <div>
            <div class="text-center" style="margin-top:40px;">
                <h1 id="siMati"></h1>
            </div>
            <div class="wrapper" style="margin-top:30px;">
                <ul class="StepProgress">
                    <li id="prog-1" class="StepProgress-item"><strong>Buka Fail</strong></li>
                    <li id="prog-2" class="StepProgress-item"><strong>Dokumentasi</strong></li>
                    <li id="prog-3" class="StepProgress-item"><strong>LA / Probate</strong></li>
                    <li id="prog-4" class="StepProgress-item"><strong>Pencairan</strong></li>
                    <li id="prog-5" class="StepProgress-item"><strong>Pembahagian</strong></li>
                    <li id="prog-6" class="StepProgress-item"><strong>Tutup Fail</strong></li>
                </ul>
            </div>
            <div style="margin-top:40px;">

                <table>
                    <thead>
                        <tr>
                            <th>No. Fail</th>
                            <th>Si Mati</th>
                            <th>No. KP</th>
                            <th>Tarikh Kematian</th>
                            <!-- <th>ID</th> -->
                        </tr>
                    </thead>
                    <tbody>
                        <tr id="item_maklumat_terperenci">
                        </tr>
                    </tbody>
                </table>
            </div>
            <div style="margin-top:40px;">

                <table>
                    <thead>
                        <tr>
                            <th>Tarikh</th>
                            <th>Status</th>
                            <th>Penerangan</th>
                            <th>Pegawai</th>
                            <!-- <th>ID</th> -->
                        </tr>
                    </thead>
                    <tbody id="item_sejarah">

                    </tbody>
                </table>
            </div>
            <div style=" margin-left:50%;margin-right:50%;">
                <button class="btn btn-primary btn-sm" onclick="close_popUp()">Close</button>

            </div>
        </div>
    </div>

</div>
</div>
<script src="../js/script.min.js"></script>
<script type="text/javascript">
    function onclick_view(id) {
        var text = "";
        var text2 = "";
        var sejarah = "";
        var siMati="";
        var buka_fail=false;
        var dokumentasi=false;
        var la_probate=false;
        var pencairan_aset=false;
        var pembahagian_aset=false;
        var tutupfail=false;

        var response1 = $.ajax({
            url: '../controller/api_maklumat_terperinci.php',
            type: 'POST',
            data: {
                id: id
            },
            async: false,
            success: function(data) {}
        }).responseText;
        if (response1 != null && response1 != "") {
            var json = JSON.parse(response1);
            text = "<td>" + json[0].m_nofail + "</td>" + "<td>" + json[0].sm_nama + "</td>" + "<td>" + json[0].sm_nric_new + "</td>" + "<td>" + json[0].sm_datemati + "</td>";
            siMati =json[0].sm_nama+"("+json[0].sm_nric_new+")";
            sejarah = json[0].m_nofail;
        }
        
        var response2 = $.ajax({
            url: '../controller/api_sejarah.php',
            type: 'POST',
            data: {
                id: sejarah
            },
            async: false,
            success: function(data) {}
        }).responseText;
        if (response2 != null && response2 != "") {

            var json2 = JSON.parse(response2);
            for (var i = 0; i < json2.length; i++) {
                text2 = text2 + "<tr><td>" + json2[i].s_tarikh + "</td>" + "<td>" + json2[i].s_status + "</td>" + "<td>" + json2[i].s_penerangan + "</td>" + "<td>" + json2[i].s_pegawai + "</td></tr>";
            if(json2[i].s_status=="Buka Fail")
            {
                buka_fail=true;
            }
            else if(json2[i].s_status=="Dokumentasi")
            {
                dokumentasi=true;
            }
            else if(json2[i].s_status=="LA / Probate")
            {
                la_probate=true;
            }
            else if(json2[i].s_status=="Pencairan")
            {
                pencairan_aset=true;
            }
            else if(json2[i].s_status=="Pembahagian")
            {
                pembahagian_aset=true;
            }
            else if(json2[i].s_status=="Tutup Fail")
            { 
                tutupfail=true;
            }
            }
        }
        if(tutupfail)
        {
            document.getElementById("prog-1").className = "StepProgress-item is-done";
            document.getElementById("prog-2").className = "StepProgress-item is-done";
            document.getElementById("prog-3").className = "StepProgress-item is-done";
            document.getElementById("prog-4").className = "StepProgress-item is-done";
            document.getElementById("prog-5").className = "StepProgress-item is-done";
            document.getElementById("prog-6").className = "StepProgress-item is-done";
        }
        else if(pembahagian_aset)
        {
            document.getElementById("prog-1").className = "StepProgress-item is-done";
            document.getElementById("prog-2").className = "StepProgress-item is-done";
            document.getElementById("prog-3").className = "StepProgress-item is-done";
            document.getElementById("prog-4").className = "StepProgress-item is-done";
            document.getElementById("prog-5").className = "StepProgress-item current";
            document.getElementById("prog-6").className = "StepProgress-item";
        }
        else if(pencairan_aset)
        {
            document.getElementById("prog-1").className = "StepProgress-item is-done";
            document.getElementById("prog-2").className = "StepProgress-item is-done";
            document.getElementById("prog-3").className = "StepProgress-item is-done";
            document.getElementById("prog-4").className = "StepProgress-item current";
            document.getElementById("prog-5").className = "StepProgress-item";
            document.getElementById("prog-6").className = "StepProgress-item";
        }
        else if(la_probate)
        {
            document.getElementById("prog-1").className = "StepProgress-item is-done";
            document.getElementById("prog-2").className = "StepProgress-item is-done";
            document.getElementById("prog-3").className = "StepProgress-item is-done";
            document.getElementById("prog-4").className = "StepProgress-item current";
            document.getElementById("prog-5").className = "StepProgress-item";
            document.getElementById("prog-6").className = "StepProgress-item";
        }
        else if(dokumentasi)
        {
            document.getElementById("prog-1").className = "StepProgress-item is-done";
            document.getElementById("prog-2").className = "StepProgress-item current";
            document.getElementById("prog-3").className = "StepProgress-item";
            document.getElementById("prog-4").className = "StepProgress-item";
            document.getElementById("prog-5").className = "StepProgress-item";
            document.getElementById("prog-6").className = "StepProgress-item";
        }
        else if(buka_fail)
        {
            document.getElementById("prog-1").className = "StepProgress-item current";
            document.getElementById("prog-2").className = "StepProgress-item";
            document.getElementById("prog-3").className = "StepProgress-item";
            document.getElementById("prog-4").className = "StepProgress-item";
            document.getElementById("prog-5").className = "StepProgress-item";
            document.getElementById("prog-6").className = "StepProgress-item";
        }
        else
        {
            document.getElementById("prog-1").className = "StepProgress-item";
            document.getElementById("prog-2").className = "StepProgress-item";
            document.getElementById("prog-3").className = "StepProgress-item";
            document.getElementById("prog-4").className = "StepProgress-item";
            document.getElementById("prog-5").className = "StepProgress-item";
            document.getElementById("prog-5").className = "StepProgress-item";
        }
        document.getElementById("item_maklumat_terperenci").innerHTML = text;
        document.getElementById("item_sejarah").innerHTML = text2;
        document.getElementById("siMati").innerHTML = siMati;
        document.getElementById("Lihat").style.display = "block";
    }

    function close_popUp() {
        document.getElementById("Lihat").style.display = "none";
    }
</script>