<!doctype html>
<html>
<head>
<meta charset="utf-8">

    <link href="https://fonts.googleapis.com/css?family=Roboto:100i,300,300i,400,700" rel="stylesheet">

    <!--============================= CSS =======================================-->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/font-awesome.min.css">
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
	<link rel="stylesheet" href="../css/navstyle.css">

    <script src="../js/jquery-3.2.1.slim.min.js"></script>
<title>Untitled Document</title>
</head>

<body>
	<div class="container">
										<div class="row">
												<div class="col-md-12">
													<br>
													<div class="section-title">
														<h3>8.0 Keterangan Mengenai Waris-Waris Simati</h3>
													</div>
													<h5>Nama Penuh/ (Seperti Dalam Kad Pengenalan) <span class="error"></span><p><input type="text" name="" value=""></p>
													</h5>
													<h5>Hubungan <span class="error"></span><p><input type="text" name="" value=""></p>
													</h5>
													<h5>No. KP <span class="error"></span><p><input type="text" name="" value=""></p>
													</h5>
													<h5>Alamat <span class="error"></span><p><input type="text" name="" value=""></p>
													</h5>
													<h5>No. Telefon Bimbit <span class="error"></span><p><input type="text" name="" value=""></p>
													</h5>
													<h5>No. Telfon Rumah <span class="error"></span><p><input type="text" name="" value=""></p>
													</h5>
													<h5>No. Telefon Bimbit <span class="error"></span><p><input type="text" name="" value=""></p>
													</h5>
													<h5>Emel <span class="error"></span><p><input type="text" name="" value=""></p>
													</h5>
												</div>
											</div>
										</div>
									</div>
								</div>
	<script src="../js/popper-1.12.9.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/owl.carousel.min.js"></script>
	<script src="../js/main.js"></script>
</body>
</html>