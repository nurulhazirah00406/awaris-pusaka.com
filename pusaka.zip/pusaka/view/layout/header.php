	<!--================= Header-area ======================-->
    <div class="header-area header-absoulate noPrint">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="logo">
                        <a href="">
                           
                            <span>AWARIS <span id="na">Amanah Warisan Berhad</span></span>
                        </a>
                    </div>
                </div>
    <!--================== Main menu-area ====================-->
                <div class="col-md-7">
                    <div class="main-menu">
                        <ul>
						    <li><a href="index.php">Halaman Utama</a></li>
						    <li><a href="permohonan.php">Pendaftaran Baru</a></li>
						    <li><a href="senarai_pusaka.php">Senarai Pusaka</a></li>
                            <li><a href="senarai_pemohon.php">Senarai Pemohon</a></li>
                            <li><a href="sejarah.php">Sejarah</a></li>
                            <?php
                            session_start();
                            // var_dump($_SESSION['username']); 
                            if (isset($_SESSION['username'])) {
                                echo '<li><a href="logout.php">Log Keluar</a></li>';
                            }else{
                                echo '<li><a href="login.php">Log Masuk</a></li>';
                            }?>
						</ul>
                    </div>
                </div>
                <div class="col-md-1 text-right">
                </div>
            </div>
        </div>
    </div>
    <!--======================= Slide-area =======================-->
    <div class="welcome-area noPrint">
        <div class="owl-carousel slider-content">
            <div class="single-slider-item slider-bg-1">
                <div class="slider-inner">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="slide-text">
                                    <h2>offers the best digital and shariah<br>trustee to our community.</h2>
                                    <p>Wasiat | Hibah | Harta Sepencarian | Amanah<br>
                                       | Pengurusan Harta Pusaka |
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="single-slider-item slider-bg-2">
                <div class="slider-inner">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="slide-text">
                                    <h2>Tulis Wasiat Anda Dengann Kami!</h2>
                                    <p>"The best way to ensure your children<br>future is to create it."
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--=========================== Content-area ============================-->
    <div class="content-area noPrint">
        <div class="container-fluid">
            <div class="row">
            </div>
        </div>
    </div>