    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title">
                    <h3>Borang Permohonan Perkhidmatan Pentadbiran Harta Pusaka</h3>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <h4>1.0 Keterangan Pemohon</h4>
                        <form action="../../epusaka/controller/functions.php" method="post">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="left-side-form">
                                        <h5><label for="namapenuh">Nama Penuh/ (Seperti Dalam Kad Pengenalan)</label>
                                        <span class="error"></span></h5>
                                        <p><input type="text" name="namapenuh" value=""></p>
                                        
                                        <h5><label for="nokp">No. KP. Baru</label><span class="error">
                                                </span></h5>
                                        <p><input type="text" name="nokp" value=""></p>
                                        
                                        <h5><label for="nokplama">No. KP Lama/Polis/Tentera/No. Pasport</label><span class="error">
                                                </span></h5>
                                        <p><input type="text" name="nokplama" value=""></p>

                                        <h5><label for="alamatsurat">Alamat Surat Menyurat </label><span class="error">
                                                </span></h5>
                                        <p><textarea name="alamatsurat" ></textarea></p>

                                        <h5><label for="alamattetap">Alamat Tetap</label><span class="error">
                                                </span></h5>
                                        <p><textarea name="alamattetap"></textarea></p>

                                        <h5><label for="notelrumah">No. Tel Rumah</label><span class="error">
                                                </span></h5>
                                        <p><input type="text" name="notelrumah" value=""></p>
                                        
                                        <h5><label for="notelbimbit">No. Tel Bimbit</label><span class="error">
                                                </span></h5>
                                        <p><input type="text" name="notelbimbit" value=""></p>
                                        
                                        <h5><label for="notelpejabat">No. Tel Pejabat</label><span class="error">
                                                </span></h5>
                                        <p><input type="text" name="notelpejabat" value=""></p>
                                        
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="right-side-form">

                                        <h5><label for="hubungansaudara">Perhubungan Persaudaraan Dengan Simati</label></h5>
                                        <input type="radio" name="hubungansaudara" value="Suami"><span>Suami</span>
                                        <input type="radio" name="hubungansaudara" value="Isteri"><span>Isteri</span>
                                        <input type="radio" name="hubungansaudara" value="Bapa"><span>Bapa</span>
                                        <input type="radio" name="hubungansaudara" value="Ibu"><span>Ibu</span>
                                        <input type="radio" name="hubungansaudara" value="Anak"><span>Anak</span>
                                        <input type="radio" name="hubungansaudara" value="Lain-lain"><span>Lain-lain</span>
                                        <span class="error">
                                            </span>


                                        
                                        <p><input type="submit" name="btn_mohon" value="Submit"></p>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>