<!DOCTYPE html>
<html>
	<head>
		<!-- Basic Page Info -->
		<meta charset="utf-8" />
		<title></title>

		<!-- CSS -->
		<link rel="stylesheet" type="text/css" href="../css/core.css" />
		<link rel="stylesheet" type="text/css" href="../css/styledashboard.css" />
		
	</head>
	<body>
 

		<div class="main-container">
				<div class="row clearfix progress-box">
					<div class="col-lg-3 col-md-6 col-sm-12 mb-30">
						<div class="card-box pd-30 height-100-p">
							<div class="progress-box text-center">
								<input
									type="text"
									class="knob dial1"
									value="80"
									data-width="120"
									data-height="120"
									data-linecap="round"
									data-thickness="0.12"
									data-bgColor="#fff"
									data-fgColor="#1b00ff"
									data-angleOffset="180"
									readonly
								/>
								<h5 class="text-blue padding-top-10 h5">Buka Fail</h5>
								<span class="d-block"
									>80% Average <i class="fa fa-line-chart text-blue"></i
								></span>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-12 mb-30">
						<div class="card-box pd-30 height-100-p">
							<div class="progress-box text-center">
								<input
									type="text"
									class="knob dial2"
									value="70"
									data-width="120"
									data-height="120"
									data-linecap="round"
									data-thickness="0.12"
									data-bgColor="#fff"
									data-fgColor="#1b00ff"
									data-angleOffset="180"
									readonly
								/>
								<h5 class="text-blue padding-top-10 h5">
									Dokumentasi
								</h5>
								<span class="d-block"
									>75% Average <i class="fa text-blue fa-line-chart"></i
								></span>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-12 mb-30">
						<div class="card-box pd-30 height-100-p">
							<div class="progress-box text-center">
								<input
									type="text"
									class="knob dial3"
									value="90"
									data-width="120"
									data-height="120"
									data-linecap="round"
									data-thickness="0.12"
									data-bgColor="#fff"
									data-fgColor="#1b00ff"
									data-angleOffset="180"
									readonly
								/>
								<h5 class="text-blue padding-top-10 h5">
									LA / Probate
								</h5>
								<span class="d-block"
									>90% Average <i class="fa text-blue fa-line-chart"></i
								></span>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-12 mb-30">
						<div class="card-box pd-30 height-100-p">
							<div class="progress-box text-center">
								<input
									type="text"
									class="knob dial4"
									value="65"
									data-width="120"
									data-height="120"
									data-linecap="round"
									data-thickness="0.12"
									data-bgColor="#fff"
									data-fgColor="#1b00ff"
									data-angleOffset="180"
									readonly
								/>
								<h5 class="text-blue padding-top-10 h5">
									Pencairan
								</h5>
								<span class="d-block"
									>65% Average <i class="fa text-blue fa-line-chart"></i
								></span>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-12 mb-30">
						<div class="card-box pd-30 height-100-p">
							<div class="progress-box text-center">
								<input
									type="text"
									class="knob dial2"
									value="70"
									data-width="120"
									data-height="120"
									data-linecap="round"
									data-thickness="0.12"
									data-bgColor="#fff"
									data-fgColor="#1b00ff"
									data-angleOffset="180"
									readonly
								/>
								<h5 class="text-blue padding-top-10 h5">
									Pembahagian
								</h5>
								<span class="d-block"
									>75% Average <i class="fa text-blue fa-line-chart"></i
								></span>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-12 mb-30">
						<div class="card-box pd-30 height-100-p">
							<div class="progress-box text-center">
								<input
									type="text"
									class="knob dial2"
									value="70"
									data-width="120"
									data-height="120"
									data-linecap="round"
									data-thickness="0.12"
									data-bgColor="#fff"
									data-fgColor="#1b00ff"
									data-angleOffset="180"
									readonly
								/>
								<h5 class="text-blue padding-top-10 h5">
									Tutup Fail
								</h5>
								<span class="d-block"
									>75% Average <i class="fa text-blue fa-line-chart"></i
								></span>
							</div>
						</div>
					</div>
				</div>

		</div>
		<!-- js -->
		<script src="../js/core.js"></script>
		<script src="../js/jquery.knob.min.js"></script>
		<script src="../js/dashboard.js"></script>
	</body>
</html>
