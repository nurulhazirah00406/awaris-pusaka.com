<!doctype html>
<html>
<head>
    <!--============================== Required meta tags ===========================-->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!--============================= Fonts =======================================-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100i,300,300i,400,700" rel="stylesheet">

    <!--============================= CSS =======================================-->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/font-awesome.min.css">
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/navstyle.css">

    <script src="../js/jquery-3.2.1.slim.min.js"></script>

    <title></title>
    <link rel="shourtcut icon" type="image/png" href="../img/image.png">
</head>
<body>

    <?php 
    require "layout/header.php";
    require "../controller/pages.php";
    $curPageName = substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1);  
    $curpage = strtok($curPageName,  '.');
    pages($curpage);
    require "layout/footer.php";
?>
    <script src="../js/popper-1.12.9.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/owl.carousel.min.js"></script>
    <script src="../js/main.js"></script>
</body>