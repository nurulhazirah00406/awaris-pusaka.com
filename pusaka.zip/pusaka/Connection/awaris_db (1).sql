-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 05, 2022 at 02:33 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `awaris_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `user_type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`, `email`, `user_type`) VALUES
(1, 'nas_rulhakim', 'Abcd1234!', 'hakimn13@gmail.com', 'staff'),
(2, 'abcd', 'e19d5cd5af0378da05f63f891c7467af', 'abcd@gmail.com', 'staff');

-- --------------------------------------------------------

--
-- Table structure for table `maklumat`
--

CREATE TABLE `maklumat` (
  `m_nofail` varchar(200) NOT NULL,
  `m_id` int(11) NOT NULL,
  `sm_id` int(11) NOT NULL,
  `m_status` varchar(200) NOT NULL,
  `m_keterangan` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `r_hartaalih`
--

CREATE TABLE `r_hartaalih` (
  `ha_id` int(11) NOT NULL,
  `sm_id` int(11) NOT NULL,
  `ha_jenis` varchar(150) NOT NULL,
  `ha_no_akaun` varchar(150) NOT NULL,
  `ha_anggaran` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `r_hrtxalih`
--

CREATE TABLE `r_hrtxalih` (
  `hx_id` int(11) NOT NULL,
  `sm_id` int(11) NOT NULL,
  `hx_jenis` varchar(150) NOT NULL,
  `hx_no_hakmilik` varchar(150) NOT NULL,
  `hx_no_lot` varchar(150) NOT NULL,
  `hx_mukim_bandar` varchar(150) NOT NULL,
  `hx_daerah_negeri` varchar(150) NOT NULL,
  `hx_bahagian` varchar(150) NOT NULL,
  `hx_anggaran` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `r_hutangsimati`
--

CREATE TABLE `r_hutangsimati` (
  `hs_id` int(11) NOT NULL,
  `sm_id` int(11) NOT NULL,
  `hs_jenis` varchar(150) NOT NULL,
  `hs_nama_alamat` varchar(150) NOT NULL,
  `hs_anggaran` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `r_infowasiat`
--

CREATE TABLE `r_infowasiat` (
  `iw_id` int(11) NOT NULL,
  `sm_id` int(11) NOT NULL,
  `iw_jenis` varchar(150) NOT NULL,
  `iw_nopendaftaran` varchar(150) NOT NULL,
  `iw_tmptsimpan` varchar(150) NOT NULL,
  `iw_wasi` varchar(150) NOT NULL,
  `iw_nama` varchar(150) NOT NULL,
  `iw_nric_new` varchar(150) NOT NULL,
  `iw_nric_old` varchar(150) NOT NULL,
  `iw_umur` varchar(150) NOT NULL,
  `iw_birthdate` varchar(150) NOT NULL,
  `iw_alamat_surat` varchar(150) NOT NULL,
  `iw_alamat_tetap` varchar(150) NOT NULL,
  `iw_poskod` varchar(150) NOT NULL,
  `iw_negeri` varchar(150) NOT NULL,
  `iw_tel_rumah` varchar(150) NOT NULL,
  `iw_tel_bimbit` varchar(150) NOT NULL,
  `iw_tel_pjbt` varchar(150) NOT NULL,
  `iw_hubungan` varchar(150) NOT NULL,
  `iw_surat_poskod` varchar(150) NOT NULL,
  `iw_surat_negeri` varchar(150) NOT NULL,
  `iw_emel` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `r_pemohon`
--

CREATE TABLE `r_pemohon` (
  `p_id` int(11) NOT NULL,
  `p_nama` varchar(150) NOT NULL,
  `p_nric_new` varchar(150) NOT NULL,
  `p_nric_old` varchar(150) NOT NULL,
  `p_age` varchar(150) NOT NULL,
  `p_birthdate` varchar(150) NOT NULL,
  `p_alamat_surat` varchar(150) NOT NULL,
  `p_poskod_surat` varchar(150) NOT NULL,
  `p_negeri_surat` varchar(150) NOT NULL,
  `p_alamat` varchar(150) NOT NULL,
  `p_poskod` varchar(150) NOT NULL,
  `p_negeri` varchar(150) NOT NULL,
  `p_tel_rumah` varchar(150) NOT NULL,
  `p_tel_bimbit` varchar(150) NOT NULL,
  `p_tel_pejabat` varchar(150) NOT NULL,
  `p_emel` varchar(255) NOT NULL,
  `p_hubungan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `r_pemohon`
--

INSERT INTO `r_pemohon` (`p_id`, `p_nama`, `p_nric_new`, `p_nric_old`, `p_age`, `p_birthdate`, `p_alamat_surat`, `p_poskod_surat`, `p_negeri_surat`, `p_alamat`, `p_poskod`, `p_negeri`, `p_tel_rumah`, `p_tel_bimbit`, `p_tel_pejabat`, `p_emel`, `p_hubungan`) VALUES
(1, 'Nasrul Hakim', '960901145169', '', '26', '01/09/1996', '29, lorong mahkota impian 2/18', '42300', 'selangor', '29, lorong mahkota impian 2/18', '42300', 'selangor', '-', '0132484996', '-', '0', '0'),
(3, 'Pemohon 1', '9621312021312', '-', '28', '1992-06-19', '29, lorong cakera purnama', '43112', 'Johor', '29, lorong cakera purnama', '43112', 'Johor', '-', '01324566742', '-', '', 'Anak'),
(4, 'Pemohon 1', '9621312021312', '-', '28', '19/06/1992', '29, lorong cakera purnama', '43112', 'Johor', '29, lorong cakera purnama', '43112', 'Johor', '-', '01324566742', '-', '', 'Anak'),
(5, 'Pemohon 1', '9621312021312', '-', '28', '19/06/1992', '29, lorong cakera purnama', '43112', 'Johor', '29, lorong cakera purnama', '43112', 'Johor', '-', '01324566742', '-', '', 'Anak'),
(6, 'Pemohon 1', '9621312021312', '-', '28', '19/06/1992', '29, lorong cakera purnama', '43112', 'Johor', '29, lorong cakera purnama', '43112', 'Johor', '-', '01324566742', '-', '', 'Anak'),
(7, 'Pemohon 1', '9621312021312', '-', '28', '19/06/1992', '29, lorong cakera purnama', '43112', 'Johor', '29, lorong cakera purnama', '43112', 'Johor', '-', '01324566742', '-', '', 'Anak'),
(8, 'Pemohon 1', '9621312021312', '-', '28', '19/06/1992', '29, lorong cakera purnama', '43112', 'Johor', '29, lorong cakera purnama', '43112', 'Johor', '-', '01324566742', '-', '', 'Anak'),
(9, 'Pemohon 1', '9621312021312', '-', '28', '19/06/1992', '29, lorong cakera purnama', '43112', 'Johor', '29, lorong cakera purnama', '43112', 'Johor', '-', '01324566742', '-', '', 'Anak');

-- --------------------------------------------------------

--
-- Table structure for table `r_penghutangsimati`
--

CREATE TABLE `r_penghutangsimati` (
  `ps_id` int(11) NOT NULL,
  `sm_id` int(11) NOT NULL,
  `ps_jenis` varchar(150) NOT NULL,
  `ps_nama_alamat` varchar(150) NOT NULL,
  `ps_anggaran` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `r_penjagawaris`
--

CREATE TABLE `r_penjagawaris` (
  `pw_id` int(11) NOT NULL,
  `sm_id` int(11) NOT NULL,
  `pw_nama` varchar(150) NOT NULL,
  `pw_nric_new` varchar(150) NOT NULL,
  `pw_birthdate` varchar(150) NOT NULL,
  `pw_nric_old` varchar(150) NOT NULL,
  `pw_alamat_tetap` varchar(150) NOT NULL,
  `pw_poskod` varchar(150) NOT NULL,
  `pw_negeri` varchar(150) NOT NULL,
  `pw_notel_rumah` varchar(150) NOT NULL,
  `pw_notel_bimbit` varchar(150) NOT NULL,
  `pw_notel_pjbt` varchar(150) NOT NULL,
  `pw_emel` varchar(150) NOT NULL,
  `pw_hubungan` varchar(150) NOT NULL,
  `pw_umur` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `r_simati`
--

CREATE TABLE `r_simati` (
  `sm_id` int(11) NOT NULL,
  `p_id` int(11) NOT NULL,
  `sm_nama` varchar(150) NOT NULL,
  `sm_nric_new` varchar(150) NOT NULL,
  `sm_nric_old` varchar(150) NOT NULL,
  `sm_jantina` varchar(150) NOT NULL,
  `sm_datemati` varchar(150) NOT NULL,
  `sm_sbbmati` varchar(150) NOT NULL,
  `sm_tmptmati` varchar(150) NOT NULL,
  `sm_taraf_perkhawinan` varchar(150) NOT NULL,
  `sm_warganegara` varchar(150) NOT NULL,
  `sm_agama` varchar(150) NOT NULL,
  `sm_bangsa` varchar(150) NOT NULL,
  `sm_muflis` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `r_waris_wasiatsimati`
--

CREATE TABLE `r_waris_wasiatsimati` (
  `ww_id` int(11) NOT NULL,
  `sm_id` int(11) NOT NULL,
  `ww_nama` varchar(150) NOT NULL,
  `ww_hubungan` varchar(150) NOT NULL,
  `ww_alamat` varchar(150) NOT NULL,
  `ww_nric` varchar(150) NOT NULL,
  `ww_notel_rumah` varchar(150) NOT NULL,
  `ww_notel_pejabat` varchar(150) NOT NULL,
  `ww_notel_bimbit` varchar(150) NOT NULL,
  `ww_emel` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `sejarah`
--

CREATE TABLE `sejarah` (
  `s_id` int(11) NOT NULL,
  `s_nofail` varchar(200) NOT NULL,
  `s_status` varchar(200) NOT NULL,
  `s_tarikh` varchar(200) NOT NULL,
  `s_penerangan` varchar(200) NOT NULL,
  `s_pegawai` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `maklumat`
--
ALTER TABLE `maklumat`
  ADD PRIMARY KEY (`m_id`);

--
-- Indexes for table `r_hartaalih`
--
ALTER TABLE `r_hartaalih`
  ADD PRIMARY KEY (`ha_id`);

--
-- Indexes for table `r_hrtxalih`
--
ALTER TABLE `r_hrtxalih`
  ADD PRIMARY KEY (`hx_id`);

--
-- Indexes for table `r_hutangsimati`
--
ALTER TABLE `r_hutangsimati`
  ADD PRIMARY KEY (`hs_id`);

--
-- Indexes for table `r_infowasiat`
--
ALTER TABLE `r_infowasiat`
  ADD PRIMARY KEY (`iw_id`);

--
-- Indexes for table `r_pemohon`
--
ALTER TABLE `r_pemohon`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `r_penghutangsimati`
--
ALTER TABLE `r_penghutangsimati`
  ADD PRIMARY KEY (`ps_id`);

--
-- Indexes for table `r_penjagawaris`
--
ALTER TABLE `r_penjagawaris`
  ADD PRIMARY KEY (`pw_id`);

--
-- Indexes for table `r_simati`
--
ALTER TABLE `r_simati`
  ADD PRIMARY KEY (`sm_id`);

--
-- Indexes for table `r_waris_wasiatsimati`
--
ALTER TABLE `r_waris_wasiatsimati`
  ADD PRIMARY KEY (`ww_id`);

--
-- Indexes for table `sejarah`
--
ALTER TABLE `sejarah`
  ADD PRIMARY KEY (`s_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `maklumat`
--
ALTER TABLE `maklumat`
  MODIFY `m_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `r_hartaalih`
--
ALTER TABLE `r_hartaalih`
  MODIFY `ha_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `r_hrtxalih`
--
ALTER TABLE `r_hrtxalih`
  MODIFY `hx_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `r_pemohon`
--
ALTER TABLE `r_pemohon`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `r_simati`
--
ALTER TABLE `r_simati`
  MODIFY `sm_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
