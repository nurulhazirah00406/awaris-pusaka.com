-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 16, 2022 at 04:18 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `awaris_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `user_type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`, `email`, `user_type`) VALUES
(1, 'nas_rulhakim', 'Abcd1234!', 'hakimn13@gmail.com', 'staff'),
(2, 'abcd', 'e19d5cd5af0378da05f63f891c7467af', 'abcd@gmail.com', 'staff');

-- --------------------------------------------------------

--
-- Table structure for table `maklumat`
--

CREATE TABLE `maklumat` (
  `m_nofail` varchar(200) NOT NULL,
  `m_id` int(11) NOT NULL,
  `sm_id` int(11) NOT NULL,
  `m_status` varchar(200) NOT NULL,
  `m_keterangan` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `maklumat`
--

INSERT INTO `maklumat` (`m_nofail`, `m_id`, `sm_id`, `m_status`, `m_keterangan`) VALUES
('A00024', 25, 24, 'Dokumentasi', 'Permohonan Baru pada 10/10/2022 16:31:50'),
('A00025', 26, 25, 'Dokumentasi', 'Permohonan Baru pada 16/10/2022 04:10:01');

-- --------------------------------------------------------

--
-- Table structure for table `r_hartaalih`
--

CREATE TABLE `r_hartaalih` (
  `ha_id` int(11) NOT NULL,
  `sm_id` int(11) NOT NULL,
  `ha_jenis` varchar(150) NOT NULL,
  `ha_no_akaun` varchar(150) NOT NULL,
  `ha_anggaran` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `r_hartaalih`
--

INSERT INTO `r_hartaalih` (`ha_id`, `sm_id`, `ha_jenis`, `ha_no_akaun`, `ha_anggaran`) VALUES
(1, 26, 'saham', 'kwsp1 sasasd', 312123),
(2, 26, 'sdasd', 'dsadasd', 321),
(3, 26, 'saham', 'kwsp1 sasasd', 312123),
(4, 26, 'sdasd', 'dsadasd', 321),
(5, 26, 'saham', 'kwsp1 sasasd', 312123),
(6, 26, 'sdasd', 'dsadasd', 321),
(7, 26, 'saham', 'kwsp1 sasasd', 312123),
(8, 26, 'sdasd', 'dsadasd', 321);

-- --------------------------------------------------------

--
-- Table structure for table `r_hrtxalih`
--

CREATE TABLE `r_hrtxalih` (
  `hx_id` int(11) NOT NULL,
  `sm_id` int(11) NOT NULL,
  `hx_jenis` varchar(150) NOT NULL,
  `hx_no_hakmilik` varchar(150) NOT NULL,
  `hx_no_lot` varchar(150) NOT NULL,
  `hx_mukim_bandar` varchar(150) NOT NULL,
  `hx_daerah_negeri` varchar(150) NOT NULL,
  `hx_bahagian` varchar(150) NOT NULL,
  `hx_anggaran` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `r_hrtxalih`
--

INSERT INTO `r_hrtxalih` (`hx_id`, `sm_id`, `hx_jenis`, `hx_no_hakmilik`, `hx_no_lot`, `hx_mukim_bandar`, `hx_daerah_negeri`, `hx_bahagian`, `hx_anggaran`) VALUES
(1, 26, 'rumah', '3123', 'ddasd', 'asda', 'sdasdas', 'asdas', 3123),
(2, 26, 'rumah', '312', 'dasd', 'dasda', 'dasd', 'asdas', 312),
(3, 26, 'rumah', '3123', 'ddasd', 'asda', 'sdasdas', 'asdas', 3123),
(4, 26, 'rumah', '312', 'dasd', 'dasda', 'dasd', 'asdas', 312),
(5, 26, 'rumah', '3123', 'ddasd', 'asda', 'sdasdas', 'asdas', 3123),
(6, 26, 'rumah', '312', 'dasd', 'dasda', 'dasd', 'asdas', 312),
(7, 26, 'rumah', '3123', 'ddasd', 'asda', 'sdasdas', 'asdas', 3123),
(8, 26, 'rumah', '312', 'dasd', 'dasda', 'dasd', 'asdas', 312);

-- --------------------------------------------------------

--
-- Table structure for table `r_hutangsimati`
--

CREATE TABLE `r_hutangsimati` (
  `hs_id` int(11) NOT NULL,
  `sm_id` int(11) NOT NULL,
  `hs_jenis` varchar(150) NOT NULL,
  `hs_nama_alamat` varchar(150) NOT NULL,
  `hs_anggaran` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `r_hutangsimati`
--

INSERT INTO `r_hutangsimati` (`hs_id`, `sm_id`, `hs_jenis`, `hs_nama_alamat`, `hs_anggaran`) VALUES
(1, 26, 'harta hutang si mati 1', 'pemiutang 1', 31231),
(2, 26, 'harta hutang si mati 2', 'pemiutang 2', 4353),
(3, 26, 'harta hutang si mati 1', 'pemiutang 1', 31231),
(4, 26, 'harta hutang si mati 2', 'pemiutang 2', 4353);

-- --------------------------------------------------------

--
-- Table structure for table `r_infowasiat`
--

CREATE TABLE `r_infowasiat` (
  `iw_id` int(11) NOT NULL,
  `sm_id` int(11) NOT NULL,
  `iw_jenis` varchar(150) NOT NULL,
  `iw_nopendaftaran` varchar(150) NOT NULL,
  `iw_tmptsimpan` varchar(150) NOT NULL,
  `iw_wasi` varchar(150) NOT NULL,
  `iw_nama` varchar(150) NOT NULL,
  `iw_nric_new` varchar(150) NOT NULL,
  `iw_nric_old` varchar(150) NOT NULL,
  `iw_umur` varchar(150) NOT NULL,
  `iw_birthdate` varchar(150) NOT NULL,
  `iw_alamat_surat` varchar(150) NOT NULL,
  `iw_alamat_tetap` varchar(150) NOT NULL,
  `iw_poskod` varchar(150) NOT NULL,
  `iw_negeri` varchar(150) NOT NULL,
  `iw_tel_rumah` varchar(150) NOT NULL,
  `iw_tel_bimbit` varchar(150) NOT NULL,
  `iw_tel_pjbt` varchar(150) NOT NULL,
  `iw_hubungan` varchar(150) NOT NULL,
  `iw_surat_poskod` varchar(150) NOT NULL,
  `iw_surat_negeri` varchar(150) NOT NULL,
  `iw_emel` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `r_infowasiat`
--

INSERT INTO `r_infowasiat` (`iw_id`, `sm_id`, `iw_jenis`, `iw_nopendaftaran`, `iw_tmptsimpan`, `iw_wasi`, `iw_nama`, `iw_nric_new`, `iw_nric_old`, `iw_umur`, `iw_birthdate`, `iw_alamat_surat`, `iw_alamat_tetap`, `iw_poskod`, `iw_negeri`, `iw_tel_rumah`, `iw_tel_bimbit`, `iw_tel_pjbt`, `iw_hubungan`, `iw_surat_poskod`, `iw_surat_negeri`, `iw_emel`) VALUES
(1, 26, 'wasiatlisan', 'tiada', 'amanah raya', 'wasi 1', 'nama wasi 1', 'no kp wasi 1', '-', '36', '16/06/1981', 'alamat wasi 1', 'alamat tetap wasi', 'poskod wasi 1', '', '-', '-', '-', 'Lain-lain', 'poskod wasi 1', 'negeri wasi 1', '-');

-- --------------------------------------------------------

--
-- Table structure for table `r_pemohon`
--

CREATE TABLE `r_pemohon` (
  `p_id` int(11) NOT NULL,
  `p_nama` varchar(150) NOT NULL,
  `p_nric_new` varchar(150) NOT NULL,
  `p_nric_old` varchar(150) NOT NULL,
  `p_age` varchar(150) NOT NULL,
  `p_birthdate` varchar(150) NOT NULL,
  `p_alamat_surat` varchar(150) NOT NULL,
  `p_poskod_surat` varchar(150) NOT NULL,
  `p_negeri_surat` varchar(150) NOT NULL,
  `p_alamat` varchar(150) NOT NULL,
  `p_poskod` varchar(150) NOT NULL,
  `p_negeri` varchar(150) NOT NULL,
  `p_tel_rumah` varchar(150) NOT NULL,
  `p_tel_bimbit` varchar(150) NOT NULL,
  `p_tel_pejabat` varchar(150) NOT NULL,
  `p_emel` varchar(255) NOT NULL,
  `p_hubungan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `r_pemohon`
--

INSERT INTO `r_pemohon` (`p_id`, `p_nama`, `p_nric_new`, `p_nric_old`, `p_age`, `p_birthdate`, `p_alamat_surat`, `p_poskod_surat`, `p_negeri_surat`, `p_alamat`, `p_poskod`, `p_negeri`, `p_tel_rumah`, `p_tel_bimbit`, `p_tel_pejabat`, `p_emel`, `p_hubungan`) VALUES
(15, 'Pemohon 1', '9621312021312', '-', '32', '28/06/1989', 'pemohon 1', '45234', 'Johor', 'sdasdas', '21312', 'Johor', '-', '', '-', '', 'Ibu'),
(16, 'nama penuh 1', 'no kp bar 1', 'no kp lama 1', 'umur 1', '28/09/2022', '-', '-', '-', 'alamat tetap 1', 'poskod 1', 'negeri 1', '-', '-', '-', '', 'Suami');

-- --------------------------------------------------------

--
-- Table structure for table `r_penghutangsimati`
--

CREATE TABLE `r_penghutangsimati` (
  `ps_id` int(11) NOT NULL,
  `sm_id` int(11) NOT NULL,
  `ps_jenis` varchar(150) NOT NULL,
  `ps_nama_alamat` varchar(150) NOT NULL,
  `ps_anggaran` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `r_penghutangsimati`
--

INSERT INTO `r_penghutangsimati` (`ps_id`, `sm_id`, `ps_jenis`, `ps_nama_alamat`, `ps_anggaran`) VALUES
(1, 26, 'jenis hutang 1', 'nama penghutang 1', 31321),
(2, 26, 'jenis hutang 2', 'nama penghutang 2', 1343),
(3, 26, 'jenis hutang 1', 'nama penghutang 1', 31321),
(4, 26, 'jenis hutang 2', 'nama penghutang 2', 1343);

-- --------------------------------------------------------

--
-- Table structure for table `r_penjagawaris`
--

CREATE TABLE `r_penjagawaris` (
  `pw_id` int(11) NOT NULL,
  `sm_id` int(11) NOT NULL,
  `pw_nama` varchar(150) NOT NULL,
  `pw_nric_new` varchar(150) NOT NULL,
  `pw_birthdate` varchar(150) NOT NULL,
  `pw_nric_old` varchar(150) NOT NULL,
  `pw_alamat_tetap` varchar(150) NOT NULL,
  `pw_poskod` varchar(150) NOT NULL,
  `pw_negeri` varchar(150) NOT NULL,
  `pw_notel_rumah` varchar(150) NOT NULL,
  `pw_notel_bimbit` varchar(150) NOT NULL,
  `pw_notel_pjbt` varchar(150) NOT NULL,
  `pw_emel` varchar(150) NOT NULL,
  `pw_hubungan` varchar(150) NOT NULL,
  `pw_umur` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `r_simati`
--

CREATE TABLE `r_simati` (
  `sm_id` int(11) NOT NULL,
  `p_id` int(11) NOT NULL,
  `sm_nama` varchar(150) NOT NULL,
  `sm_nric_new` varchar(150) NOT NULL,
  `sm_nric_old` varchar(150) NOT NULL,
  `sm_jantina` varchar(150) NOT NULL,
  `sm_datemati` varchar(150) NOT NULL,
  `sm_sbbmati` varchar(150) NOT NULL,
  `sm_tmptmati` varchar(150) NOT NULL,
  `sm_taraf_perkhawinan` varchar(150) NOT NULL,
  `sm_warganegara` varchar(150) NOT NULL,
  `sm_agama` varchar(150) NOT NULL,
  `sm_bangsa` varchar(150) NOT NULL,
  `sm_muflis` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `r_simati`
--

INSERT INTO `r_simati` (`sm_id`, `p_id`, `sm_nama`, `sm_nric_new`, `sm_nric_old`, `sm_jantina`, `sm_datemati`, `sm_sbbmati`, `sm_tmptmati`, `sm_taraf_perkhawinan`, `sm_warganegara`, `sm_agama`, `sm_bangsa`, `sm_muflis`) VALUES
(24, 15, 'simati 1', '1235643442', '-', 'Perempuan', '27/09/2022', 'Biasa', 'jfgsjkdf', 'Bujang', 'Malaysia', 'Islam', 'Melayu', 'Tidak'),
(25, 16, 'nama penuh si mati 1', 'kp si mati 1', 'kp lama si mati 1', 'Lelaki', '28/09/2022', 'Kemalangan', 'highway', 'Bujang', 'Malaysia', 'Islam', 'Melayu', 'Tidak');

-- --------------------------------------------------------

--
-- Table structure for table `r_waris_wasiatsimati`
--

CREATE TABLE `r_waris_wasiatsimati` (
  `ww_id` int(11) NOT NULL,
  `sm_id` int(11) NOT NULL,
  `ww_nama` varchar(150) NOT NULL,
  `ww_hubungan` varchar(150) NOT NULL,
  `ww_alamat` varchar(150) NOT NULL,
  `ww_nric` varchar(150) NOT NULL,
  `ww_notel_rumah` varchar(150) NOT NULL,
  `ww_notel_pejabat` varchar(150) NOT NULL,
  `ww_notel_bimbit` varchar(150) NOT NULL,
  `ww_emel` varchar(150) NOT NULL,
  `ww_waris_type` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `r_waris_wasiatsimati`
--

INSERT INTO `r_waris_wasiatsimati` (`ww_id`, `sm_id`, `ww_nama`, `ww_hubungan`, `ww_alamat`, `ww_nric`, `ww_notel_rumah`, `ww_notel_pejabat`, `ww_notel_bimbit`, `ww_emel`, `ww_waris_type`) VALUES
(1, 26, 'waris 1', 'anak', 'dasda', '', '-', '-', '-', '-', 1),
(2, 26, 'asdasd', 'wetwef', 'sfsd', 'feffdsfsd', '-', '-', '-', '-', 3),
(3, 26, 'waris 1', 'anak', 'dasda', '', '-', '-', '-', '-', 1),
(4, 26, 'asdasd', 'wetwef', 'sfsd', 'feffdsfsd', '-', '-', '-', '-', 3);

-- --------------------------------------------------------

--
-- Table structure for table `sejarah`
--

CREATE TABLE `sejarah` (
  `s_id` int(11) NOT NULL,
  `s_nofail` varchar(200) NOT NULL,
  `s_status` varchar(200) NOT NULL,
  `s_tarikh` varchar(200) NOT NULL,
  `s_penerangan` varchar(200) NOT NULL,
  `s_pegawai` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sejarah`
--

INSERT INTO `sejarah` (`s_id`, `s_nofail`, `s_status`, `s_tarikh`, `s_penerangan`, `s_pegawai`) VALUES
(7, 'A00024', 'Dokumentasi', '10/10/2022 16:31:50', 'Permohonan Baru pada 10/10/2022 16:31:50', 'abcd'),
(8, 'A00025', 'Dokumentasi', '16/10/2022 04:10:01', 'Permohonan Baru pada 16/10/2022 04:10:01', 'abcd');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `maklumat`
--
ALTER TABLE `maklumat`
  ADD PRIMARY KEY (`m_id`);

--
-- Indexes for table `r_hartaalih`
--
ALTER TABLE `r_hartaalih`
  ADD PRIMARY KEY (`ha_id`);

--
-- Indexes for table `r_hrtxalih`
--
ALTER TABLE `r_hrtxalih`
  ADD PRIMARY KEY (`hx_id`);

--
-- Indexes for table `r_hutangsimati`
--
ALTER TABLE `r_hutangsimati`
  ADD PRIMARY KEY (`hs_id`);

--
-- Indexes for table `r_infowasiat`
--
ALTER TABLE `r_infowasiat`
  ADD PRIMARY KEY (`iw_id`);

--
-- Indexes for table `r_pemohon`
--
ALTER TABLE `r_pemohon`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `r_penghutangsimati`
--
ALTER TABLE `r_penghutangsimati`
  ADD PRIMARY KEY (`ps_id`);

--
-- Indexes for table `r_penjagawaris`
--
ALTER TABLE `r_penjagawaris`
  ADD PRIMARY KEY (`pw_id`);

--
-- Indexes for table `r_simati`
--
ALTER TABLE `r_simati`
  ADD PRIMARY KEY (`sm_id`);

--
-- Indexes for table `r_waris_wasiatsimati`
--
ALTER TABLE `r_waris_wasiatsimati`
  ADD PRIMARY KEY (`ww_id`);

--
-- Indexes for table `sejarah`
--
ALTER TABLE `sejarah`
  ADD PRIMARY KEY (`s_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `maklumat`
--
ALTER TABLE `maklumat`
  MODIFY `m_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `r_hartaalih`
--
ALTER TABLE `r_hartaalih`
  MODIFY `ha_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `r_hrtxalih`
--
ALTER TABLE `r_hrtxalih`
  MODIFY `hx_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `r_hutangsimati`
--
ALTER TABLE `r_hutangsimati`
  MODIFY `hs_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `r_infowasiat`
--
ALTER TABLE `r_infowasiat`
  MODIFY `iw_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `r_pemohon`
--
ALTER TABLE `r_pemohon`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `r_penghutangsimati`
--
ALTER TABLE `r_penghutangsimati`
  MODIFY `ps_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `r_penjagawaris`
--
ALTER TABLE `r_penjagawaris`
  MODIFY `pw_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `r_simati`
--
ALTER TABLE `r_simati`
  MODIFY `sm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `r_waris_wasiatsimati`
--
ALTER TABLE `r_waris_wasiatsimati`
  MODIFY `ww_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sejarah`
--
ALTER TABLE `sejarah`
  MODIFY `s_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
