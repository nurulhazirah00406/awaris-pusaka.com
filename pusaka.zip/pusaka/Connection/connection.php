<?php
  //database connection
  $conn = new mysqli('localhost','root','','awaris_db');

  if ($conn -> connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
    exit();
  }else{
    $GLOBALS["conn"] = $conn;
    return $conn;
  }

 // if ($result = $conn -> query("SELECT * FROM r_pemohon")) {
 //   echo "Returned rows are: " . $result -> num_rows;
 //   // Free result set
 //   $result -> free_result();
 // }

 // $conn -> close();
   
?>