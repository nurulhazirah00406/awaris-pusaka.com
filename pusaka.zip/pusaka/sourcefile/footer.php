<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
	
	<link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/font-awesome.min.css">
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
	<link rel="stylesheet" href="../css/navstyle.css">
</head>

<body>
	    <!--========================== Footer-area ===============================-->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="widget">
                        <div class="logo">
                            <a href="">
                                <span>Operation Hours</span>
                            </a>
                            <p> 9:00a.m - 5:00p.m
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="widget">
                        <h3>Navigation 📍</h3>
                        <div class="footer-menu">
                            <ul>
                                <li><a href="#">8Trium, M2-12-03, Menara 2,<br> Jalan Cempaka SD 12/5,<br> Bandar Sri Damansara, <br>52200 Kuala Lumpur, Selangor</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <h3>Contact Us</h3>
                    <span class="social-icon">
                        <a href=""><i class="fa fa-facebook"></i></a>
                        <a href=""><i class="fa fa-google-plus"></i></a>
                    </span>
                </div>
                <p class="copy-right">Copyright &copy;hazirah:3 | 2022</p>
            </div>
        </div>
    </footer>
</body>
</html>