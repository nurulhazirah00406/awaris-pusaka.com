<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Halaman Utama - AWARIS</title>
	
	<?php include('../sourcefile/navbar.php') ?>
	
	<link rel="stylesheet" type="text/css" href="../css/styleborang.css">
	<link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/font-awesome.min.css">
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
</head>

<body>

	
	<?php include('../sourcefile/footer.php')?>
</body>
</html>