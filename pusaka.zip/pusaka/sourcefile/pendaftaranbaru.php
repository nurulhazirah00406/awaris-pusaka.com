<?php

   $namapenuh=$_POST['namapenuh'];
   $nokp=$_POST['nokp'];
   $nokplama=$_POST['nokplama'];
   $umur=$_POST['umur'];
   $tarikhlahir=$_POST['tarikhlahir'];
   $alamatsurat=$_POST['alamatsurat'];
   $alamattetap=$_POST['alamattetap'];
   $notelrumah=$_POST['notelrumah'];
   $notelbimbit=$_POST['notelbimbit']; 
   $notelpejabat=$_POST['notelpejabat'];
   $hubungansaudara=$_POST['hubungansaudara'];
   $emel=$_POST['emel'];

?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Pendaftaran Baru - AWARIS</title>
		<link rel="stylesheet" type="text/css">
</head>

	<?php
include_once '../Connection/connection.php';
?>
	<body>
		<?php include ('../sourcefile/navbar.css')?>
		
		
    <div class="container">
      <div class="row col-md-6 col-md-offset-3">
        <div class="panel panel-primary">
          <div class="panel-heading text-center">
            <h1> Borang Permohonan Perkhidmatan Pentadbiran Harta Pusaka</h1>
          </div>
          <div class="panel-body">
            <form action="" method="post">
              <div class="../Connection/connection.php">
                <label for="namapenuh">Nama Penuh(Seperti Dalam Kad Pengenalan)</label>
                <input
                  type="text"
                  class="form-control"
                  id="namapenuh"
                  name="namapenuh"
                />
              </div>
              <div class="form-group">
                <label for="nokp">No. KP. Baru</label>
                <input
                  type="text"
                  class="form-control"
                  id="nokp"
                  name="nokp"
                />
              </div>
				<div class="form-group">
                <label for="nokplama">No. KP. Lama/Polis/Tentera/No.Pasport</label>
                <input
                  type="text"
                  class="form-control"
                  id="nokplama"
                  name="nokplama"
                />
              </div>
				<div class="form-group">
                <label for="umur">Umur</label>
                <input
                  type="text"
                  class="form-control"
                  id="umur"
                  name="umur"
                />
              </div>
				<div class="form-group">
                <label for="tarikhlahir">Tarikh Lahir</label>
                <input
                  type="text"
                  class="form-control"
                  id="tarikhlahir"
                  name="tarikhlahir"
                />
              </div>
				<div class="form-group">
                <label for="alamatsurat">Alamat Surat Menyurat</label>
                <input
                  type="text"
                  class="form-control"
                  id="alamatsurat"
                  name="alamatsurat"
                />
              </div>
				<div class="form-group">
                <label for="alamattetap">Alamat Tetap</label>
                <input
                  type="text"
                  class="form-control"
                  id="alamattetap"
                  name="alamattetap"
                />
              </div>
				<div class="form-group">
                <label for="notelrumah">No. Tel Rumah</label>
                <input
                  type="text"
                  class="form-control"
                  id="notelrumah"
                  name="notelrumah"
                />
              </div>
				<div class="form-group">
                <label for="notelbimbit">No. Tel Bimbit</label>
                <input
                  type="text"
                  class="form-control"
                  id="notelbimbit"
                  name="notelbimbit"
                />
              </div>
				<div class="form-group">
                <label for="notelpejabat">No. Tel Pejabat</label>
                <input
                  type="text"
                  class="form-control"
                  id="notelpejabat"
                  name="notelpejabat"
                />
              </div>
              <div class="form-group">
                <label for="hubungansaudara">Perhubungan Persaudaraan Dengan Simati</label>
                <div>
                  <label for="suami" class="radio-inline"
                    ><input
                      type="radio"
                      name="hubungansaudara"
                      value="s"
                      id="suami"
                    />Suami</label
                  >
                  <label for="isteri" class="radio-inline"
                    ><input
                      type="radio"
                      name="hubungansaudara"
                      value="i"
                      id="isteri"
                    />Isteri</label
                  >
                  <label for="bapa" class="radio-inline"
                    ><input
                      type="radio"
                      name="hubungansaudara"
                      value="b"
                      id="bapa"
                    />Bapa</label
                  >
					<label for="ibu" class="radio-inline"
                    ><input
                      type="radio"
                      name="hubungansaudara"
                      value="i"
                      id="ibu"
                    />Ibu</label
                  >
					<label for="anak" class="radio-inline"
                    ><input
                      type="radio"
                      name="hubungansaudara"
                      value="a"
                      id="anak"
                    />Anak</label
                  >
					<label for="lain-lain" class="radio-inline"
                    ><input
                      type="radio"
                      name="hubungansaudara"
                      value="l"
                      id="lain-lain"
                    />Lain-lain</label
                  >
                </div>
              </div>
              <div class="form-group">
                <label for="emel">E-mel</label>
                <input
                  type="text"
                  class="form-control"
                  id="emel"
                  name="emel"
                />
              </div>
              <input type="submit" class="btn btn-primary" />
            </form>
          </div>
          <div class="panel-footer text-right">
            <small>&copy; Manage by AWARIS</small>
          </div>
        </div>
      </div>
    </div>
    <div class="toast" role="alert" aria-live="assertive" aria-atomic="true">
  <div class="toast-header">
    <img src="..." class="rounded mr-2" alt="...">
    <strong class="mr-auto">Bootstrap</strong>
    <small>11 mins ago</small>
    <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
  <div class="toast-body">
    Hello, world! This is a toast message.
  </div>
</div>
		<script type="text/javascript" src="bootstrap.css">
		</script>
  </body>

</html>