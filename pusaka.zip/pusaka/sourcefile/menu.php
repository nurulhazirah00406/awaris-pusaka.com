<ul>
    <li><a href="halamanutama.php">Halaman Utama</a></li>
    <li><a href="borang_pemohon.php">Pendaftaran Baru</a></li>
    <li><a href="statuspusaka.php">Senarai Pusaka</a></li>
</ul>
