<!-- ===============================================
	**** A COMPLETE VALIDATE FORM WITH PHP ****
================================================ -->

<!-- ==============  PHP begin  =================-->
<?php
					$nama = "";
					$nokp = "";
					$nokplama = "";
					$jantina = "";
					$tarikhmeningal = "";
					$tempatkematian = "";
					$tarafkahwin = "";
					$sebabkematian = "";
					$warganegara= "";
					$agama = "";
                    $bangsa = "";
                    $muflis = "";
					
					$enama = "";
					$enokp = "";
					$enokplama = "";
					$ejantina = "";
					$etarikhmeningal = "";
					$etempatkematian = "";
					$etarafkahwin = "";
					$esebabkematian = "";
					$ewarganegara= "";
					$eagama = "";
                    $ebangsa = "";
                    $emuflis = "";					

					if(isset($_POST['submit']))
					{
					$nama = $_POST['nama'];
					$nokp = $_POST['nokp'] ;
					$nokplama = $_POST['nokplama'];
					$tarikhmeningal = $_POST['tarikhmeningal'];
					$tempatkematian = $_POST['tempatkematian'];
						
					if(isset($_POST['jantina']))
					$jantina = $_POST['jantina'];
						if(isset($_POST['tarafkhawin']))
							$tarafkahwin = $_POST['tarafkahwin'];
						if(isset($_POST['sebabkematian']))
							$sebabkematian = $_POST['sebabkematian'];
						if(isset($_POST['warganegara']))
							$warganegara = $_POST['warganegara'];
						if(isset($_POST['agama']))
							$agama = $_POST['agama'];
						if(isset($_POST['bangsa']))
							$bangsa = $_POST['bangsa'];
						if(isset($_POST['muflis']))
							$muflis = $_POST['muflis'];
						}
						
						$er = 0;
						
						if($nama == "")
						{
							$er++;
							$enama = "*Required"; 
						}
						else{
							$nama = test_input($nama);
							if(!preg_match("/^[a-zA-Z ]*$/",$nama)){
							$er++;
							$enama = "*Only letters and white space allowed";
						}
						}

						if($nokp == "")
						{
							$er++;
							$enokp = "*Required";
						}
						else{
							$nokp = test_input($nokp);
							if(!preg_match("/^[+0-9]*$/",$nokp)){
							$er++;
							$enokp = "*Only numbers are allowed";
							}
							
						}
						
						if($nokplama == "")
						{
							$er++;
							$enokplama = "*Required";
						}
						else{
							$nokplama = test_input($nokplama);
							if(!preg_match("/^[+0-9]*$/",$nokplama)){
							$er++;
							$enokplama = "*Only numbers are allowed";
							}
							
						}
						
						if($er == 0)
						{
                            /* $cn = mysqli_connect("localhost", "root", "", "db_admission");*/
							
							$sql = "INSERT INTO secregistration (nama, nokp, nokplama, jantina, tarikhmeningal, tempatkematian, tarafkahwin, sebabkematian, warganegara, agama, bangsa, muflis) VALUES (
							'".mysqli_real_escape_string($cn, strip_tags($nama))."',
							'".mysqli_real_escape_string($cn, strip_tags($nokp))."', 
							'".mysqli_real_escape_string($cn, strip_tags($nokplama))."', 
							'".mysqli_real_escape_string($cn, strip_tags($jantina))."', 
							'".mysqli_real_escape_string($cn, strip_tags($tarikhmeningal))."', 
							'".mysqli_real_escape_string($cn, strip_tags($tempatkematian))."', 
							".mysqli_real_escape_string($cn, strip_tags($tarafkahwin)).", 
							'".mysqli_real_escape_string($cn, strip_tags($sebabkematian))."', 
							'".mysqli_real_escape_string($cn, strip_tags($warganegara))."', 
							".mysqli_real_escape_string($cn, strip_tags($agama)).",
							'".mysqli_real_escape_string($cn, strip_tags($bangsa)).",
							'".mysqli_real_escape_string($cn, strip_tags($muflis))."
							)";
							
							if(mysqli_query($cn , $sql))
							{
								print '<span class = "successMessage">Data saved into system.</span>';
								$nama = "";
								$nokp = "";
								$nokplama = "";
								$jantina = "";
								$tarikhmeninggal = "";
								$tempatkematian = "";
								$tarafkahwin = "";
								$sebabkematian = "";
								$warganegara = "";
								$agama = "";
								$bangsa = "";
								$muflis= "";
									
							}
							else
							{
								print '<span class= "errorMessage">'.mysqli_error($cn).'</span>';
							}
						}
						else
						{
							print '<span class = "errorMessage">Please fill all the required fields correctly.</span>';
						}
					
					function test_input($data) {
					  $data = trim($data);
					  $data = stripslashes($data);
					  $data = htmlspecialchars($data);
					  return $data;
					}
					
//================================ PHP End =============================	
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
	<title>Borang Permohanan - AWARIS</title>
	
<head> 
<link rel="stylesheet" type="text/css" href="../css/styleborang.css">
	<link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/font-awesome.min.css">
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
	
	<title>Borang Permohanan - AWARIS</title>
	
	<?php include('../sourcefile/navbar.php') ?>
	
	<style>
	
	</style>
	
</head>

<body>
<div class="form-area">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="section-title">
					<h3>Borang Permohonan Perkhidmatan Pentadbiran Harta Pusaka</h3>
				</div>

				<div class="row">
					<div class="col-md-12">
						<h4>2.0 Keterangan Mengenai Simati</h4>
						<form action="" method="post">
							<div class="row">
								<div class="col-md-6">
									<div class="left-side-form">
										<h5><label for="nama">Nama Penuh/ (Seperti Dalam Kad Pengenalan)</label>
										<span class="error"><?php print $enama; ?></span></h5>
										<p><input type="text" name="nama" value="<?php print $nama; ?>"></p>

										<h5><label for="nokp">No. KP Baru</label><span class="error">
												<?php print $enokp; ?></span></h5>
										<p><input type="text" name="nokp" value="<?php print $nokp; ?>"></p>
										
										<h5><label for="nokplama">No. KP Lama/Polis/Tentera/No. Pasport</label><span class="error">
												<?php print $enokplama; ?></span></h5>
										<p><input type="text" name="nokplama" value="<?php print $nokplama; ?>"></p>
										
										<h5><label for="jantina">Jantina</label></h5>
										<input type="radio" name="jantina" value="Lelaki"><span>Lelaki</span>
										<input type="radio" name="jantina" value="Perempuan"><span>Perempuan</span>
										<span class="error">
											<?php print $ejantina; ?></span>

										<h5><label for="tarikhmeningal">Tarikh Meninggal Dunia </label><span class="error">
												<?php print $etarikhmeningal; ?></span></h5>
										<p><textarea name="tarikhmeningal" ><?php print $tarikhmeningal; ?></textarea></p>

										<h5><label for="tempatkematian">Tempat Kematian</label><span class="error">
												<?php print $etempatkematian; ?></span></h5>
										<p><textarea name="tempatkematian"><?php print $tempatkematian; ?></textarea></p>
										
						         </div>
								</div>
								<div class="col-md-6">
									<div class="right-side-form">
										
                                        <h5><label for="tarafkahwin">Taraf Perkhawinan</label></h5>
										<input type="radio" name="tarafkahwin" value="Berkahwin"><span>Berkahwin</span>
										<input type="radio" name="tarafkahwin" value="Bujang"><span>Bujang</span>
										<input type="radio" name="tarafkahwin" value="Bercerai"><span>Bercerai</span>
										<span class="error">
											<?php print $etarafkahwin; ?></span>
										
										<h5><label for="sebabkematian">Sebab Kematian</label></h5>
										<input type="radio" name="sebabkematian" value="Biasa"><span>Biasa</span>
										<input type="radio" name="sebabkematian" value="Kemalangan"><span>Kemalangan</span>
										<span class="error">
											<?php print $esebabkematian; ?></span>
										
                                        <h5><label for="warganegara">Warganegara</label></h5>
										<input type="radio" name="warganegara" value="Malaysia"><span>Malaysia</span>
										<input type="radio" name="warganegara" value="Lain-lain"><span>Lain-lain</span>
										<span class="error">
											<?php print $ewarganegara; ?></span>
										
										<h5><label for="agama">Agama</label></h5>
										<input type="radio" name="agama" value="Islam"><span>Islam</span>
										<input type="radio" name="agama" value="Buddha"><span>Buddha</span>
										<input type="radio" name="agama" value="Kristian"><span>Kristian</span>
										<input type="radio" name="agama" value="Hindu"><span>Hindu</span>
										<input type="radio" name="agama" value="Lain-lain"><span>Lain-lain</span>
										<span class="error">
											<?php print $eagama; ?></span>
										
										<h5><label for="bangsa">Bangsa</label></h5>
										<input type="radio" name="bangsa" value="Melayu"><span>Melayu</span>
										<input type="radio" name="bangsa" value="Cina"><span>Cina</span>
										<input type="radio" name="bangsa" value="India"><span>India</span>
										<span class="error">
											<?php print $ebangsa; ?></span>
										
										<h5><label for="muflis">Muflis</label></h5>
										<input type="radio" name="muflis" value="Ya"><span>Ya</span>
										<input type="radio" name="muflis" value="Tidak"><span>Tidak</span>
										<span class="error">
											<?php print $emuflis; ?></span>
										<p><input type="submit" name="submit" value="Submit"></p>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
	
	
	<?php include('../sourcefile/footer.php') ?>
	
	<script src="../js/popper-1.12.9.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/owl.carousel.min.js"></script>
    <script src="../js/main.js"></script>
	<script src="jquery-3.2.1.slim.min.js"></script>
	</body>
