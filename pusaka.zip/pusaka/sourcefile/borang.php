<!-- ===============================================
	**** A COMPLETE VALIDATE FORM WITH PHP ****
================================================ -->

<!-- ==============  PHP begin  =================-->
<?php
					$namapenuh = "";
					$nokp = "";
					$nokplama = "";
					$umur = "";
					$tarikhlahir = "";
					$alamatsurat = "";
					$alamattetap = "";
					$notelrumah = "";
					$notelbimbit= "";
					$notelpejabat = "";
                    $hubungansaudara = "";
                    $emel = "";
					
					$enamapenuh = "";
					$enokp = "";
					$enokplama = "";
					$eumur = "";
					$etarikhlahir = "";
					$ealamatsurat = "";
					$ealamattetap = "";
					$enotelrumah = "";
					$enotelpejabat = "";
                    $enotelbimbit = "";
					$ehubungansaudara = "";
                    $eemel = "";					

					if(isset($_POST['submit']))
					{
					$sname = $_POST['namapenuh'];
					$gname = $_POST['nokp'] ;
					$contact = $_POST['nokplama'];
					$email = $_POST['umur'];
					$address = $_POST['tarikhlahir'];
					$class = $_POST['alamatsurat'];
					$shift = $_POST['alamattetap'];
					$shift = $_POST['notelrumah'];	
					$shift = $_POST['notelbimbit'];	
					$shift = $_POST['notelpejabat'];
						
					if(isset($_POST['hubungansaudara']))
					$gender = $_POST['hubungansaudara'];
						
						$er = 0;
						
						if($namapenuh == "")
						{
							$er++;
							$enamapenuh = "*Required";
						}
						else{
							$namapenuh = test_input($namapenuh);
							if(!preg_match("/^[a-zA-Z ]*$/",$namapenuh)){
							$er++;
							$enamapenuh = "*Only letters and white space allowed";
						}
						}

						if($nokp == "")
						{
							$er++;
							$enokp = "*Required";
						}
						else{
							$nokp = test_input($nokp);
							if(!preg_match("/^[+0-9]*$/",$nokp)){
							$er++;
							$enokp = "*Only numbers are allowed";
							}
							
						}
						
						if($nokplama == "")
						{
							$er++;
							$enokplama = "*Required";
						}
						else{
							$nokplama = test_input($nokplama);
							if(!preg_match("/^[+0-9]*$/",$nokplama)){
							$er++;
							$enokplama = "*Only numbers are allowed";
							}
							
						}

						if($emel == "")
						{
							$er++;
							$eemel = "*Required";
						}
						else
						{
							$emel = test_input($emel);
							if(!filter_var($emel, FILTER_VALIDATE_EMAIL))
							{
								$er++;
								$eemell = "*Email format is invalid";
							}
							
						}

						if($alamatsurat == "")
						{
							$er++;
							$ealamatsurat = "*Required";
						}
						
						if($alamattetap == "")
						{
							$er++;
							$ealamattetap = "*Required";
						}
						
						 if (empty($hubungansaudara)) {
						 	$er++;
						    $ehubungansaudara = "*Gender is required";
						  } else {
						    $hubungansaudara = test_input($hubungansaudara);
						  }
						
						if($er == 0)
						{
                            /* $cn = mysqli_connect("localhost", "root", "", "db_admission");*/
							
							$sql = "INSERT INTO registration (namapenuh, nokp, nokplama, umur, tarikhlahir, alamatsurat, alamattetap, notelrumah, notelbimbit, notelpejabat, hubungansaudara, emel) VALUES (
							'".mysqli_real_escape_string($cn, strip_tags($namapenuh))."',
							'".mysqli_real_escape_string($cn, strip_tags($nokp))."', 
							'".mysqli_real_escape_string($cn, strip_tags($nokplama))."', 
							'".mysqli_real_escape_string($cn, strip_tags($umur))."', 
							'".mysqli_real_escape_string($cn, strip_tags($tarikhlahir))."', 
							'".mysqli_real_escape_string($cn, strip_tags($alamatsurat))."', 
							".mysqli_real_escape_string($cn, strip_tags($alamattetap)).", 
							'".mysqli_real_escape_string($cn, strip_tags($notelrumah))."', 
							'".mysqli_real_escape_string($cn, strip_tags($notelbimbit))."', 
							".mysqli_real_escape_string($cn, strip_tags($notelpejabat)).",
							'".mysqli_real_escape_string($cn, strip_tags($hubungansaudara)).",
							'".mysqli_real_escape_string($cn, strip_tags($emel))."
							)";
							
							if(mysqli_query($cn , $sql))
							{
								print '<span class = "successMessage">Data saved into system.</span>';
								$namapenuh = "";
								$nokp = "";
								$nokplama = "";
								$umur = "";
								$tarikhlahir = "";
								$alamatsurat = "";
								$alamattetap = "";
								$notelrumah = "";
								$notelbimbit = "";
								$notelpejabat = "";
								$hubungansaudara = "";
								$emel= "";
									
							}
							else
							{
								print '<span class= "errorMessage">'.mysqli_error($cn).'</span>';
							}
						}
						else
						{
							print '<span class = "errorMessage">Please fill all the required fields correctly.</span>';
						}
					}
					
					function test_input($data) {
					  $data = trim($data);
					  $data = stripslashes($data);
					  $data = htmlspecialchars($data);
					  return $data;
					}
					
//================================ PHP End =============================	
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
	<title>Borang Permohanan - AWARIS</title>
	
<head> 
<link rel="stylesheet" type="text/css" href="../css/styleborang.css">
	<link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/font-awesome.min.css">
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
	
	<title>Borang Permohanan - AWARIS</title>
	
	<?php include('../sourcefile/navbar.php') ?>
	
	<style>
a {
  text-decoration: none;
  display: inline-block;
  padding: 8px 16px;
}

a:hover {
  background-color: #ddd;
  color: black;
}

.previous {
  background-color: #f1f1f1;
  color: black;
}

.next {
  background-color:#1973D1;
  color: white;
}

.round {
  border-radius: 50%;
}
	</style>
	
</head>

<body>
<div class="form-area">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="section-title">
					<h3>Borang Permohonan Perkhidmatan Pentadbiran Harta Pusaka</h3>
				</div>

				<div class="row">
					<div class="col-md-12">
						<h4>1.0 Keterangan Pemohon</h4>
						<form action="" method="post">
							<div class="row">
								<div class="col-md-6">
									<div class="left-side-form">
										<h5><label for="namapenuh">Nama Penuh/ (Seperti Dalam Kad Pengenalan)</label>
										<span class="error"></span></h5>
										<p><input type="text" name="namapenuh" value=""></p>
                                        
										<h5><label for="nokp">No. KP. Baru</label><span class="error">
												</span></h5>
										<p><input type="text" name="nokp" value=""></p>
										
										<h5><label for="nokplama">No. KP Lama/Polis/Tentera/No. Pasport</label><span class="error">
												</span></h5>
										<p><input type="text" name="nokplama" value=""></p>

										<h5><label for="alamatsurat">Alamat Surat Menyurat </label><span class="error">
												</span></h5>
										<p><textarea name="alamatsurat" ></textarea></p>

										<h5><label for="alamattetap">Alamat Tetap</label><span class="error">
												</span></h5>
										<p><textarea name="alamattetap"></textarea></p>

										<h5><label for="notelrumah">No. Tel Rumah</label><span class="error">
												</span></h5>
										<p><input type="text" name="notelrumah" value=""></p>
										
										<h5><label for="notelbimbit">No. Tel Bimbit</label><span class="error">
												</span></h5>
										<p><input type="text" name="notelbimbit" value=""></p>
										
										<h5><label for="notelpejabat">No. Tel Pejabat</label><span class="error">
												</span></h5>
										<p><input type="text" name="notelpejabat" value=""></p>
										
									</div>
								</div>
								<div class="col-md-6">
									<div class="right-side-form">

										<h5><label for="hubungansaudara">Perhubungan Persaudaraan Dengan Simati</label></h5>
										<input type="radio" name="hubungansaudara" value="Suami"><span>Suami</span>
										<input type="radio" name="hubungansaudara" value="Isteri"><span>Isteri</span>
										<input type="radio" name="hubungansaudara" value="Bapa"><span>Bapa</span>
										<input type="radio" name="hubungansaudara" value="Ibu"><span>Ibu</span>
										<input type="radio" name="hubungansaudara" value="Anak"><span>Anak</span>
										<input type="radio" name="hubungansaudara" value="Lain-lain"><span>Lain-lain</span>
										<span class="error">
											</span>


										
										<p><input type="submit" name="submit" value="Submit"></p>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
				<div class="col-md-6">
		<div class="right-side-form">
<a href="#" class="next">Next &raquo;</a>	
					</div>
	</div>
	
	<?php include('../sourcefile/footer.php') ?>
	
	<script src="../js/popper-1.12.9.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/owl.carousel.min.js"></script>
    <script src="../js/main.js"></script>
	<script src="jquery-3.2.1.slim.min.js"></script>
	</body>
