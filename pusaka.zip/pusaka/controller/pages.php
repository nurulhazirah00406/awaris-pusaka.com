<?php 
	include "../Connection/connection.php";
	// session_start();
	
	function base_url(){
		return $base_url = "http://" . $_SERVER['SERVER_NAME'];
	}

	function redirect($url) {
	    // header("Location: ".$url);
	    echo "<script> window.location.href = `$url`; </script>;";
	    die();
	}
	function pages($pages = ''){
		if (isset($_SESSION['page'])) {
			// $page = $_SESSION['page'];
		}
		switch ($pages) {
		    case ($pages == 'index'):
		        index();
		    break;

		    case ($pages == 'permohonan'):
		    	$progressbar_id = progressbar_id('permohonan');
		        borang();
		    break;
		    case ($pages == 'senarai_pusaka'):
		        senarai_pusaka();
		    break;
		    case ($pages == 'senarai_pemohon'):
		        senarai_pemohon();
		    break;
		    case ($pages == 'borang_simati'):
		    	$progressbar_id = progressbar_id('borang_simati');
		        borang_simati();
		    break;
		    case ($pages == 'borang_wasiat_wasi'):
		    	$progressbar_id = progressbar_id('borang_wasiat_wasi');
		        borang_wasiat_wasi();
		    break;
		    case ($pages == 'borang_harta_simati'):
		    	$progressbar_id = progressbar_id('borang_harta_simati');
		        borang_harta_simati();
		    break;
		    case ($pages == 'borang_hutang_penghutang'):
		    	$progressbar_id = progressbar_id('borang_hutang_penghutang');
		        borang_hutang_penghutang();
		    break;
		    case ($pages == 'borang_benefisiari'):
		    	$progressbar_id = progressbar_id('borang_benefisiari');
		        borang_benefisiari();
		    break;
		    case ($pages == 'borang_waris_waris'):
		    	$progressbar_id = progressbar_id('borang_waris_waris');
		        borang_waris_waris();
		    break;
		    case ($pages == 'borang_penjaga'):
		    	$progressbar_id = progressbar_id('borang_penjaga');
		        borang_penjaga();
		    break;
		    case ($pages == 'borang_akuan'):
		    	$progressbar_id = progressbar_id('borang_akuan');
		        borang_akuan();
		    break;
		    case ($pages == 'borang_view'):
		    	$progressbar_id = progressbar_id('borang_view');
		        borang_view();
		    break;
		    case ($pages == 'sejarah'):
		    	$progressbar_id = progressbar_id('sejarah');
		        sejarah();
		    break;
		    case ($pages == 'update_pemohon'):
		    	$progressbar_id = progressbar_id('update_pemohon');
		        update_pemohon();
		    break;
		    case ($pages == 'update_benefisiari'):
		    	$progressbar_id = progressbar_id('update_benefisiari');
		        update_benefisiari();
		    break;
		    case ($pages == 'update_simati'):
		    	$progressbar_id = progressbar_id('update_simati');
		        update_simati();
		    break;
		    case ($pages == 'update_wasiat_wasi'):
		    	$progressbar_id = progressbar_id('update_wasiat_wasi');
		        update_wasiat_wasi();
		    break;
		    case ($pages == 'update_harta_simati'):
		    	$progressbar_id = progressbar_id('update_harta_simati');
		        update_harta_simati();
		    break;
		    case ($pages == 'update_hutang_penghutang'):
		    	$progressbar_id = progressbar_id('update_hutang_penghutang');
		        update_hutang_penghutang();
		    break;
		    case ($pages == 'update_penjaga'):
		    	$progressbar_id = progressbar_id('update_penjaga');
		        update_penjaga();
		    break;
		    case ($pages == 'borang_view'):
		    	$progressbar_id = progressbar_id('borang_view');
		        borang_view();
		    break;
		    // case ($pages == 'borang_view'):
		    // 	$progressbar_id = progressbar_id('borang_view');
		    //     borang_view();
		    // break;
		    // case ($pages == 'borang_view'):
		    // 	$progressbar_id = progressbar_id('borang_view');
		    //     borang_view();
		    // break;
		    default:
        		index();
        	break;
		}
	}

	function index(){
		if (isset($_SESSION["page"])) {
			unset($_SESSION["page"]);
		}
		$conn = $GLOBALS["conn"];
		$sql = "SELECT m_status, 
		count(m_status) AS count_status, 
		(select count(m_status) AS counts FROM maklumat) AS TotalRows, 
		ROUND(((count(m_status) / (select count(m_status) AS counts FROM maklumat)) * 100), 2) AS percentage 
		FROM maklumat GROUP BY m_status"; // SQL with parameters
		$stmt = $conn->prepare($sql);
		$stmt->execute();
		$result = $stmt->get_result();
		include  "../view/page/halamanutama.php";
	}

	function borang(){
		if (isset($_SESSION["page"])) {
			unset($_SESSION["page"]);
		}
		if (isset($_SESSION['username'])) {
			include  "../view/page/borang_pemohon.php";
		}else{
			$base_url = base_url();
			$url = $base_url."/epusaka/view/login.php";
			$_SESSION['page'] = "permohonan";
			redirect($url);
		}
	}

	function borang_wasiat_wasi(){
		if (isset($_SESSION["page"])) {
			unset($_SESSION["page"]);
		}
		if (isset($_SESSION['username'])) {
			include  "../view/page/borang_wasiat_wasi.php";
		}else{
			$base_url = base_url();
			$url = $base_url."/epusaka/view/login.php";
			$_SESSION['page'] = "permohonan";
			redirect($url);
		}
	}

	function borang_simati(){
		if (isset($_SESSION["page"])) {
			unset($_SESSION["page"]);
		}
		if (isset($_SESSION['username'])) {
			include  "../view/page/borang_simati.php";
		}else{
			$base_url = base_url();
			$url = $base_url."/epusaka/view/login.php";
			$_SESSION['page'] = "permohonan";
			redirect($url);
		}
	}

	function borang_harta_simati(){
			include  "../view/page/borang_harta_simati.php";
		// if (isset($_SESSION["page"])) {
		// 	unset($_SESSION["page"]);
		// }
		// if (isset($_SESSION['username'])) {
		// 	include  "../view/page/borang_harta_simati.php";
		// }else{
		// 	$base_url = base_url();
		// 	$url = $base_url."/epusaka/view/login.php";
		// 	$_SESSION['page'] = "permohonan";
		// 	redirect($url);
		// }
	}

	function borang_hutang_penghutang(){
			include  "../view/page/borang_hutang_penghutang.php";
		// if (isset($_SESSION["page"])) {
		// 	unset($_SESSION["page"]);
		// }
		// if (isset($_SESSION['username'])) {
		// 	include  "../view/page/borang_harta_simati.php";
		// }else{
		// 	$base_url = base_url();
		// 	$url = $base_url."/epusaka/view/login.php";
		// 	$_SESSION['page'] = "permohonan";
		// 	redirect($url);
		// }
	}

	function borang_benefisiari(){
			include  "../view/page/borang_benefisiari.php";
		// if (isset($_SESSION["page"])) {
		// 	unset($_SESSION["page"]);
		// }
		// if (isset($_SESSION['username'])) {
		// 	include  "../view/page/borang_harta_simati.php";
		// }else{
		// 	$base_url = base_url();
		// 	$url = $base_url."/epusaka/view/login.php";
		// 	$_SESSION['page'] = "permohonan";
		// 	redirect($url);
		// }
	}

	function borang_waris_waris(){
			include  "../view/page/borang_waris_waris.php";
		// if (isset($_SESSION["page"])) {
		// 	unset($_SESSION["page"]);
		// }
		// if (isset($_SESSION['username'])) {
		// 	include  "../view/page/borang_harta_simati.php";
		// }else{
		// 	$base_url = base_url();
		// 	$url = $base_url."/epusaka/view/login.php";
		// 	$_SESSION['page'] = "permohonan";
		// 	redirect($url);
		// }
	}

	function update_pemohon(){
			
		if (isset($_SESSION["page"])) {
			unset($_SESSION["page"]);
		}
		if (isset($_SESSION['username'])) {
			$sm_id = $_GET['simati'];
			$conn = $GLOBALS["conn"]; //call connection that have set to global...
			$sql = "SELECT * FROM r_pemohon LEFT OUTER JOIN r_simati ON r_simati.p_id = r_pemohon.p_id WHERE sm_id = $sm_id"; // SQL with parameters
			$stmt = $conn->prepare($sql);
			$stmt->execute();
			$result = $stmt->get_result();
			include  "../view/page/update_pemohon.php";
		}else{
			$base_url = base_url();
			$url = $base_url."/epusaka/view/login.php";
			$_SESSION['page'] = "senarai_pusaka";
			redirect($url);
		}
	}

	function update_simati(){
			
		if (isset($_SESSION["page"])) {
			unset($_SESSION["page"]);
		}
		if (isset($_SESSION['username'])) {
			$sm_id = $_GET['simati'];
			$conn = $GLOBALS["conn"]; //call connection that have set to global...
			$sql = "SELECT * FROM r_pemohon LEFT OUTER JOIN r_simati ON r_simati.p_id = r_pemohon.p_id WHERE sm_id = $sm_id"; // SQL with parameters
			$stmt = $conn->prepare($sql);
			$stmt->execute();
			$result = $stmt->get_result();
			include  "../view/page/update_simati.php";
		}else{
			$base_url = base_url();
			$url = $base_url."/epusaka/view/login.php";
			$_SESSION['page'] = "senarai_pusaka";
			redirect($url);
		}
	}

	function update_wasiat_wasi(){
			
		if (isset($_SESSION["page"])) {
			unset($_SESSION["page"]);
		}
		if (isset($_SESSION['username'])) {
			$sm_id = $_GET['simati'];
			$conn = $GLOBALS["conn"]; //call connection that have set to global...
			$sql = "SELECT * FROM r_simati rs
			LEFT OUTER JOIN r_infowasiat iw ON iw.sm_id = rs.sm_id
			LEFT OUTER JOIN r_penjagawaris pw ON pw.sm_id = rs.sm_id
			LEFT OUTER JOIN r_pemohon p ON p.p_id = rs.p_id
			WHERE rs.sm_id = '$sm_id'"; // SQL with parameters
			$stmt = $conn->prepare($sql);
			$stmt->execute();
			$result = $stmt->get_result();
			include  "../view/page/update_wasiat_wasi.php";
		}else{
			$base_url = base_url();
			$url = $base_url."/epusaka/view/login.php";
			$_SESSION['page'] = "senarai_pusaka";
			redirect($url);
		}
	}

	function update_harta_simati(){
			
		if (isset($_SESSION["page"])) {
			unset($_SESSION["page"]);
		}
		if (isset($_SESSION['username'])) {
			$sm_id = $_GET['simati'];
			$conn = $GLOBALS["conn"]; //call connection that have set to global...
			$sql1 = "SELECT * FROM r_simati rs 
			LEFT OUTER JOIN r_hrtxalih hx ON hx.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_hartaalih ha ON ha.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_hutangsimati hs ON hs.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_infowasiat iw ON iw.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_penghutangsimati ps ON ps.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_penjagawaris pw ON pw.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_waris_wasiatsimati ww ON ww.sm_id = rs.sm_id
			-- // LEFT OUTER JOIN r_pemohon p ON p.p_id = rs.p_id
			WHERE rs.sm_id = '$sm_id'"; // SQL with parameters
			$stmt1 = $conn->prepare($sql1);
			$stmt1->execute();
			$result1 = $stmt1->get_result();

			$sql2 = "SELECT * FROM r_simati rs 
			-- LEFT OUTER JOIN r_hrtxalih hx ON hx.sm_id = rs.sm_id
			LEFT OUTER JOIN r_hartaalih ha ON ha.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_hutangsimati hs ON hs.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_infowasiat iw ON iw.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_penghutangsimati ps ON ps.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_penjagawaris pw ON pw.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_waris_wasiatsimati ww ON ww.sm_id = rs.sm_id
			-- // LEFT OUTER JOIN r_pemohon p ON p.p_id = rs.p_id
			WHERE rs.sm_id = '$sm_id'"; // SQL with parameters
			$stmt2 = $conn->prepare($sql2);
			$stmt2->execute();
			$result2 = $stmt2->get_result();
			include  "../view/page/update_harta_simati.php";
		}else{
			$base_url = base_url();
			$url = $base_url."/epusaka/view/login.php";
			$_SESSION['page'] = "senarai_pusaka";
			redirect($url);
		}
	}

	function update_hutang_penghutang(){
			
		if (isset($_SESSION["page"])) {
			unset($_SESSION["page"]);
		}
		if (isset($_SESSION['username'])) {
			$sm_id = $_GET['simati'];
			$conn = $GLOBALS["conn"]; //call connection that have set to global...
			$sql1 = "SELECT * FROM r_simati rs 
			-- LEFT OUTER JOIN r_hrtxalih hx ON hx.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_hartaalih ha ON ha.sm_id = rs.sm_id
			LEFT OUTER JOIN r_hutangsimati hs ON hs.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_infowasiat iw ON iw.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_penghutangsimati ps ON ps.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_penjagawaris pw ON pw.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_waris_wasiatsimati ww ON ww.sm_id = rs.sm_id
			-- // LEFT OUTER JOIN r_pemohon p ON p.p_id = rs.p_id
			WHERE rs.sm_id = '$sm_id'"; // SQL with parameters
			$stmt1 = $conn->prepare($sql1);
			$stmt1->execute();
			$result_hutangsimati = $stmt1->get_result();

			$sql2 = "SELECT * FROM r_simati rs 
			-- LEFT OUTER JOIN r_hrtxalih hx ON hx.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_hartaalih ha ON ha.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_hutangsimati hs ON hs.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_infowasiat iw ON iw.sm_id = rs.sm_id
			LEFT OUTER JOIN r_penghutangsimati ps ON ps.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_penjagawaris pw ON pw.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_waris_wasiatsimati ww ON ww.sm_id = rs.sm_id
			-- // LEFT OUTER JOIN r_pemohon p ON p.p_id = rs.p_id
			WHERE rs.sm_id = '$sm_id'"; // SQL with parameters
			$stmt2 = $conn->prepare($sql2);
			$stmt2->execute();
			$result_r_penghutangsimati = $stmt2->get_result();
			include  "../view/page/update_hutang_penghutang.php";
		}else{
			$base_url = base_url();
			$url = $base_url."/epusaka/view/login.php";
			$_SESSION['page'] = "senarai_pusaka";
			redirect($url);
		}
	}

	function update_benefisiari(){
			
		if (isset($_SESSION["page"])) {
			unset($_SESSION["page"]);
		}
		if (isset($_SESSION['username'])) {
			$sm_id = $_GET['simati'];
			$conn = $GLOBALS["conn"]; //call connection that have set to global...
			$sql1 = "SELECT * FROM r_simati rs 
			-- LEFT OUTER JOIN r_hrtxalih hx ON hx.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_hartaalih ha ON ha.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_hutangsimati hs ON hs.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_infowasiat iw ON iw.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_penghutangsimati ps ON ps.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_penjagawaris pw ON pw.sm_id = rs.sm_id
			LEFT OUTER JOIN r_waris_wasiatsimati ww ON ww.sm_id = rs.sm_id
			-- // LEFT OUTER JOIN r_pemohon p ON p.p_id = rs.p_id
			WHERE rs.sm_id = '$sm_id'"; // SQL with parameters
			$stmt1 = $conn->prepare($sql1);
			$stmt1->execute();
			$result_r_waris_wasiatsimati = $stmt1->get_result();

			$sql2 = "SELECT * FROM r_simati rs 
			-- LEFT OUTER JOIN r_hrtxalih hx ON hx.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_hartaalih ha ON ha.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_hutangsimati hs ON hs.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_infowasiat iw ON iw.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_penghutangsimati ps ON ps.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_penjagawaris pw ON pw.sm_id = rs.sm_id
			LEFT OUTER JOIN r_waris_wasiatsimati ww ON ww.sm_id = rs.sm_id
			-- // LEFT OUTER JOIN r_pemohon p ON p.p_id = rs.p_id
			WHERE rs.sm_id = '$sm_id'"; // SQL with parameters
			$stmt2 = $conn->prepare($sql2);
			$stmt2->execute();
			$result_r_waris_wasiatsimati1 = $stmt2->get_result();
			include  "../view/page/update_benefisiari.php";
		}else{
			$base_url = base_url();
			$url = $base_url."/epusaka/view/login.php";
			$_SESSION['page'] = "senarai_pusaka";
			redirect($url);
		}
	}

	function update_penjaga(){
			
		if (isset($_SESSION["page"])) {
			unset($_SESSION["page"]);
		}
		if (isset($_SESSION['username'])) {
			$sm_id = $_GET['simati'];
			$conn = $GLOBALS["conn"]; //call connection that have set to global...
			$sql1 = "SELECT * FROM r_simati rs 
			-- LEFT OUTER JOIN r_hrtxalih hx ON hx.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_hartaalih ha ON ha.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_hutangsimati hs ON hs.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_infowasiat iw ON iw.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_penghutangsimati ps ON ps.sm_id = rs.sm_id
			LEFT OUTER JOIN r_penjagawaris pw ON pw.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_waris_wasiatsimati ww ON ww.sm_id = rs.sm_id
			-- // LEFT OUTER JOIN r_pemohon p ON p.p_id = rs.p_id
			WHERE rs.sm_id = '$sm_id'"; // SQL with parameters
			$stmt1 = $conn->prepare($sql1);
			$stmt1->execute();
			$result = $stmt1->get_result();
			include  "../view/page/update_penjaga.php";
		}else{
			$base_url = base_url();
			$url = $base_url."/epusaka/view/login.php";
			$_SESSION['page'] = "senarai_pusaka";
			redirect($url);
		}
	}

	function borang_penjaga(){
			include  "../view/page/borang_penjaga.php";
		// if (isset($_SESSION["page"])) {
		// 	unset($_SESSION["page"]);
		// }
		// if (isset($_SESSION['username'])) {
		// 	include  "../view/page/borang_harta_simati.php";
		// }else{
		// 	$base_url = base_url();
		// 	$url = $base_url."/epusaka/view/login.php";
		// 	$_SESSION['page'] = "permohonan";
		// 	redirect($url);
		// }
	}

	function borang_akuan(){
		if (isset($_SESSION["page"])) {
			unset($_SESSION["page"]);
		}
		if (isset($_SESSION['username'])) {
			$conn = $GLOBALS["conn"]; //call connection that have set to global...
			$id_simati = $_GET['simati'];
			$sql = "SELECT * FROM r_pemohon LEFT OUTER JOIN r_simati ON r_simati.p_id = r_pemohon.p_id WHERE sm_id = '$id_simati'"; // SQL with parameters
			$stmt = $conn->prepare($sql);
			$stmt->execute();
			$result = $stmt->get_result();

			include  "../view/page/borang_akuan.php";
		}else{
			$base_url = base_url();
			$url = $base_url."/epusaka/view/login.php";
			$_SESSION['page'] = "permohonan";
			redirect($url);
		}
	}

	function borang_view(){
		if (isset($_SESSION["page"])) {
			unset($_SESSION["page"]);
		}
		if (isset($_SESSION['username'])) {
			$id_simati = $_GET['simati'];
			$conn = $GLOBALS["conn"]; //call connection that have set to global...
			$sql_pemohon = "SELECT * FROM r_simati rs 
			-- LEFT OUTER JOIN r_hrtxalih hx ON hx.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_hartaalih ha ON ha.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_hutangsimati hs ON hs.sm_id = rs.sm_id
			LEFT OUTER JOIN r_infowasiat iw ON iw.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_penghutangsimati ps ON ps.sm_id = rs.sm_id
			LEFT OUTER JOIN r_penjagawaris pw ON pw.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_waris_wasiatsimati ww ON ww.sm_id = rs.sm_id
			LEFT OUTER JOIN r_pemohon p ON p.p_id = rs.p_id
			WHERE rs.sm_id = '$id_simati'"; // SQL with parameters
			$stmt_pemohon = $conn->prepare($sql_pemohon);
			$stmt_pemohon->execute();
			$result_pemohon = $stmt_pemohon->get_result();

			$sql_hartaxalih = "SELECT * FROM r_simati rs 
			LEFT OUTER JOIN r_hrtxalih hx ON hx.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_hartaalih ha ON ha.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_hutangsimati hs ON hs.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_infowasiat iw ON iw.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_penghutangsimati ps ON ps.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_penjagawaris pw ON pw.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_waris_wasiatsimati ww ON ww.sm_id = rs.sm_id
			-- // LEFT OUTER JOIN r_pemohon p ON p.p_id = rs.p_id
			WHERE rs.sm_id = '$id_simati'"; // SQL with parameters
			$stmt_hartaxalih = $conn->prepare($sql_hartaxalih);
			$stmt_hartaxalih->execute();
			$result_hartaxalih = $stmt_hartaxalih->get_result();


			$sql_hartaalih = "SELECT * FROM r_simati rs 
			-- LEFT OUTER JOIN r_hrtxalih hx ON hx.sm_id = rs.sm_id
			LEFT OUTER JOIN r_hartaalih ha ON ha.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_hutangsimati hs ON hs.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_infowasiat iw ON iw.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_penghutangsimati ps ON ps.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_penjagawaris pw ON pw.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_waris_wasiatsimati ww ON ww.sm_id = rs.sm_id
			-- // LEFT OUTER JOIN r_pemohon p ON p.p_id = rs.p_id
			WHERE rs.sm_id = '$id_simati'"; // SQL with parameters
			$stmt_hartaalih = $conn->prepare($sql_hartaalih);
			$stmt_hartaalih->execute();
			$result_hartaalih = $stmt_hartaalih->get_result();


			$sql_r_hutangsimati = "SELECT * FROM r_simati rs 
			-- LEFT OUTER JOIN r_hrtxalih hx ON hx.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_hartaalih ha ON ha.sm_id = rs.sm_id
			LEFT OUTER JOIN r_hutangsimati hs ON hs.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_infowasiat iw ON iw.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_penghutangsimati ps ON ps.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_penjagawaris pw ON pw.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_waris_wasiatsimati ww ON ww.sm_id = rs.sm_id
			-- // LEFT OUTER JOIN r_pemohon p ON p.p_id = rs.p_id
			WHERE rs.sm_id = '$id_simati'"; // SQL with parameters
			$stmt_r_hutangsimati = $conn->prepare($sql_r_hutangsimati);
			$stmt_r_hutangsimati->execute();
			$result_hutangsimati = $stmt_r_hutangsimati->get_result();


			$sql_r_penghutangsimati = "SELECT * FROM r_simati rs 
			-- LEFT OUTER JOIN r_hrtxalih hx ON hx.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_hartaalih ha ON ha.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_hutangsimati hs ON hs.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_infowasiat iw ON iw.sm_id = rs.sm_id
			LEFT OUTER JOIN r_penghutangsimati ps ON ps.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_penjagawaris pw ON pw.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_waris_wasiatsimati ww ON ww.sm_id = rs.sm_id
			-- // LEFT OUTER JOIN r_pemohon p ON p.p_id = rs.p_id
			WHERE rs.sm_id = '$id_simati'"; // SQL with parameters
			$stmt_r_penghutangsimati = $conn->prepare($sql_r_penghutangsimati);
			$stmt_r_penghutangsimati->execute();
			$result_r_penghutangsimati = $stmt_r_penghutangsimati->get_result();


			$sql_r_waris_wasiatsimati = "SELECT * FROM r_simati rs 
			-- LEFT OUTER JOIN r_hrtxalih hx ON hx.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_hartaalih ha ON ha.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_hutangsimati hs ON hs.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_infowasiat iw ON iw.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_penghutangsimati ps ON ps.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_penjagawaris pw ON pw.sm_id = rs.sm_id
			LEFT OUTER JOIN r_waris_wasiatsimati ww ON ww.sm_id = rs.sm_id
			-- // LEFT OUTER JOIN r_pemohon p ON p.p_id = rs.p_id
			WHERE rs.sm_id = '$id_simati'"; // SQL with parameters
			$stmt_r_waris_wasiatsimati = $conn->prepare($sql_r_waris_wasiatsimati);
			$stmt_r_waris_wasiatsimati->execute();
			$result_r_waris_wasiatsimati = $stmt_r_waris_wasiatsimati->get_result();


			$sql_r_waris_wasiatsimati1 = "SELECT * FROM r_simati rs 
			-- LEFT OUTER JOIN r_hrtxalih hx ON hx.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_hartaalih ha ON ha.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_hutangsimati hs ON hs.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_infowasiat iw ON iw.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_penghutangsimati ps ON ps.sm_id = rs.sm_id
			-- LEFT OUTER JOIN r_penjagawaris pw ON pw.sm_id = rs.sm_id
			LEFT OUTER JOIN r_waris_wasiatsimati ww ON ww.sm_id = rs.sm_id
			-- // LEFT OUTER JOIN r_pemohon p ON p.p_id = rs.p_id
			WHERE rs.sm_id = '$id_simati'"; // SQL with parameters
			$stmt_r_waris_wasiatsimati1 = $conn->prepare($sql_r_waris_wasiatsimati1);
			$stmt_r_waris_wasiatsimati1->execute();
			$result_r_waris_wasiatsimati1 = $stmt_r_waris_wasiatsimati1->get_result();
			include  "../view/page/borang_view.php";
		}else{
			$base_url = base_url();
			$url = $base_url."/epusaka/view/login.php";
			$_SESSION['page'] = "permohonan";
			redirect($url);
		}
	}

	function senarai_pusaka(){
		if (isset($_SESSION["page"])) {
			unset($_SESSION["page"]);
		}
		if (isset($_SESSION['username'])) {
			$conn = $GLOBALS["conn"]; //call connection that have set to global...
			$sql = "SELECT *, r_simati.sm_id AS id FROM r_simati LEFT OUTER JOIN maklumat ON r_simati.sm_id = maklumat.sm_id"; // SQL with parameters
			$stmt = $conn->prepare($sql);
			$stmt->execute();
			$result = $stmt->get_result();

			include  "../view/page/senaraipusaka.php";
		}else{
			$base_url = base_url();
			$url = $base_url."/epusaka/view/login.php";
			$_SESSION['page'] = "senarai_pusaka";
			redirect($url);
		}
	}


	function sejarah(){
		if (isset($_SESSION["page"])) {
			unset($_SESSION["page"]);
		}
		if (isset($_SESSION['username'])) {
			$conn = $GLOBALS["conn"]; //call connection that have set to global...
			$sql = "SELECT * FROM sejarah"; // SQL with parameters
			$stmt = $conn->prepare($sql);
			$stmt->execute();
			$result = $stmt->get_result();

			include  "../view/page/sejarah.php";
		}else{
			$base_url = base_url();
			$url = $base_url."/epusaka/view/login.php";
			$_SESSION['page'] = "senarai_pusaka";
			redirect($url);
		}
	}

	function senarai_pemohon(){
		if (isset($_SESSION["page"])) {
			unset($_SESSION["page"]);
		}
		if (isset($_SESSION['username'])) {
			$conn = $GLOBALS["conn"]; //call connection that have set to global...
			$sql = "SELECT *, COUNT(sm_id) AS bil_pusaka, r_pemohon.p_id AS id FROM r_pemohon LEFT OUTER JOIN r_simati ON r_simati.p_id = r_pemohon.p_id GROUP BY r_pemohon.p_id"; // SQL with parameters
			$stmt = $conn->prepare($sql);
			$stmt->execute();
			$result = $stmt->get_result(); // get the mysqli result
			// $senarai_pemohon = $result->fetch_all(MYSQLI_ASSOC); // fetch data
			// $GLOBALS["senarai_pemohon"] = $result; //set it global to fetch data from this function in page $variable
			include "../view/page/senaraipemohon.php";
		}else{
			$base_url = base_url();
			$url = $base_url."/epusaka/view/login.php";
			$_SESSION['page'] = "senarai_pemohon";
			redirect($url);
		}
	}

	function progressbar_id($id_progress){
	

	

	
?>

	<script type="text/javascript">
		$( document ).ready(function() {
			// var d = document.getElementById('<?php echo $id_progress;?>');
			// d.className += "current-item";
			// $('#'+progressid).addClass("current-item");
			$('#<?php echo $id_progress;?>').addClass("current-item");
			});
	</script>
<?php 
	}
?>