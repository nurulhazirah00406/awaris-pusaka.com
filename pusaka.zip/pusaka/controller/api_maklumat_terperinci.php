<?php
    include "../Connection/connection.php";
    if (isset($_POST['id'])) {

        $conn = $GLOBALS["conn"]; //call connection that have set to global...
        $sql = "SELECT IFNULL(maklumat.m_nofail,'') as m_nofail,IFNULL(r_simati.sm_nama,'') as sm_nama,IFNULL(r_simati.sm_nric_new,'') as sm_nric_new,IFNULL(r_simati.sm_datemati,'') as sm_datemati FROM r_pemohon LEFT JOIN r_simati ON r_pemohon.p_id=r_simati.p_id LEFT JOIN maklumat ON r_simati.sm_id=maklumat.sm_id WHERE r_pemohon.p_id='".$_POST['id']."'"; // SQL with parameters
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->get_result(); 

        $item_arr=array();
        
        while ($row = $result->fetch_assoc()) {
            
            $item=array(
                "m_nofail" => $row['m_nofail'],
                "sm_nama" => $row['sm_nama'],
                "sm_nric_new" => $row['sm_nric_new'],
                "sm_datemati" => $row['sm_datemati']
            );
            array_push($item_arr, $item);
        }

  
        
        echo json_encode($item_arr);
    }

?>