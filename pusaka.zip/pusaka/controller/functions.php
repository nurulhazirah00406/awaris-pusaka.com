<?php
	require '../Connection/connection.php';
	session_start();
	function base_url(){
		return $base_url = "http://" . $_SERVER['SERVER_NAME'];
	}

	function redirect($url) {
	    header("Location: ".$url);
	    die();
	}

	if (isset($_POST['btn_mohon'])) {
		// echo "borang permohonan";
		// var_dump($_POST);
		// $column = '';
		// foreach ($_POST as $key => $value) {
		// 	$column = $column.",".$key;
		// 	// echo $key;
		// 	// echo "<br>";
		// }
		// echo $column;
		unset($_POST['btn_mohon']);
		$_POST['p_birthdate'] = date("d/m/Y", strtotime($_POST['p_birthdate']));  
		$data = $_POST;
		$values = array();
        $columns = implode(", ",array_keys($data));
		$escaped_values = array_map(array($conn, 'real_escape_string'),array_values($data));
		$values  = implode("', '", $escaped_values);
		$sql = "INSERT INTO r_pemohon ($columns) VALUES ('$values')";
		if ($conn->query($sql) === TRUE) {
        	printf("Record inserted successfully.<br />");
        	$base_url = base_url();
        	$last_id = $conn->insert_id;
			// echo $last_id;
			$url = $base_url."/epusaka/view/borang_simati.php?pemohon=$last_id";
			// echo $url;
			redirect($url);
     	}else{
         printf("Could not insert record into table: %s<br />", $conn -> error);
      }
       $conn->close();
	}

	if (isset($_POST['btn_borangsimati'])) {
		// echo "borang permohonan";
		// var_dump($_POST);
		// $column = '';
		// foreach ($_POST as $key => $value) {
		// 	$column = $column.",".$key;
		// 	// echo $key;
		// 	// echo "<br>";
		// }
		// echo $column;
		unset($_POST['btn_borangsimati']);
		$_POST['sm_datemati'] = date("d/m/Y", strtotime($_POST['sm_datemati']));  
		$data = $_POST;
		$values = array();
        $columns = implode(", ",array_keys($data));
		$escaped_values = array_map(array($conn, 'real_escape_string'),array_values($data));
		$values  = implode("', '", $escaped_values);

		// mysqli_begin_transaction($conn, MYSQLI_TRANS_START_READ_WRITE);
		
		$sql = "INSERT INTO r_simati ($columns) VALUES ('$values')";
		echo $sql;
		if ($conn->query($sql) === TRUE) {
			$last_id_simati = $conn -> insert_id;
			$curr_datetime = date("d/m/Y H:i:s");
			$len = strlen($last_id_simati);
			$nofail = 'A';
			for ($i=0; $i < 5 - $len; $i++) { 
				$nofail = $nofail.'0';
			}

			$nofail = $nofail.$last_id_simati;
			// echo $nofail;
			$sql1 = "INSERT INTO maklumat(m_nofail, sm_id, m_status, m_keterangan) VALUES ('$nofail','$last_id_simati','Buka Fail','Permohonan Baru pada $curr_datetime')";
			// echo $sql1;
			// var_dump($conn->query($sql1));
			if ($conn->query($sql1) === TRUE) {
				$last_id1 = $conn -> insert_id;
	        	// printf("Record inserted successfully.<br />");
	        	$username = $_SESSION['username'];
	        	$sql2 = "INSERT INTO sejarah(s_nofail, s_status, s_tarikh, s_penerangan, s_pegawai) VALUES ('$nofail','Buka Fail','$curr_datetime','Permohonan Baru pada $curr_datetime','$username')";
				// echo $sql2;

	        	if ($conn->query($sql2) === TRUE) {

		        	printf("Record inserted successfully.<br />");
		        	$base_url = base_url();
					
					$url = $base_url."/epusaka/view/borang_wasiat_wasi.php?simati=$last_id1";
					// echo $url;
					mysqli_commit($conn);
					redirect($url);
				}else{
					mysqli_rollback($conn); 
	        		printf("Could not insert record into table: %s<br />", $conn -> error);
				}
			}else{
				mysqli_rollback($conn); 
        		printf("Could not insert record into table: %s<br />", $conn -> error);
			}

     	}else {
     		mysqli_rollback($conn); 
        	printf("Could not insert record into table: %s<br />", $conn -> error);
      }
      $conn->close();
	}


	if (isset($_POST['btn_borangwasi_wasiat'])) {

		unset($_POST['btn_borangwasi_wasiat']);
		$_POST['iw_birthdate'] = date("d/m/Y", strtotime($_POST['iw_birthdate']));  
		$data = $_POST;
		$values = array();
        $columns = implode(", ",array_keys($data));
		$escaped_values = array_map(array($conn, 'real_escape_string'),array_values($data));
		$values  = implode("', '", $escaped_values);
		
		$sql = "INSERT INTO r_infowasiat ($columns) VALUES ('$values')";
		$id_simati = $_POST['sm_id'];
		echo $sql;
		if ($conn->query($sql) === TRUE) {

        	printf("Record inserted successfully.<br />");
        	$base_url = base_url();
			
			$url = $base_url."/epusaka/view/borang_harta_simati.php?simati=$id_simati";
			// echo $url;
			mysqli_commit($conn);
			redirect($url);
		}else{
			mysqli_rollback($conn); 
    		printf("Could not insert record into table: %s<br />", $conn -> error);
		}
      	$conn->close();
	}


	if (isset($_POST['btn_borang_harta'])) {

		unset($_POST['btn_borang_harta']);
		// $_POST['iw_birthdate'] = date("d/m/Y", strtotime($_POST['iw_birthdate']));  
		$data = $_POST;
		// echo json_encode($data);
		$values = array();
        $columns1 = implode(", ",array_keys($data));
		// $escaped_values = array_map(array($conn, 'real_escape_string'),array_values($data));
		// $values  = implode("', '", $escaped_values);
		
		// $sql = "INSERT INTO r_infowasiat ($columns) VALUES ('$values')";
		// $id_simati = $_POST['sm_id'];
		// echo $sql;
		$columns_hx = array();
		$columns_ha = array();

		$valueshx = array();
		$valuesha = array();

		if (!function_exists('str_contains')) {
		    function str_contains(string $haystack, string $needle): bool
		    {
		        return '' === $needle || false !== strpos($haystack, $needle);
		    }
		}

		foreach ($data as $key => $value) {
			// echo $key;
			if (str_contains($key, 'hx_')) { 
			   $columns_hx[$key] = $value;
			   foreach ($value as $key1 => $value1) {
				   	if (isset($valueshx[$key1])) {
				   		$valueshx[$key1] = $valueshx[$key1].", '".$conn -> real_escape_string($value1)."'";
				   	}else{
				   		$valueshx[$key1] = "('".$conn -> real_escape_string($value1)."'";
				   	}
			   	}
			}

			if (str_contains($key, 'ha_')) { 
			    $columns_ha[$key] = $value;
			    foreach ($value as $key1 => $value1) {
				   	if (isset($valuesha[$key1])) {
				   		$valuesha[$key1] = $valuesha[$key1].", '".$conn -> real_escape_string($value1)."'";
				   	}else{
				   		$valuesha[$key1] = "('".$conn->real_escape_string($value1)."'";
				   	}
			   	}
			}
		}

		$columns_hx['sm_id'] = $_POST['sm_id'];
		$columns_ha['sm_id'] = $_POST['sm_id'];

		$columns1 = implode(", ",array_keys($columns_hx));
		$columns2 = implode(", ",array_keys($columns_ha));

		foreach ($valueshx as $key => $value) {
			$valueshx[$key] = $valueshx[$key].', '.$_POST['sm_id'].')';
		}

		foreach ($valuesha as $key => $value) {
			$valuesha[$key] = $valuesha[$key].', '.$_POST['sm_id'].')';
		}

		// $escaped_valueshx = array_map(array($conn, 'real_escape_string'),array_values($valueshx));
		$string_valueshx  = implode(", ", $valueshx);

		// $escaped_valuesha = array_map(array($conn, 'real_escape_string'),array_values($valuesha));
		$string_valuesha  = implode(", ", $valuesha);

		

		// echo "<br>";
		// echo "<br>";
		// var_dump($valueshx);
		// echo "<br>";
		// echo "<br>";
		// var_dump($valuesha);
		// echo "<br>";
		// echo "<br>";
		// var_dump($string_valueshx);
		// echo "<br>";
		// echo "<br>";
		// var_dump($string_valuesha);
		// echo "<br>";
		// echo "<br>";

		$sqlhx = "INSERT INTO r_hrtxalih ($columns1) VALUES $string_valueshx ";
		$sqlha = "INSERT INTO r_hartaalih ($columns2) VALUES $string_valuesha ";
		$id_simati = $_POST['sm_id'];
		if ($conn->query($sqlhx) === TRUE) {
        	if ($conn->query($sqlha) === TRUE) {

	        	printf("Record inserted successfully.<br />");
	        	$base_url = base_url();
				
				$url = $base_url."/epusaka/view/borang_hutang_penghutang.php?simati=$id_simati";
				// echo $url;
				mysqli_commit($conn);
				redirect($url);
			}else{
				mysqli_rollback($conn); 
        		printf("Could not insert record into table: %s<br />", $conn -> error);
			}
		}else{
			mysqli_rollback($conn); 
    		printf("Could not insert record into table: %s<br />", $conn -> error);
		}

      	$conn->close();
	}


	if (isset($_POST['btn_borang_hutang_penghutang'])) {

		unset($_POST['btn_borang_harta']);
		// $_POST['iw_birthdate'] = date("d/m/Y", strtotime($_POST['iw_birthdate']));  
		$data = $_POST;
		// echo json_encode($data);
		$values = array();
        $columns1 = implode(", ",array_keys($data));
		// $escaped_values = array_map(array($conn, 'real_escape_string'),array_values($data));
		// $values  = implode("', '", $escaped_values);
		
		// $sql = "INSERT INTO r_infowasiat ($columns) VALUES ('$values')";
		// $id_simati = $_POST['sm_id'];
		// echo $sql;
		$columns_hx = array();
		$columns_ha = array();

		$valueshx = array();
		$valuesha = array();

		if (!function_exists('str_contains')) {
		    function str_contains(string $haystack, string $needle): bool
		    {
		        return '' === $needle || false !== strpos($haystack, $needle);
		    }
		}

		foreach ($data as $key => $value) {
			// echo $key;
			if (str_contains($key, 'hs_')) { 
			   $columns_hx[$key] = $value;
			   foreach ($value as $key1 => $value1) {
				   	if (isset($valueshx[$key1])) {
				   		$valueshx[$key1] = $valueshx[$key1].", '".$conn -> real_escape_string($value1)."'";
				   	}else{
				   		$valueshx[$key1] = "('".$conn -> real_escape_string($value1)."'";
				   	}
			   	}
			}

			if (str_contains($key, 'ps_')) { 
			    $columns_ha[$key] = $value;
			    foreach ($value as $key1 => $value1) {
				   	if (isset($valuesha[$key1])) {
				   		$valuesha[$key1] = $valuesha[$key1].", '".$conn -> real_escape_string($value1)."'";
				   	}else{
				   		$valuesha[$key1] = "('".$conn->real_escape_string($value1)."'";
				   	}
			   	}
			}
		}

		$columns_hx['sm_id'] = $_POST['sm_id'];
		$columns_ha['sm_id'] = $_POST['sm_id'];

		$columns1 = implode(", ",array_keys($columns_hx));
		$columns2 = implode(", ",array_keys($columns_ha));

		foreach ($valueshx as $key => $value) {
			$valueshx[$key] = $valueshx[$key].', '.$_POST['sm_id'].')';
		}

		foreach ($valuesha as $key => $value) {
			$valuesha[$key] = $valuesha[$key].', '.$_POST['sm_id'].')';
		}

		// $escaped_valueshx = array_map(array($conn, 'real_escape_string'),array_values($valueshx));
		$string_valueshx  = implode(", ", $valueshx);

		// $escaped_valuesha = array_map(array($conn, 'real_escape_string'),array_values($valuesha));
		$string_valuesha  = implode(", ", $valuesha);

		

		// echo "<br>";
		// echo "<br>";
		// var_dump($valueshx);
		// echo "<br>";
		// echo "<br>";
		// var_dump($valuesha);
		// echo "<br>";
		// echo "<br>";
		// var_dump($string_valueshx);
		// echo "<br>";
		// echo "<br>";
		// var_dump($string_valuesha);
		// echo "<br>";
		// echo "<br>";

		$sqlhx = "INSERT INTO r_hutangsimati ($columns1) VALUES $string_valueshx ";
		$sqlha = "INSERT INTO r_penghutangsimati ($columns2) VALUES $string_valuesha ";
		$id_simati = $_POST['sm_id'];

		// echo $sqlhx;
		// echo "<br>";
		// echo $sqlha;
		if ($conn->query($sqlhx) === TRUE) {
        	if ($conn->query($sqlha) === TRUE) {

	        	printf("Record inserted successfully.<br />");
	        	$base_url = base_url();
				
				$url = $base_url."/epusaka/view/borang_waris_waris.php?simati=$id_simati";
				// echo $url;
				mysqli_commit($conn);
				redirect($url);
			}else{
				mysqli_rollback($conn); 
        		printf("Could not insert record into table: %s<br />", $conn -> error);
			}
		}else{
			mysqli_rollback($conn); 
    		printf("Could not insert record into table: %s<br />", $conn -> error);
		}

      	$conn->close();
	}


	if (isset($_POST['btn_borang_benefisiari'])) {

		unset($_POST['btn_borang_harta']); 
		$data = $_POST;
		$values = array();
        $columns1 = implode(", ",array_keys($data));
		$columns_hx = array();
		$columns_ha = array();

		$valueshx = array();
		$valuesha = array();

		if (!function_exists('str_contains')) {
		    function str_contains(string $haystack, string $needle): bool
		    {
		        return '' === $needle || false !== strpos($haystack, $needle);
		    }
		}

		foreach ($data as $key => $value) {
			if (str_contains($key, 'ww_')) { 
			   $columns_hx[$key] = $value;
			   foreach ($value as $key1 => $value1) {
				   	if (isset($valueshx[$key1])) {
				   		$valueshx[$key1] = $valueshx[$key1].", '".$conn -> real_escape_string($value1)."'";
				   	}else{
				   		$valueshx[$key1] = "('".$conn -> real_escape_string($value1)."'";
				   	}
			   	}
			}
		}

		$columns_hx['sm_id'] = $_POST['sm_id'];

		$columns1 = implode(", ",array_keys($columns_hx));

		foreach ($valueshx as $key => $value) {
			$valueshx[$key] = $valueshx[$key].', '.$_POST['sm_id'].')';
		}

		$string_valueshx  = implode(", ", $valueshx);

		$sqlhx = "INSERT r_waris_wasiatsimati ($columns1) VALUES $string_valueshx ";
		echo $sqlhx;
		$id_simati = $_POST['sm_id'];

		if ($conn->query($sqlhx) === TRUE) {

        	printf("Record inserted successfully.<br />");
        	$base_url = base_url();
			
			$url = $base_url."/epusaka/view/borang_penjaga.php?simati=$id_simati";
			// echo $url;
			mysqli_commit($conn);
			redirect($url);
		}else{
			mysqli_rollback($conn); 
    		printf("Could not insert record into table: %s<br />", $conn -> error);
		}

      	$conn->close();
	}


	if (isset($_POST['btn_borang_penjaga'])) {
		// echo "borang permohonan";
		// var_dump($_POST);
		// $column = '';
		// foreach ($_POST as $key => $value) {
		// 	$column = $column.",".$key;
		// 	// echo $key;
		// 	// echo "<br>";
		// }
		// echo $column;
		unset($_POST['btn_borang_penjaga']);
		$_POST['pw_birthdate'] = date("d/m/Y", strtotime($_POST['pw_birthdate']));  
		$data = $_POST;
		$values = array();
        $columns = implode(", ",array_keys($data));
		$escaped_values = array_map(array($conn, 'real_escape_string'),array_values($data));
		$values  = implode("', '", $escaped_values);
		$sql = "INSERT INTO r_penjagawaris ($columns) VALUES ('$values')";
		$id_simati = $_POST['sm_id'];

		// echo $sql;
		if ($conn->query($sql) === TRUE) {
        	printf("Record inserted successfully.<br />");
        	$base_url = base_url();
        	// $last_id = $conn->insert_id;
			// echo $last_id;
			$url = $base_url."/epusaka/view/borang_akuan.php?simati=$id_simati";
			// echo $url;
			redirect($url);
     	}else{
         printf("Could not insert record into table: %s<br />", $conn -> error);
      	}
       $conn->close();
	}


	if (isset($_POST['btn_borang_akuan'])) {
		// echo "borang permohonan";
		// var_dump($_POST);
		// $column = '';
		// foreach ($_POST as $key => $value) {
		// 	$column = $column.",".$key;
		// 	// echo $key;
		// 	// echo "<br>";
		// }
		// echo $column;
		$id_simati = $_POST['sm_id'];
		$sql = "UPDATE r_simati SET sm_setuju ='1' WHERE sm_id = $id_simati;";

		// echo $sql;
		if ($conn->query($sql) === TRUE) {
        	printf("Record inserted successfully.<br />");
        	$base_url = base_url();
        	// $last_id = $conn->insert_id;
			// echo $last_id;
			$url = $base_url."/epusaka/view/borang_view.php?simati=$id_simati";
			// echo $url;
			redirect($url);
     	}else{
         printf("Could not insert record into table: %s<br />", $conn -> error);
      	}
       $conn->close();
	}


	if (isset($_POST['btn_update_status'])) {
		// echo "borang permohonan";
		// var_dump($_POST);
		// $column = '';
		// foreach ($_POST as $key => $value) {
		// 	$column = $column.",".$key;
		// 	// echo $key;
		// 	// echo "<br>";
		// }
		// echo $column;
		$m_nofail = $_POST['m_nofail'];
		$m_status = $_POST['m_status'];
		$m_keterangan = $_POST['m_keterangan'];
		$curr_datetime = date("d/m/Y H:i:s");
		$username = $_SESSION['username'];

		$sql = "UPDATE maklumat SET m_status = '$m_status', m_keterangan = '$m_keterangan' WHERE m_nofail = '$m_nofail'";
		$sql2 = "INSERT INTO sejarah(s_nofail, s_status, s_tarikh, s_penerangan, s_pegawai) VALUES ('$m_nofail','$m_status','$curr_datetime','$m_keterangan','$username')";

		// echo $sql;
		if ($conn->query($sql) === TRUE) {
        	if ($conn->query($sql2) === TRUE) {

	        	printf("Record inserted successfully.<br />");
	        	$base_url = base_url();
				
				$url = $base_url."/epusaka/view/senarai_pusaka.php";
				// echo $url;
				mysqli_commit($conn);
				redirect($url);
			}else{
				mysqli_rollback($conn); 
        		printf("Could not insert record into table: %s<br />", $conn -> error);
			}
     	}else{
     		mysqli_rollback($conn); 
         	printf("Could not insert record into table: %s<br />", $conn -> error);
      	}
       $conn->close();
	}


	if (isset($_POST['btn_update_mohon'])) {
		// echo "borang permohonan";
		// var_dump($_POST);
		// $column = '';
		// foreach ($_POST as $key => $value) {
		// 	$column = $column.",".$key;
		// 	// echo $key;
		// 	// echo "<br>";
		// }
		// echo $column;
		// $m_nofail = $_POST['m_nofail'];
		// $m_status = $_POST['m_status'];
		// $m_keterangan = $_POST['m_keterangan'];
		// $curr_datetime = date("d/m/Y H:i:s");
		// $username = $_SESSION['username'];
		$_POST['p_birthdate'] = date("d/m/Y", strtotime($_POST['p_birthdate'])); 
		$sm_id = $_POST['sm_id'];

		$sql = "UPDATE r_pemohon SET p_nama='".$_POST['p_nama']."',p_nric_new='".$_POST['p_nric_new']."',p_nric_old='".$_POST['p_nric_old']."',p_age='".$_POST['p_age']."',p_birthdate='".$_POST['p_birthdate']."',p_alamat_surat='".$_POST['p_alamat_surat']."',p_poskod_surat='".$_POST['p_poskod_surat']."',p_negeri_surat='".$_POST['p_negeri_surat']."',p_alamat='".$_POST['p_alamat']."',p_poskod='".$_POST['p_poskod']."',p_negeri='".$_POST['p_negeri']."',p_tel_rumah='".$_POST['p_tel_rumah']."',p_tel_bimbit='".$_POST['p_tel_bimbit']."',p_tel_pejabat='".$_POST['p_tel_pejabat']."',p_hubungan='".$_POST['p_hubungan']."' WHERE p_id='".$_POST['p_id']."'";

		// echo $sql;
		if ($conn->query($sql) === TRUE) {

	        	printf("Record updated successfully.<br />");
	        	$base_url = base_url();
				
				$url = $base_url."/epusaka/view/update_simati.php?simati=$sm_id";
				// echo $url;
				mysqli_commit($conn);
				redirect($url);
     	}else{
     		mysqli_rollback($conn); 
         	printf("Could not insert record into table: %s<br />", $conn -> error);
      	}
       $conn->close();
	}



	if (isset($_POST['btn_updatesimati'])) {
		// echo "borang permohonan";
		// var_dump($_POST);
		// $column = '';
		// foreach ($_POST as $key => $value) {
		// 	$column = $column.",".$key;
		// 	// echo $key;
		// 	// echo "<br>";
		// }
		// echo $column;
		// $m_nofail = $_POST['m_nofail'];
		// $m_status = $_POST['m_status'];
		// $m_keterangan = $_POST['m_keterangan'];
		// $curr_datetime = date("d/m/Y H:i:s");
		// $username = $_SESSION['username'];
		$_POST['sm_datemati'] = date("d/m/Y", strtotime($_POST['sm_datemati'])); 
		$sm_id = $_POST['sm_id'];

		$sql = "UPDATE r_simati SET sm_nama='".$_POST['sm_nama']."',sm_nric_new='".$_POST['sm_nric_new']."',sm_nric_old='".$_POST['sm_nric_old']."',sm_jantina='".$_POST['sm_jantina']."',sm_datemati='".$_POST['sm_datemati']."',sm_sbbmati='".$_POST['sm_sbbmati']."',sm_tmptmati='".$_POST['sm_tmptmati']."',sm_taraf_perkhawinan='".$_POST['sm_taraf_perkhawinan']."',sm_warganegara='".$_POST['sm_warganegara']."',sm_agama='".$_POST['sm_agama']."',sm_bangsa='".$_POST['sm_bangsa']."',sm_muflis='".$_POST['sm_muflis']."' WHERE sm_id='".$_POST['sm_id']."'";

		// echo $sql;
		if ($conn->query($sql) === TRUE) {

	        	printf("Record updated successfully.<br />");
	        	$base_url = base_url();
				
				$url = $base_url."/epusaka/view/update_wasiat_wasi.php?simati=$sm_id";
				// echo $url;
				mysqli_commit($conn);
				redirect($url);
     	}else{
     		mysqli_rollback($conn); 
         	printf("Could not insert record into table: %s<br />", $conn -> error);
      	}
       	$conn->close();
	}


	if (isset($_POST['btn_update_wasiat'])) {
		// echo "borang permohonan";
		// var_dump($_POST);
		// $column = '';
		// foreach ($_POST as $key => $value) {
		// 	$column = $column.",".$key;
		// 	// echo $key;
		// 	// echo "<br>";
		// }
		// echo $column;
		// $m_nofail = $_POST['m_nofail'];
		// $m_status = $_POST['m_status'];
		// $m_keterangan = $_POST['m_keterangan'];
		// $curr_datetime = date("d/m/Y H:i:s");
		// $username = $_SESSION['username'];
		$_POST['iw_birthdate'] = date("d/m/Y", strtotime($_POST['iw_birthdate'])); 
		$sm_id = $_POST['sm_id'];

		$sql = "UPDATE r_infowasiat SET iw_jenis='".$_POST['iw_jenis']."',iw_nopendaftaran='".$_POST['iw_nopendaftaran']."',iw_tmptsimpan='".$_POST['iw_tmptsimpan']."',iw_wasi='".$_POST['iw_wasi']."',iw_nama='".$_POST['iw_nama']."',iw_nric_new='".$_POST['iw_nric_new']."',iw_nric_old='".$_POST['iw_nric_old']."',iw_umur='".$_POST['iw_umur']."',iw_birthdate='".$_POST['iw_birthdate']."',iw_alamat_surat='".$_POST['iw_alamat_surat']."',iw_alamat_tetap='".$_POST['iw_alamat_tetap']."',iw_poskod='".$_POST['iw_poskod']."',iw_negeri='".$_POST['iw_negeri']."',iw_tel_rumah='".$_POST['iw_tel_rumah']."',iw_tel_bimbit='".$_POST['iw_tel_bimbit']."',iw_tel_pjbt='".$_POST['iw_tel_pjbt']."',iw_hubungan='".$_POST['iw_hubungan']."',iw_surat_poskod='".$_POST['iw_surat_poskod']."',iw_surat_negeri='".$_POST['iw_surat_negeri']."',iw_emel='".$_POST['iw_emel']."' WHERE sm_id='".$_POST['sm_id']."'";

		// echo $sql;
		if ($conn->query($sql) === TRUE) {

	        	printf("Record updated successfully.<br />");
	        	$base_url = base_url();
				
				$url = $base_url."/epusaka/view/update_harta_simati.php?simati=$sm_id";
				// echo $url;
				mysqli_commit($conn);
				redirect($url);
     	}else{
     		mysqli_rollback($conn); 
         	printf("Could not insert record into table: %s<br />", $conn -> error);
      	}
       	$conn->close();
	}


	if (isset($_GET['page']) && isset($_GET['dlt_jenis']) && isset($_GET['dlte'])) {
		$sm_id = $_GET['idsimati'];
		echo $sql = "DELETE FROM ".$_GET['dlt_jenis']." WHERE ".$_GET['colname']." ='".$_GET['dlte']."'";

		// echo $sql;
		if ($conn->query($sql) === TRUE) {

	        	printf("Record deleted successfully.<br />");
	        	$base_url = base_url();
				
				$url = $base_url."/epusaka/view/".$_GET['page'].".php?simati=$sm_id";
				// echo $url;
				mysqli_commit($conn);
				redirect($url);
     	}else{
     		mysqli_rollback($conn); 
         	printf("Could not insert record into table: %s<br />", $conn -> error);
      	}
       	$conn->close();
	}
	

	if (isset($_POST['btn_update_penjaga'])) {
		// echo "borang permohonan";
		// var_dump($_POST);
		// $column = '';
		// foreach ($_POST as $key => $value) {
		// 	$column = $column.",".$key;
		// 	// echo $key;
		// 	// echo "<br>";
		// }
		// echo $column;
		// $m_nofail = $_POST['m_nofail'];
		// $m_status = $_POST['m_status'];
		// $m_keterangan = $_POST['m_keterangan'];
		// $curr_datetime = date("d/m/Y H:i:s");
		// $username = $_SESSION['username'];
		$_POST['pw_birthdate'] = date("d/m/Y", strtotime($_POST['pw_birthdate'])); 
		$sm_id = $_POST['sm_id'];

		echo $sql = "UPDATE r_penjagawaris SET pw_nama='".$_POST['pw_nama']."',pw_nric_new='".$_POST['pw_nric_new']."',pw_birthdate='".$_POST['pw_birthdate']."',pw_nric_old='".$_POST['pw_nric_old']."',pw_alamat_tetap='".$_POST['pw_alamat_tetap']."',pw_poskod='".$_POST['pw_poskod']."',pw_negeri='".$_POST['pw_negeri']."',pw_notel_rumah='".$_POST['pw_notel_rumah']."',pw_notel_bimbit='".$_POST['pw_notel_bimbit']."',pw_notel_pjbt='".$_POST['pw_notel_pjbt']."',pw_emel='".$_POST['pw_emel']."',pw_hubungan='".$_POST['pw_hubungan']."',pw_umur='".$_POST['pw_umur']."' WHERE sm_id='".$_POST['sm_id']."'";

		// echo $sql;
		if ($conn->query($sql) === TRUE) {

	        	printf("Record updated successfully.<br />");
	        	$base_url = base_url();
				
				$url = $base_url."/epusaka/view/borang_view.php?simati=$sm_id";
				// echo $url;
				mysqli_commit($conn);
				redirect($url);
     	}else{
     		mysqli_rollback($conn); 
         	printf("Could not insert record into table: %s<br />", $conn -> error);
      	}
       $conn->close();
	}


	if (isset($_POST['btn_update_hartaxalih'])) {
		// echo "borang permohonan";
		// var_dump($_POST);
		// $column = '';
		// foreach ($_POST as $key => $value) {
		// 	$column = $column.",".$key;
		// 	// echo $key;
		// 	// echo "<br>";
		// }
		// echo $column;
		// $m_nofail = $_POST['m_nofail'];
		// $m_status = $_POST['m_status'];
		// $m_keterangan = $_POST['m_keterangan'];
		// $curr_datetime = date("d/m/Y H:i:s");
		// $username = $_SESSION['username'];
		// $_POST['pw_birthdate'] = date("d/m/Y", strtotime($_POST['pw_birthdate'])); 
		$sm_id = $_POST['sm_id'];

		echo $sql = "UPDATE r_hrtxalih SET hx_jenis='".$_POST['hx_jenis']."',hx_no_hakmilik='".$_POST['hx_no_hakmilik']."',hx_no_lot='".$_POST['hx_no_lot']."',hx_mukim_bandar='".$_POST['hx_mukim_bandar']."',hx_daerah_negeri='".$_POST['hx_daerah_negeri']."',hx_bahagian='".$_POST['hx_bahagian']."',hx_anggaran='".$_POST['hx_anggaran']."' WHERE  hx_id='".$_POST['hx_id']."'";

		// echo $sql;
		if ($conn->query($sql) === TRUE) {

	        	printf("Record updated successfully.<br />");
	        	$base_url = base_url();
				
				$url = $base_url."/epusaka/view/update_harta_simati.php?simati=$sm_id";
				// echo $url;
				mysqli_commit($conn);
				redirect($url);
     	}else{
     		mysqli_rollback($conn); 
         	printf("Could not insert record into table: %s<br />", $conn -> error);
      	}
       	$conn->close();
	}


	if (isset($_POST['btn_update_hartaalih'])) {
		// echo "borang permohonan";
		// var_dump($_POST);
		// $column = '';
		// foreach ($_POST as $key => $value) {
		// 	$column = $column.",".$key;
		// 	// echo $key;
		// 	// echo "<br>";
		// }
		// echo $column;
		// $m_nofail = $_POST['m_nofail'];
		// $m_status = $_POST['m_status'];
		// $m_keterangan = $_POST['m_keterangan'];
		// $curr_datetime = date("d/m/Y H:i:s");
		// $username = $_SESSION['username'];
		// $_POST['pw_birthdate'] = date("d/m/Y", strtotime($_POST['pw_birthdate'])); 
		$sm_id = $_POST['sm_id'];

		echo $sql = "UPDATE r_hartaalih SET ha_jenis='".$_POST['ha_jenis']."',ha_no_akaun='".$_POST['ha_no_akaun']."',ha_anggaran='".$_POST['ha_anggaran']."' WHERE  ha_id='".$_POST['ha_id']."'";

		// echo $sql;
		if ($conn->query($sql) === TRUE) {

	        	printf("Record updated successfully.<br />");
	        	$base_url = base_url();
				
				$url = $base_url."/epusaka/view/update_harta_simati.php?simati=$sm_id";
				// echo $url;
				mysqli_commit($conn);
				redirect($url);
     	}else{
     		mysqli_rollback($conn); 
         	printf("Could not insert record into table: %s<br />", $conn -> error);
      	}
       	$conn->close();
	}


	if (isset($_POST['btn_update_waris'])) {
		// echo "borang permohonan";
		// var_dump($_POST);
		// $column = '';
		// foreach ($_POST as $key => $value) {
		// 	$column = $column.",".$key;
		// 	// echo $key;
		// 	// echo "<br>";
		// }
		// echo $column;
		// $m_nofail = $_POST['m_nofail'];
		// $m_status = $_POST['m_status'];
		// $m_keterangan = $_POST['m_keterangan'];
		// $curr_datetime = date("d/m/Y H:i:s");
		// $username = $_SESSION['username'];
		// $_POST['pw_birthdate'] = date("d/m/Y", strtotime($_POST['pw_birthdate'])); 
		$sm_id = $_POST['sm_id'];

		echo $sql = "UPDATE r_waris_wasiatsimati SET ww_nama='".$_POST['ww_nama']."',ww_hubungan='".$_POST['ww_hubungan']."',ww_alamat='".$_POST['ww_alamat']."',ww_nric='".$_POST['ww_nric']."',ww_notel_rumah='".$_POST['ww_notel_rumah']."',ww_notel_pejabat='".$_POST['ww_notel_pejabat']."',ww_notel_bimbit='".$_POST['ww_notel_bimbit']."',ww_emel='".$_POST['ww_emel']."',ww_waris_type='".$_POST['ww_waris_type']."' WHERE  ww_id ='".$_POST['ww_id']."'";

		// echo $sql;
		if ($conn->query($sql) === TRUE) {

	        	printf("Record updated successfully.<br />");
	        	$base_url = base_url();
				
				$url = $base_url."/epusaka/view/update_benefisiari.php?simati=$sm_id";
				// echo $url;
				mysqli_commit($conn);
				redirect($url);
     	}else{
     		mysqli_rollback($conn); 
         	printf("Could not insert record into table: %s<br />", $conn -> error);
      	}
       	$conn->close();
	}


	if (isset($_POST['btn_update_hutang'])) {
		$sm_id = $_POST['sm_id'];

		echo $sql = "UPDATE r_hutangsimati SET hs_jenis='".$_POST['hs_jenis']."',hs_nama_alamat='".$_POST['hs_nama_alamat']."',hs_anggaran='".$_POST['hs_anggaran']."' WHERE  hs_id ='".$_POST['hs_id']."'";

		// echo $sql;
		if ($conn->query($sql) === TRUE) {

	        	printf("Record updated successfully.<br />");
	        	$base_url = base_url();
				
				$url = $base_url."/epusaka/view/update_hutang_penghutang.php?simati=$sm_id";
				// echo $url;
				mysqli_commit($conn);
				redirect($url);
     	}else{
     		mysqli_rollback($conn); 
         	printf("Could not insert record into table: %s<br />", $conn -> error);
      	}
       	$conn->close();
	}


	if (isset($_POST['btn_update_penghutang'])) {
		$sm_id = $_POST['sm_id'];

		echo $sql = "UPDATE r_penghutangsimati SET ps_jenis='".$_POST['ps_jenis']."',ps_nama_alamat='".$_POST['ps_nama_alamat']."',ps_anggaran='".$_POST['ps_anggaran']."' WHERE  ps_id ='".$_POST['ps_id']."'";

		// echo $sql;
		if ($conn->query($sql) === TRUE) {

	        	printf("Record updated successfully.<br />");
	        	$base_url = base_url();
				
				$url = $base_url."/epusaka/view/update_hutang_penghutang.php?simati=$sm_id";
				// echo $url;
				mysqli_commit($conn);
				redirect($url);
     	}else{
     		mysqli_rollback($conn); 
         	printf("Could not insert record into table: %s<br />", $conn -> error);
      	}
       	$conn->close();
	}


	if (isset($_POST['btn_add_hartaxalih'])) {

		unset($_POST['btn_add_hartaxalih']);
		$data = $_POST;
		$values = array();
        $columns = implode(", ",array_keys($data));
		$escaped_values = array_map(array($conn, 'real_escape_string'),array_values($data));
		$values  = implode("', '", $escaped_values);
		
		$sql = "INSERT INTO r_hrtxalih ($columns) VALUES ('$values')";
		$id_simati = $_POST['sm_id'];
		echo $sql;
		if ($conn->query($sql) === TRUE) {

        	printf("Record inserted successfully.<br />");
        	$base_url = base_url();
			
			$url = $base_url."/epusaka/view/update_harta_simati.php?simati=$id_simati";
			// echo $url;
			mysqli_commit($conn);
			redirect($url);
		}else{
			mysqli_rollback($conn); 
    		printf("Could not insert record into table: %s<br />", $conn -> error);
		}
      	$conn->close();
	}


	if (isset($_POST['btn_add_hartaalih'])) {

		unset($_POST['btn_add_hartaalih']);
		$data = $_POST;
		$values = array();
        $columns = implode(", ",array_keys($data));
		$escaped_values = array_map(array($conn, 'real_escape_string'),array_values($data));
		$values  = implode("', '", $escaped_values);
		
		$sql = "INSERT INTO r_hartaalih ($columns) VALUES ('$values')";
		$id_simati = $_POST['sm_id'];
		echo $sql;
		if ($conn->query($sql) === TRUE) {

        	printf("Record inserted successfully.<br />");
        	$base_url = base_url();
			
			$url = $base_url."/epusaka/view/update_harta_simati.php?simati=$id_simati";
			// echo $url;
			mysqli_commit($conn);
			redirect($url);
		}else{
			mysqli_rollback($conn); 
    		printf("Could not insert record into table: %s<br />", $conn -> error);
		}
      	$conn->close();
	}


	if (isset($_POST['btn_add_waris'])) {

		unset($_POST['btn_add_waris']);
		$data = $_POST;
		$values = array();
        $columns = implode(", ",array_keys($data));
		$escaped_values = array_map(array($conn, 'real_escape_string'),array_values($data));
		$values  = implode("', '", $escaped_values);
		
		$sql = "INSERT INTO r_waris_wasiatsimati ($columns) VALUES ('$values')";
		$id_simati = $_POST['sm_id'];
		echo $sql;
		if ($conn->query($sql) === TRUE) {

        	printf("Record inserted successfully.<br />");
        	$base_url = base_url();
			
			$url = $base_url."/epusaka/view/update_benefisiari.php?simati=$id_simati";
			// echo $url;
			mysqli_commit($conn);
			redirect($url);
		}else{
			mysqli_rollback($conn); 
    		printf("Could not insert record into table: %s<br />", $conn -> error);
		}
      	$conn->close();
	}


	if (isset($_POST['btn_add_hutang'])) {

		unset($_POST['btn_add_hutang']);
		$data = $_POST;
		$values = array();
        $columns = implode(", ",array_keys($data));
		$escaped_values = array_map(array($conn, 'real_escape_string'),array_values($data));
		$values  = implode("', '", $escaped_values);
		
		$sql = "INSERT INTO r_hutangsimati ($columns) VALUES ('$values')";
		$id_simati = $_POST['sm_id'];
		echo $sql;
		if ($conn->query($sql) === TRUE) {

        	printf("Record inserted successfully.<br />");
        	$base_url = base_url();
			
			$url = $base_url."/epusaka/view/update_hutang_penghutang.php?simati=$id_simati";
			// echo $url;
			mysqli_commit($conn);
			redirect($url);
		}else{
			mysqli_rollback($conn); 
    		printf("Could not insert record into table: %s<br />", $conn -> error);
		}
      	$conn->close();
	}


	if (isset($_POST['btn_add_penghutang'])) {

		unset($_POST['btn_add_penghutang']);
		$data = $_POST;
		$values = array();
        $columns = implode(", ",array_keys($data));
		$escaped_values = array_map(array($conn, 'real_escape_string'),array_values($data));
		$values  = implode("', '", $escaped_values);
		
		$sql = "INSERT INTO r_penghutangsimati ($columns) VALUES ('$values')";
		$id_simati = $_POST['sm_id'];
		echo $sql;
		if ($conn->query($sql) === TRUE) {

        	printf("Record inserted successfully.<br />");
        	$base_url = base_url();
			
			$url = $base_url."/epusaka/view/update_hutang_penghutang.php?simati=$id_simati";
			// echo $url;
			mysqli_commit($conn);
			redirect($url);
		}else{
			mysqli_rollback($conn); 
    		printf("Could not insert record into table: %s<br />", $conn -> error);
		}
      	$conn->close();
	}
?>