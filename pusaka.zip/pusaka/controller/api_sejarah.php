<?php
    include "../Connection/connection.php";
    if (isset($_POST['id'])) {

        $conn = $GLOBALS["conn"]; //call connection that have set to global...
        $sql = "SELECT IFNULL(sejarah.s_tarikh,'') as s_tarikh,IFNULL(sejarah.s_status,'') as s_status,IFNULL(sejarah.s_penerangan,'') as s_penerangan,IFNULL(sejarah.s_pegawai,'') as s_pegawai FROM sejarah WHERE sejarah.s_nofail='".$_POST['id']."'"; // SQL with parameters
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->get_result(); 

        $item_arr=array();
        
        while ($row = $result->fetch_assoc()) {
            
            $item=array(
                "s_tarikh" => $row['s_tarikh'],
                "s_status" => $row['s_status'],
                "s_penerangan" => $row['s_penerangan'],
                "s_pegawai" => $row['s_pegawai']
            );
            array_push($item_arr, $item);
        }

  
        
        echo json_encode($item_arr);
    }

?>